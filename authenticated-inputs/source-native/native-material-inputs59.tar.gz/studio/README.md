# Theme Forge Nebular Fusion

Nebular Fusion 0.6.0 is an unreleased source checkpoint for the maintained
Darwin ARM64, Linux ARM64 and Linux x64 source-build targets. Native release
artifacts and installed GUI qualification remain pending.

The next component versions are Stellar Burst 0.6.0, Stellar Loom 0.4.0 and
Solar Sail 0.2.0. Existing authenticated embedded inputs and matching runtime
checks remain pinned to Burst 0.5.0, Loom 0.3.0 and Solar Sail 0.1.0 until new
upstream artifacts are qualified. Update their version and digest bindings
together and finalize that source change before committed-source Nebular
preparation. Separate version-only gates in portable consumer-closure validation,
sidecar preparation/manifest validation and the Rust sidecar artifact validator
also still reject Burst 0.6.0. Those gates require an explicit source update and
focused consumer qualification in that later commit; they are not digest pins.
The portable R7-1 consumer integration test remains a deferred production gate.
A private checkout is not a runtime input.

## Reproducible development

This product owns `flake.nix`, `flake.lock`, and `rust-toolchain.toml`.
From a clean checkout, enter its pinned environment with:

```sh
nix develop .
```

For an uncommitted local source snapshot, use `nix develop path:.` instead.
The lock fixes nixpkgs and rust-overlay source identities. The shell puts its
Rust binaries before host tools and rustup proxies. `rustc --version` reports
1.98.0 and `cargo --version` reports 1.98.0. No global profile or rustup change
and no `--ignore-rust-version` is needed. Node 22.23.2 or later is required for
frontend tooling; app payload preparation authenticates the exact declared
Node runtime independently.

```sh
npm ci --ignore-scripts
npm run typecheck
npm test
npm run build
cargo fmt --manifest-path src-tauri/Cargo.toml --all -- --check
cargo check --manifest-path src-tauri/Cargo.toml --locked --all-targets --all-features
cargo clippy --manifest-path src-tauri/Cargo.toml --locked --all-targets --all-features -- -D warnings
cargo test --manifest-path src-tauri/Cargo.toml --locked --all-targets --all-features
```

Release qualification uses the independent public composition and its
`authenticated-inputs` archives. It prepares and authenticates all three
payloads before building a default-feature app. Private development conveniences
do not qualify release inputs.

## Distribution and licensing

The Homebrew cask is **WITHHELD / NO-GO** pending Developer ID signing and
notarization. No public release or npm publication is authorized by this
candidate. No PNG/social-platform compatibility is claimed for Scene output.

The application is AGPL-3.0-or-later with a commercial licensing option.
See the repository's `LICENSE`, `NOTICE`, and `COMMERCIAL-LICENSE.md`.
[Public source and issue tracker](https://github.com/Knowledge-Forge-AI/theme-forge-nebular-fusion).
