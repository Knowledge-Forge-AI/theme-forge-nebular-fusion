# Contributing to Theme Forge Nebular Fusion

Theme Forge Nebular Fusion accepts contributions only under the project contribution terms in [CLA.md](CLA.md).

Contributors retain copyright in their contributions. By submitting a contribution, the contributor grants Samuel Leighton Lair, as Theme Forge Nebular Fusion project steward, broad copyright and patent rights to use, modify, distribute, sublicense, and relicense the contribution as part of Theme Forge Nebular Fusion, including under AGPL-3.0-or-later and commercial licenses.

Contributions must be original work or submitted with authority from the copyright owner. Do not submit code, documentation, generated output, or other content unless you have the right to provide it under these terms.

Every pull request must include this explicit acknowledgment in the pull request body:

```text
I agree to the Theme Forge Nebular Fusion contribution terms in CLA.md.
```

A `Signed-off-by` line may be included, but it does not replace the explicit pull request acknowledgment. Contributions without that acknowledgment cannot be accepted.

Pull requests should also confirm that the contributor has authority to submit the work under `CLA.md`.

Questions about commercial licensing or contribution terms can be sent to sam.lair@knowledge-forge.ai.
