import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { generateThemePackageCatalog } from "../src/catalog/index.js";

const root = resolve(import.meta.dirname, "..");
const testSpec = JSON.parse(
  readFileSync(resolve(root, "test/fixtures/catalog-dogfood-baseline/manifest.json"), "utf8")
).records[0].spec;

const metadata = {
  name: "starlight-theme-reading-test",
  version: "0.1.0",
};

describe("Stellar Loom reading layout preset and TS emission", () => {
  it("preserves exact default behavior when readingLayout and language are omitted", () => {
    const result = generateThemePackageCatalog({
      themeSpec: testSpec,
      metadata,
    });

    expect(result.files.has("styles/reading.css")).toBe(false);
    expect(result.files.has("src/index.ts")).toBe(false);
    expect(result.files.has("tsconfig.json")).toBe(false);
    expect(result.provenance.language).toBeUndefined();
  });

  it("emits layered styles/reading.css when readingLayout is true", () => {
    const result = generateThemePackageCatalog({
      themeSpec: testSpec,
      metadata,
      readingLayout: true,
    });

    expect(result.files.has("styles/reading.css")).toBe(true);
    const readingCss = result.files.get("styles/reading.css") as string;
    expect(readingCss).toContain("@layer tfsl.overrides");
    expect(readingCss).toContain(`--sl-content-width: min(${testSpec.surfaces.content}px, 48rem);`);
    expect(readingCss).toContain("--sl-content-margin-inline: auto;");

    const indexJs = result.files.get("index.js") as string;
    expect(indexJs).toContain("styles/reading.css");

    const readme = result.files.get("README.md") as string;
    expect(readme).toContain("Reading layout preset is active");
  });

  it("emits TypeScript source, declarations, and tsconfig when language is typescript", () => {
    const result = generateThemePackageCatalog({
      themeSpec: testSpec,
      metadata,
      readingLayout: true,
      language: "typescript",
    });

    expect(result.files.has("src/index.ts")).toBe(true);
    expect(result.files.has("tsconfig.json")).toBe(true);

    const srcTs = result.files.get("src/index.ts") as string;
    expect(srcTs).toContain("import type { HookParameters, StarlightPlugin, StarlightUserConfig } from \"@astrojs/starlight/types\";");
    expect(srcTs).toContain("export default function themePlugin(): StarlightPlugin");

    expect(result.provenance.language).toBe("typescript");
    const pkg = JSON.parse(result.files.get("package.json") as string);
    expect(pkg.files).toContain("src");
    expect(pkg.files).toContain("dist");
    expect(pkg.files).toContain("tsconfig.json");
    expect(pkg.scripts?.build).toBe("tsc");
    expect(pkg.exports["."].import).toBe("./dist/index.js");
    expect(pkg.exports["."].types).toBe("./dist/index.d.ts");
  });
});
