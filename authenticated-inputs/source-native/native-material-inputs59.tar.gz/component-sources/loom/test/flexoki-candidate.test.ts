import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import {
  mapProfileToSolarSail,
  mapProfileToStellarLoom,
  mapProfileToSyntaxPalette,
  compileTheme as compileSolarSailTheme,
  validateThemeSpecification as validateSolarSailTheme,
} from "../../solar-sail/src/index.js";
import {
  compileSyntaxPalette,
  compileThemeCatalog,
  validateSyntaxCategoryPalette,
  deriveSyntaxTheme,
} from "../src/index-catalog.js";

const __dirname = dirname(fileURLToPath(import.meta.url));
const PROFILE_PATH = resolve(__dirname, "../../solar-sail/examples/flexoki.profile.json");
const LOOM_CATALOG_PATH = resolve(__dirname, "../examples/loom-flexoki-catalog.json");

describe("Outcome D: Flexoki Paired-Design Candidate", () => {
  const profileRaw = readFileSync(PROFILE_PATH, "utf8");
  const profile = JSON.parse(profileRaw);
  const baseCatalog = JSON.parse(readFileSync(LOOM_CATALOG_PATH, "utf8"));

  it("conforms to tf-paired-profile-v1 schema without engine pollution", () => {
    expect(profile.schemaVersion).toBe("tf-paired-profile-v1");
    expect(profile.name).toBe("flexoki");
    expect(profile.palette.light.primary).toBe("#24837b");
    expect(profile.palette.dark.primary).toBe("#3aa99f");
    expect(profile.palette.light.accent).toBe("#bc5215");
    expect(profile.palette.dark.accent).toBe("#da702c");

    // Must have zero --sl-* or shadcn class/variable pollutions in source profile
    expect(profileRaw).not.toContain("--sl-");
    expect(profileRaw).not.toContain("--radius");
    expect(profileRaw).not.toContain("bg-background");
  });

  it("compiles cleanly and deterministically through Solar Sail engine", () => {
    const ssSpec = mapProfileToSolarSail(profile);
    const validation = validateSolarSailTheme(ssSpec);
    expect(validation.valid).toBe(true);
    expect(validation.errors).toHaveLength(0);

    const ssResult1 = compileSolarSailTheme(ssSpec);
    const ssResult2 = compileSolarSailTheme(ssSpec);
    expect(ssResult1.outputDigest).toBeDefined();
    expect(ssResult1.outputDigest).toBe(ssResult2.outputDigest);
    expect(ssResult1.css).toBe(ssResult2.css);
    expect(ssResult1.css).toContain("--primary: #24837b");
    expect(ssResult1.css).toContain(".dark");
    expect(ssResult1.css).toContain("--primary: #3aa99f");
  });

  it("derives valid SyntaxPaletteModel and compiles through Stellar Loom catalog", () => {
    const syntaxModel = mapProfileToSyntaxPalette(profile);
    const validatedPalette = validateSyntaxCategoryPalette(syntaxModel.syntax);
    expect(validatedPalette.light.comment).toBe("#6f6e69");
    expect(validatedPalette.light.string).toBe("#24837b");
    expect(validatedPalette.light.keyword).toBe("#a02f6f");
    expect(validatedPalette.dark.string).toBe("#3aa99f");

    const codePresentation = compileSyntaxPalette(syntaxModel as any);
    expect(codePresentation.mode).toBe("expressive-code");
    expect(codePresentation.frame).toBe("editor");
    expect(codePresentation.syntaxTheme.light.rules).toHaveLength(11);
    expect(codePresentation.syntaxTheme.dark.rules).toHaveLength(11);

    const mappedLoom = mapProfileToStellarLoom(profile, baseCatalog);
    mappedLoom.codePresentation = codePresentation;

    const loomResult1 = compileThemeCatalog(mappedLoom);
    const loomResult2 = compileThemeCatalog(mappedLoom);
    expect(loomResult1.descriptor.themeName).toBe("flexoki");
    expect(loomResult1.outputDigest).toBeDefined();
    expect(loomResult1.outputDigest).toBe(loomResult2.outputDigest);
    expect(loomResult1.styles.has("styles/code.css")).toBe(true);
    expect(loomResult1.styles.has("styles/tokens.css")).toBe(true);

    const tokensCss = loomResult1.styles.get("styles/tokens.css");
    expect(tokensCss).toContain("#24837b");
    expect(tokensCss).toContain("#3aa99f");
  });
});
