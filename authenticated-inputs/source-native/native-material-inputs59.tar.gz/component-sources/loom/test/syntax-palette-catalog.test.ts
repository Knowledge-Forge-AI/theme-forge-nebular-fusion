import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { generateThemePackageCatalog } from "../src/catalog/index.js";
import {
  compileSyntaxPalette,
  validateSyntaxCategoryPalette,
  type SyntaxPaletteModel,
} from "../src/syntax/index.js";
import { mapProfileToSyntaxPalette } from "../../../packages/solar-sail/src/profile.js";

const root = resolve(import.meta.dirname, "..");
const testSpec = JSON.parse(
  readFileSync(resolve(root, "test/fixtures/catalog-dogfood-baseline/manifest.json"), "utf8")
).records[0].spec;

const sampleSyntaxPalette: SyntaxPaletteModel = {
  syntax: {
    light: {
      keyword: "#a02f6f",
      string: "#24837b",
      number: "#bc5215",
      constant: "#ad8301",
      function: "#205ea6",
      type: "#24837b",
      variable: "#5e409d",
      comment: "#6f6e69",
      punctuation: "#6f6e69",
      tag: "#a02f6f",
      attribute: "#24837b",
    },
    dark: {
      keyword: "#ce5d97",
      string: "#3aa99f",
      number: "#da702c",
      constant: "#d0a215",
      function: "#4385be",
      type: "#3aa99f",
      variable: "#8b7ec8",
      comment: "#878580",
      punctuation: "#878580",
      tag: "#ce5d97",
      attribute: "#3aa99f",
    },
  },
  chrome: {
    light: {
      background: "#fffcf0",
      foreground: "#100f0f",
      border: "#cecdc3",
      focus: "#24837b",
      tabBarBackground: "#f2f0e5",
      activeTabBackground: "#fffcf0",
      activeTabIndicator: "#24837b",
    },
    dark: {
      background: "#100f0f",
      foreground: "#cecdc3",
      border: "#343331",
      focus: "#3aa99f",
      tabBarBackground: "#282726",
      activeTabBackground: "#100f0f",
      activeTabIndicator: "#3aa99f",
    },
  },
  tabs: {
    activeIndicator: "bottom",
  },
  frame: "editor",
};

const metadata = {
  name: "starlight-theme-syntax-palette-test",
  version: "0.1.0",
};

describe("Stellar Loom syntax palette catalog integration (R1-A deterministic test)", () => {
  it("omits tabs.css and uses standard ecDefaults when syntaxPalette is omitted", () => {
    const result = generateThemePackageCatalog({
      themeSpec: testSpec,
      metadata,
    });

    expect(result.files.has("styles/tabs.css")).toBe(false);
    const indexJs = result.files.get("index.js") as string;
    expect(indexJs).not.toContain("styles/tabs.css");
    const readme = result.files.get("README.md") as string;
    expect(readme).not.toContain("Code tabs presentation is active");
  });

  it("emits styles/tabs.css and derives ecDefaults styleOverrides when syntaxPalette is provided", () => {
    const result = generateThemePackageCatalog({
      themeSpec: testSpec,
      metadata,
      syntaxPalette: sampleSyntaxPalette,
    });

    // 1. styles/tabs.css emission
    expect(result.files.has("styles/tabs.css")).toBe(true);
    const tabsCss = result.files.get("styles/tabs.css") as string;
    expect(tabsCss).toContain("@layer tfsl.overrides");
    expect(tabsCss).toContain("starlight-tabs");
    expect(tabsCss).toContain("--sl-tab-color-border");

    // 2. index.js customCss array includes tabs.css
    const indexJs = result.files.get("index.js") as string;
    expect(indexJs).toContain(`${metadata.name}/styles/tabs.css`);

    // 3. ecDefaults includes derived styleOverrides
    expect(indexJs).toContain("const ecDefaults =");
    expect(indexJs).toContain('"codeBackground":');
    expect(indexJs).toContain('"editorActiveTabIndicatorBottomColor":');
    expect(indexJs).toContain("#3aa99f"); // active indicator dark color
    expect(indexJs).toContain("#24837b"); // active indicator light color

    // 4. README documentation
    const readme = result.files.get("README.md") as string;
    expect(readme).toContain("Code tabs presentation is active");
  });

  it("supports TypeScript language mode with strict typing and prepare script", () => {
    const result = generateThemePackageCatalog({
      themeSpec: testSpec,
      metadata,
      syntaxPalette: sampleSyntaxPalette,
      language: "typescript",
    });

    expect(result.files.has("src/index.ts")).toBe(true);
    expect(result.files.has("tsconfig.json")).toBe(true);
    expect(result.files.has("index.js")).toBe(false);

    const srcTs = result.files.get("src/index.ts") as string;
    expect(srcTs).toContain(`${metadata.name}/styles/tabs.css`);
    expect(srcTs).toContain("function mergeCodeConfig<T extends Record<string, unknown>");
    expect(srcTs).not.toContain("defaults: any");

    const tsconfig = JSON.parse(result.files.get("tsconfig.json") as string);
    expect(tsconfig.compilerOptions.strict).toBe(true);
    expect(tsconfig.compilerOptions.noImplicitAny).toBe(true);

    const pkgJson = JSON.parse(result.files.get("package.json") as string);
    expect(pkgJson.scripts?.build).toBe("tsc");
    expect(pkgJson.scripts?.prepare).toBe("tsc");
    expect(pkgJson.files).toContain("dist");
    expect(pkgJson.files).toContain("src");
  });

  it("guards against cross-package type drift with Solar Sail profile mapping (F12)", () => {
    const flexokiProfile = JSON.parse(
      readFileSync(resolve(root, "../solar-sail/examples/flexoki.profile.json"), "utf8")
    );

    const mappedSyntaxModel = mapProfileToSyntaxPalette(flexokiProfile);

    // Assert structural conformance to Loom validator and compiler
    const validated = validateSyntaxCategoryPalette(mappedSyntaxModel.syntax);
    expect(validated.light.keyword).toBe("#a02f6f");
    expect(validated.dark.keyword).toBe("#ce5d97");

    const compiledPresentation = compileSyntaxPalette(mappedSyntaxModel);
    expect(compiledPresentation.mode).toBe("expressive-code");
    expect(compiledPresentation.syntaxTheme.light.rules.length).toBe(11);
    expect(compiledPresentation.syntaxTheme.dark.rules.length).toBe(11);

    // Generation integration with Solar Sail mapped syntax palette
    const result = generateThemePackageCatalog({
      themeSpec: testSpec,
      metadata,
      syntaxPalette: mappedSyntaxModel,
    });
    expect(result.files.has("styles/tabs.css")).toBe(true);
  });

  it("proves provenance boundary: chrome delta alters package inventoryDigest while preserving cssOutputDigest (R2-F)", () => {
    // 1. Generate baseline package with sampleSyntaxPalette
    const resultA = generateThemePackageCatalog({
      themeSpec: testSpec,
      metadata: { name: "starlight-theme-provenance-test-a", version: "0.1.0" },
      syntaxPalette: sampleSyntaxPalette,
    });

    // 2. Generate second package with identical syntaxPalette except for chrome border colors
    // Note: Border requires both dark and light to be updated together in deriveExpressiveCodeStyleOverrides
    const alteredSyntaxPalette: SyntaxPaletteModel = {
      ...sampleSyntaxPalette,
      chrome: {
        ...sampleSyntaxPalette.chrome,
        dark: {
          ...sampleSyntaxPalette.chrome?.dark,
          border: "#454442", // changed from #343331
        },
        light: {
          ...sampleSyntaxPalette.chrome?.light,
          border: "#dcdbd2", // changed from #cecdc3
        },
      },
    };

    const resultB = generateThemePackageCatalog({
      themeSpec: testSpec,
      metadata: { name: "starlight-theme-provenance-test-a", version: "0.1.0" },
      syntaxPalette: alteredSyntaxPalette,
    });

    // CSS descriptor output digest is intentionally narrower than package runtime output
    // compileSyntaxPalette does not consume chrome, so CSS compilation output remains identical
    expect(resultA.cssOutputDigest).toBe(resultB.cssOutputDigest);

    // Package provenance inventoryDigest covers all emitted files (including index.js containing ecDefaults)
    expect(resultA.provenance.inventoryDigest).not.toBe(resultB.provenance.inventoryDigest);

    // Verify index.js content difference reflects the chrome styleOverride
    const indexJsA = resultA.files.get("index.js") as string;
    const indexJsB = resultB.files.get("index.js") as string;
    expect(indexJsA).not.toBe(indexJsB);
    expect(indexJsA).toContain("#343331");
    expect(indexJsB).toContain("#454442");

    // 3. Repeat for TypeScript generation mode (src/index.ts)
    const resultTsA = generateThemePackageCatalog({
      themeSpec: testSpec,
      metadata: { name: "starlight-theme-provenance-ts", version: "0.1.0" },
      syntaxPalette: sampleSyntaxPalette,
      language: "typescript",
    });

    const resultTsB = generateThemePackageCatalog({
      themeSpec: testSpec,
      metadata: { name: "starlight-theme-provenance-ts", version: "0.1.0" },
      syntaxPalette: alteredSyntaxPalette,
      language: "typescript",
    });

    expect(resultTsA.cssOutputDigest).toBe(resultTsB.cssOutputDigest);
    expect(resultTsA.provenance.inventoryDigest).not.toBe(resultTsB.provenance.inventoryDigest);

    const srcTsA = resultTsA.files.get("src/index.ts") as string;
    const srcTsB = resultTsB.files.get("src/index.ts") as string;
    expect(srcTsA).not.toBe(srcTsB);
    expect(srcTsA).toContain("#343331");
    expect(srcTsB).toContain("#454442");
  });

  it("throws a descriptive validation error when a chrome role is defined in only one mode (fail-closed)", () => {
    const asymmetricPalette: SyntaxPaletteModel = {
      ...sampleSyntaxPalette,
      chrome: {
        ...sampleSyntaxPalette.chrome,
        dark: {
          ...sampleSyntaxPalette.chrome?.dark,
          focus: "#3aa99f",
        },
        light: {
          ...sampleSyntaxPalette.chrome?.light,
          focus: undefined, // asymmetric: missing in light
        },
      },
    };

    expect(() =>
      generateThemePackageCatalog({
        themeSpec: testSpec,
        metadata: { name: "starlight-theme-asymmetric-test", version: "0.1.0" },
        syntaxPalette: asymmetricPalette,
      })
    ).toThrow(/\[SYNTAX_PALETTE_VALIDATION_ERROR\] Chrome role 'focus' must be defined in both dark and light modes/);
  });
});


