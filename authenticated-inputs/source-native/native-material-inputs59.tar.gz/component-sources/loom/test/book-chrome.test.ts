import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import {
  generateThemePackageCatalog,
  verifyCatalogDigest,
} from "../src/catalog/index.js";

const root = resolve(import.meta.dirname, "..");
const testSpec = JSON.parse(
  readFileSync(resolve(root, "test/fixtures/catalog-dogfood-baseline/manifest.json"), "utf8")
).records[0].spec;

const metadata = {
  name: "starlight-theme-book-chrome-test",
  version: "0.1.0",
};

describe("Stellar Loom book chrome layout capability and TS mode parity", () => {
  it("preserves frozen catalog digests with book chrome capability in envelope", () => {
    expect(verifyCatalogDigest()).toBe(true);
  });

  it("validates bookChrome and language options negatively", () => {
    expect(() =>
      generateThemePackageCatalog({
        themeSpec: testSpec,
        metadata,
        bookChrome: "invalid" as any,
      })
    ).toThrow("Invalid bookChrome option");

    expect(() =>
      generateThemePackageCatalog({
        themeSpec: testSpec,
        metadata,
        bookChrome: null as any,
      })
    ).toThrow("Invalid bookChrome option");

    expect(() =>
      generateThemePackageCatalog({
        themeSpec: testSpec,
        metadata,
        bookChrome: { unknownKey: true } as any,
      })
    ).toThrow("Invalid bookChrome option key");

    expect(() =>
      generateThemePackageCatalog({
        themeSpec: testSpec,
        metadata,
        bookChrome: { chapterNavigation: "not-a-boolean" } as any,
      })
    ).toThrow("Invalid bookChrome option value");

    expect(() =>
      generateThemePackageCatalog({
        themeSpec: testSpec,
        metadata,
        language: "python" as any,
      })
    ).toThrow("Unsupported language");
  });

  it("emits styles/book.css in @layer tfsl.overrides with zero !important", () => {
    const result = generateThemePackageCatalog({
      themeSpec: testSpec,
      metadata,
      bookChrome: true,
    });

    expect(result.files.has("styles/book.css")).toBe(true);
    const bookCss = result.files.get("styles/book.css") as string;
    expect(bookCss).toContain("@layer tfsl.overrides");
    expect(bookCss).toContain(".tfsl-book-chrome");
    expect(bookCss).toContain(".tfsl-book-nav-arrow");
    expect(bookCss).toContain(".tfsl-book-nav-prev");
    expect(bookCss).toContain(".tfsl-book-nav-next");
    expect(bookCss).toContain("data-tfsl-chapter-active");
    expect(bookCss).not.toContain("!important");

    const indexJs = result.files.get("index.js") as string;
    expect(indexJs).toContain("styles/book.css");

    const readme = result.files.get("README.md") as string;
    expect(readme).toContain("Book chrome layout preset is active");
    expect(result.provenance.bookChrome).toEqual({
      chapterNavigation: true,
      chapterProgress: true,
      keyboardShortcuts: true,
    });
  });

  it("proves bookChrome: true and bookChrome: {} emit identical normalized README bytes and provenance digests (Gate 13)", () => {
    const trueResult = generateThemePackageCatalog({
      themeSpec: testSpec,
      metadata,
      bookChrome: true,
    });
    const emptyObjResult = generateThemePackageCatalog({
      themeSpec: testSpec,
      metadata,
      bookChrome: {},
    });
    const explicitAllTrueResult = generateThemePackageCatalog({
      themeSpec: testSpec,
      metadata,
      bookChrome: { chapterNavigation: true, chapterProgress: true, keyboardShortcuts: true },
    });

    const expectedConfig = {
      chapterNavigation: true,
      chapterProgress: true,
      keyboardShortcuts: true,
    };

    expect(trueResult.provenance.bookChrome).toEqual(expectedConfig);
    expect(emptyObjResult.provenance.bookChrome).toEqual(expectedConfig);
    expect(explicitAllTrueResult.provenance.bookChrome).toEqual(expectedConfig);

    expect(trueResult.files.get("README.md")).toBe(emptyObjResult.files.get("README.md"));
    expect(trueResult.files.get("README.md")).toBe(explicitAllTrueResult.files.get("README.md"));

    expect(trueResult.provenance.inventoryDigest).toBe(emptyObjResult.provenance.inventoryDigest);
    expect(trueResult.provenance.inventoryDigest).toBe(explicitAllTrueResult.provenance.inventoryDigest);
  });

  it("emits book-chrome navigation arrows and collision-safe keyboard listener in Pagination.astro", () => {
    const result = generateThemePackageCatalog({
      themeSpec: testSpec,
      metadata,
      bookChrome: true,
    });

    const paginationAstro = result.files.get("components/Pagination.astro") as string;
    expect(paginationAstro).toContain("tfsl-book-nav-arrows");
    expect(paginationAstro).toContain("tfsl-book-nav-arrow tfsl-book-nav-prev");
    expect(paginationAstro).toContain("tfsl-book-nav-arrow tfsl-book-nav-next");
    expect(paginationAstro).toContain('addEventListener("keydown"');
    expect(paginationAstro).toContain("ArrowLeft");
    expect(paginationAstro).toContain("ArrowRight");
    expect(paginationAstro).toContain("fieldHasFocus");
    // Collision resistance assertions (Finding F1 & F2)
    expect(paginationAstro).toContain("e.defaultPrevented");
    expect(paginationAstro).toContain('[role="tab"], [role="tablist"]');
    expect(paginationAstro).toContain("contenteditable");
    expect(paginationAstro).toContain("scrollWidth - el.clientWidth >= 16");
    expect(paginationAstro).toContain('style.overflowX === "auto" || style.overflowX === "scroll"');

    const sidebarAstro = result.files.get("components/Sidebar.astro") as string;
    expect(sidebarAstro).toContain('data-tfsl-book-chrome="true"');

    const sidebarTreeAstro = result.files.get("components/SidebarTree.astro") as string;
    expect(sidebarTreeAstro).toContain('data-tfsl-chapter-active={item.current ? "true" : undefined}');
  });

  it("respects granular BookChromeConfig toggles and verifies distinct provenance digests (Finding F2)", () => {
    const fullResult = generateThemePackageCatalog({
      themeSpec: testSpec,
      metadata,
      bookChrome: true,
    });

    // 1. Disable chapter navigation (arrows)
    const noNavResult = generateThemePackageCatalog({
      themeSpec: testSpec,
      metadata,
      bookChrome: { chapterNavigation: false },
    });
    const noNavPagination = noNavResult.files.get("components/Pagination.astro") as string;
    expect(noNavPagination).not.toContain("tfsl-book-nav-arrows");
    expect(noNavPagination).toContain('addEventListener("keydown"');
    const noNavCss = noNavResult.files.get("styles/book.css") as string;
    expect(noNavCss).not.toContain(".tfsl-book-nav-arrow");
    expect(noNavResult.provenance.inventoryDigest).not.toBe(fullResult.provenance.inventoryDigest);

    // 2. Disable keyboard shortcuts
    const noKeyResult = generateThemePackageCatalog({
      themeSpec: testSpec,
      metadata,
      bookChrome: { keyboardShortcuts: false },
    });
    const noKeyPagination = noKeyResult.files.get("components/Pagination.astro") as string;
    expect(noKeyPagination).toContain("tfsl-book-nav-arrows");
    expect(noKeyPagination).not.toContain('addEventListener("keydown"');
    expect(noKeyResult.provenance.inventoryDigest).not.toBe(fullResult.provenance.inventoryDigest);

    // 3. Disable chapter progress
    const noProgResult = generateThemePackageCatalog({
      themeSpec: testSpec,
      metadata,
      bookChrome: { chapterProgress: false },
    });
    const noProgTree = noProgResult.files.get("components/SidebarTree.astro") as string;
    expect(noProgTree).not.toContain("data-tfsl-chapter-active");
    const noProgCss = noProgResult.files.get("styles/book.css") as string;
    expect(noProgCss).not.toContain("data-tfsl-chapter-active");
    expect(noProgResult.provenance.inventoryDigest).not.toBe(fullResult.provenance.inventoryDigest);
  });

  it("proves JavaScript mode and TypeScript mode export and import coherence", () => {
    const jsResult = generateThemePackageCatalog({
      themeSpec: testSpec,
      metadata,
      bookChrome: true,
      language: "javascript",
    });

    const tsResult = generateThemePackageCatalog({
      themeSpec: testSpec,
      metadata,
      bookChrome: true,
      language: "typescript",
    });

    // JS mode checks
    expect(jsResult.files.has("index.js")).toBe(true);
    expect(jsResult.files.has("index.d.ts")).toBe(true);
    expect(jsResult.files.has("navigation.js")).toBe(true);
    expect(jsResult.files.has("src/index.ts")).toBe(false);
    expect(jsResult.files.has("src/navigation.ts")).toBe(false);
    expect(jsResult.files.has("tsconfig.json")).toBe(false);

    const jsPagination = jsResult.files.get("components/Pagination.astro") as string;
    expect(jsPagination).toContain('import { safeHref, text } from "../navigation.js";');
    const jsSidebar = jsResult.files.get("components/Sidebar.astro") as string;
    expect(jsSidebar).toContain('import { projectNavigation } from "../navigation.js";');

    const jsPkg = JSON.parse(jsResult.files.get("package.json") as string);
    expect(jsPkg.exports["."].import).toBe("./index.js");
    expect(jsPkg.exports["./navigation.js"]).toBe("./navigation.js");
    expect(jsPkg.scripts).toBeUndefined();

    // TS mode checks
    expect(tsResult.files.has("index.js")).toBe(false);
    expect(tsResult.files.has("index.d.ts")).toBe(false);
    expect(tsResult.files.has("navigation.js")).toBe(false);
    expect(tsResult.files.has("src/index.ts")).toBe(true);
    expect(tsResult.files.has("src/navigation.ts")).toBe(true);
    expect(tsResult.files.has("tsconfig.json")).toBe(true);

    const tsPagination = tsResult.files.get("components/Pagination.astro") as string;
    expect(tsPagination).toContain('import { safeHref, text } from "../dist/navigation.js";');
    const tsSidebar = tsResult.files.get("components/Sidebar.astro") as string;
    expect(tsSidebar).toContain('import { projectNavigation } from "../dist/navigation.js";');

    const tsPkg = JSON.parse(tsResult.files.get("package.json") as string);
    expect(tsPkg.exports["."].import).toBe("./dist/index.js");
    expect(tsPkg.exports["."].types).toBe("./dist/index.d.ts");
    expect(tsPkg.exports["./navigation.js"].import).toBe("./dist/navigation.js");
    expect(tsPkg.exports["./navigation.js"].types).toBe("./dist/navigation.d.ts");
    expect(tsPkg.files).toContain("dist");
    expect(tsPkg.files).toContain("src");
    expect(tsPkg.files).toContain("tsconfig.json");
    expect(tsPkg.files).not.toContain("navigation.js");
    expect(tsPkg.scripts?.build).toBe("tsc");

    const tsConfig = JSON.parse(tsResult.files.get("tsconfig.json") as string);
    expect(tsConfig.compilerOptions.rootDir).toBe("src");
    expect(tsConfig.compilerOptions.outDir).toBe("dist");
    expect(tsConfig.compilerOptions.declaration).toBe(true);
    expect(tsConfig.compilerOptions.declarationMap).toBe(true);
    expect(tsConfig.compilerOptions.sourceMap).toBe(true);
    expect(tsConfig.compilerOptions.resolveJsonModule).toBe(true);
  });

  it("verifies behavioral equivalence of emitted navigation logic between JS and TS templates", async () => {
    const jsResult = generateThemePackageCatalog({
      themeSpec: testSpec,
      metadata,
      language: "javascript",
    });
    const tsResult = generateThemePackageCatalog({
      themeSpec: testSpec,
      metadata,
      language: "typescript",
    });

    const jsCode = jsResult.files.get("navigation.js") as string;
    const tsCode = tsResult.files.get("src/navigation.ts") as string;

    for (const fn of ["safeHref", "localHref", "text", "projectNavigation"]) {
      expect(jsCode).toContain("export function " + fn);
      expect(tsCode).toContain("export function " + fn);
    }

    const jsDataUrl = "data:text/javascript;base64," + Buffer.from(jsCode).toString("base64");
    const jsNav = await import(jsDataUrl);

    // Execute TypeScript source in Vitest runner to verify runtime behavioral equivalence (Finding F9c)
    const { tmpdir } = await import("node:os");
    const { writeFileSync, unlinkSync } = await import("node:fs");
    const { pathToFileURL } = await import("node:url");
    const tmpTsFile = resolve(tmpdir(), `temp-nav-${Date.now()}-${Math.random().toString(36).slice(2)}.ts`);
    let tsNav: any;
    try {
      writeFileSync(tmpTsFile, tsCode, "utf8");
      tsNav = await import(pathToFileURL(tmpTsFile).href);
    } finally {
      try { unlinkSync(tmpTsFile); } catch {}
    }

    for (const nav of [jsNav, tsNav]) {
      expect(nav.safeHref("/docs/intro")).toBe("/docs/intro");
      expect(nav.safeHref("#chapter-1")).toBe("#chapter-1");
      expect(() => nav.safeHref("javascript:alert(1)")).toThrow("Invalid navigation href");
      expect(() => nav.safeHref("//evil.com")).toThrow("Invalid navigation href");
      expect(() => nav.safeHref("/foo/../bar")).toThrow("Invalid navigation href");
      expect(() => nav.safeHref("/foo/%20/bar")).toThrow("Invalid navigation href");

      expect(nav.localHref("/intro", "/base/")).toBe("/base/intro");
      expect(nav.localHref("#top", "/base/")).toBe("#top");

      expect(nav.text("Chapter 1")).toBe("Chapter 1");
      expect(() => nav.text("")).toThrow("Invalid navigation label");
      expect(() => nav.text("Bad\u0000Text")).toThrow("Invalid navigation label");

      const sampleSidebar = [
        {
          type: "group",
          label: "Getting Started",
          entries: [
            { type: "link", label: "Introduction", href: "/docs/intro", isCurrent: true },
            { type: "link", label: "Installation", href: "/docs/install", isCurrent: false },
          ],
        },
      ];
      const projected = nav.projectNavigation(sampleSidebar);
      expect(projected).toHaveLength(1);
      expect(projected[0].type).toBe("group");
      expect(projected[0].label).toBe("Getting Started");
      expect(projected[0].current).toBe(true);
      expect(projected[0].entries).toHaveLength(2);
      expect(projected[0].entries[0].current).toBe(true);
      expect(projected[0].entries[0].href).toBe("/docs/intro");
      expect(projected[0].entries[1].current).toBe(false);
    }
  });
});
