import type { CompilationResult } from "./types.js";

export const MATERIAL_SCHEMA_VERSION = "tfss.material-v1" as const;
export const MATERIAL_DESCRIPTOR_SCHEMA = "tfss.material-descriptor-v1" as const;
export const MATERIAL_ADAPTER_NAME =
  "@knowledge-forge-ai/theme-forge-solar-sail/material" as const;
export const MATERIAL_ADAPTER_VERSION = "1.0.0" as const;

export type MaterialReducedTransparency = "preserve" | "reduce";
export type MaterialFallbackPolicy = "source-tint";

export interface MaterialModeV1 {
  panelAlpha?: number | undefined;
  borderAlpha?: number | undefined;
  blur?: string | undefined;
  saturation?: number | undefined;
  reducedTransparency?: MaterialReducedTransparency | undefined;
}

export interface MaterialPolicyV1 {
  solidFallback?: MaterialFallbackPolicy | undefined;
}

export interface MaterialSidecarV1 {
  schemaVersion: typeof MATERIAL_SCHEMA_VERSION;
  theme: {
    schemaVersion: "tfss.theme-v1";
    name: string;
    version: string;
    inputDigest: string;
    outputDigest: string;
  };
  light?: MaterialModeV1 | undefined;
  dark?: MaterialModeV1 | undefined;
  policy?: MaterialPolicyV1 | undefined;
  sourceProfileSha256?: string | undefined;
  adapter: {
    name: typeof MATERIAL_ADAPTER_NAME;
    version: typeof MATERIAL_ADAPTER_VERSION;
  };
}

export interface MaterialDescriptorV1 {
  schema: typeof MATERIAL_DESCRIPTOR_SCHEMA;
  schemaVersion: 1;
  materialSchemaVersion: typeof MATERIAL_SCHEMA_VERSION;
  themeInputDigest: string;
  themeOutputDigest: string;
  materialInputDigest: string;
  cssOutputDigest: string;
  adapter: {
    name: typeof MATERIAL_ADAPTER_NAME;
    version: typeof MATERIAL_ADAPTER_VERSION;
  };
  sourceProfileSha256?: string | undefined;
}

export interface GenerateMaterialSidecarOptions {
  /** The exact result returned by compileTheme; the emitter rebinds it. */
  compilation: CompilationResult;
  /** Paired-v2 material intent. Omission produces no sidecar. */
  material?: unknown;
  /** Optional expected source identity; the actual compiled specification wins. */
  sourceProfileSha256?: string;
  /** Explicit target policy; never inferred from source omission. */
  solidFallback?: MaterialFallbackPolicy;
}

export interface MaterialSidecarResult {
  sidecar: MaterialSidecarV1;
  descriptor: MaterialDescriptorV1;
  sidecarJson: string;
  descriptorJson: string;
  css: string;
  materialInputDigest: string;
  cssOutputDigest: string;
  files: Map<string, string>;
}
