import { assertSafeDataV2 } from "./paired-v2/canonical.js";
import type { MaterialModeV2, MaterialV2 } from "./paired-v2/types.js";
import { toUnitlessPx, deepFreeze } from "./paired-v2/normalize.js";
import type { MaterialFallbackPolicy } from "./material-types.js";

export type MaterialValidationCode =
  | "UNSAFE_DATA"
  | "SCHEMA_VALIDATION"
  | "INVALID_VALUE"
  | "SOURCE_PROFILE_BINDING_MISMATCH"
  | "COMPILATION_BINDING_MISMATCH";

export class MaterialSidecarValidationError extends TypeError {
  readonly code: MaterialValidationCode;
  readonly path: string | undefined;

  constructor(
    message: string,
    code: MaterialValidationCode = "SCHEMA_VALIDATION",
    path?: string
  ) {
    super(path ? `${message} at '${path}'` : message);
    this.name = "MaterialSidecarValidationError";
    this.code = code;
    this.path = path;
  }
}

const MATERIAL_MODE_KEYS = [
  "panelAlpha",
  "borderAlpha",
  "blur",
  "saturation",
  "reducedTransparency",
] as const;

const SIDECAR_PX_LENGTH = /^(?:0|(?:[0-9]+(?:\.[0-9]+)?|\.[0-9]+)px)$/u;

function fail(
  message: string,
  code: MaterialValidationCode = "SCHEMA_VALIDATION",
  path?: string
): never {
  throw new MaterialSidecarValidationError(message, code, path);
}

function assertSafe(value: unknown): void {
  try {
    assertSafeDataV2(value);
  } catch {
    fail("Material data must be safe plain data", "UNSAFE_DATA");
  }
}

function assertObject(value: unknown, path: string): asserts value is Record<string, unknown> {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    fail("Expected a plain object", "SCHEMA_VALIDATION", path);
  }
}

function assertExactKeys(value: Record<string, unknown>, allowed: readonly string[], path: string): void {
  for (const key of Object.keys(value)) {
    if (!allowed.includes(key)) fail(`Unknown field '${key}'`, "SCHEMA_VALIDATION", `${path}.${key}`);
  }
}

function validateAlpha(value: unknown, path: string): number {
  if (typeof value !== "number" || !Number.isFinite(value) || value < 0 || value > 1) {
    fail("Expected a finite number between 0 and 1", "INVALID_VALUE", path);
  }
  return value;
}

function validateBlur(value: unknown, path: string): string {
  if (typeof value !== "string" || value !== value.trim() || !SIDECAR_PX_LENGTH.test(value)) {
    fail("Expected a non-negative explicit length", "INVALID_VALUE", path);
  }
  const pixels = toUnitlessPx(value);
  if (pixels === null || pixels > 64) {
    fail("Blur must be an explicit pixel length no greater than 64px", "INVALID_VALUE", path);
  }
  return value;
}

function validateSaturation(value: unknown, path: string): number {
  if (typeof value !== "number" || !Number.isFinite(value) || value < 0 || value > 2) {
    fail("Expected a finite number between 0 and 2", "INVALID_VALUE", path);
  }
  return value;
}

function validateMode(value: unknown, mode: "light" | "dark"): MaterialModeV2 {
  const path = `material.${mode}`;
  assertObject(value, path);
  assertExactKeys(value, MATERIAL_MODE_KEYS, path);

  const clean: MaterialModeV2 = {};
  if (value.panelAlpha !== undefined) clean.panelAlpha = validateAlpha(value.panelAlpha, `${path}.panelAlpha`);
  if (value.borderAlpha !== undefined) clean.borderAlpha = validateAlpha(value.borderAlpha, `${path}.borderAlpha`);
  if (value.blur !== undefined) clean.blur = validateBlur(value.blur, `${path}.blur`);
  if (value.saturation !== undefined) clean.saturation = validateSaturation(value.saturation, `${path}.saturation`);
  if (value.reducedTransparency !== undefined) {
    if (value.reducedTransparency !== "preserve" && value.reducedTransparency !== "reduce") {
      fail("Expected 'preserve' or 'reduce'", "INVALID_VALUE", `${path}.reducedTransparency`);
    }
    clean.reducedTransparency = value.reducedTransparency;
  }
  return clean;
}

/** Validate the paired-v2 material object again at the native emitter boundary. */
export function validateMaterialInput(value: unknown): MaterialV2 | undefined {
  if (value === undefined) return undefined;
  assertSafe(value);
  assertObject(value, "material");
  assertExactKeys(value, ["light", "dark"], "material");

  const clean: MaterialV2 = {};
  if (value.light !== undefined) clean.light = validateMode(value.light, "light");
  if (value.dark !== undefined) clean.dark = validateMode(value.dark, "dark");
  return deepFreeze(clean);
}

export function validateMaterialPolicy(value: unknown): MaterialFallbackPolicy | undefined {
  if (value === undefined) return undefined;
  assertSafe(value);
  if (value !== "source-tint") {
    fail("Only the explicit 'source-tint' fallback policy is supported", "INVALID_VALUE", "solidFallback");
  }
  return value;
}

export function validateExpectedSourceProfileSha256(value: unknown): string | undefined {
  if (value === undefined) return undefined;
  assertSafe(value);
  if (typeof value !== "string" || !/^[0-9a-f]{64}$/.test(value)) {
    fail(
      "Expected a 64-character lowercase SHA-256 digest",
      "INVALID_VALUE",
      "sourceProfileSha256"
    );
  }
  return value;
}

function modeHasLeaves(mode: MaterialModeV2 | undefined): boolean {
  return mode !== undefined && Object.keys(mode).length > 0;
}

export function materialHasAuthoredLeaves(material: MaterialV2 | undefined): boolean {
  return modeHasLeaves(material?.light) || modeHasLeaves(material?.dark);
}

