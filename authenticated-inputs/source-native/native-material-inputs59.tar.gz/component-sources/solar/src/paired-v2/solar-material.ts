import type { CompilationResult, ThemeSpecification } from "../types.js";
import { compileTheme, computeSha256 } from "../compiler.js";
import {
  MATERIAL_SCHEMA_VERSION,
  type MaterialFallbackPolicy,
  type MaterialSidecarResult,
} from "../material-types.js";
import { generateMaterialSidecar } from "../material-emitter.js";
import {
  MaterialSidecarValidationError,
  validateMaterialPolicy,
} from "../material-validator.js";
import {
  assertSafeDataV2,
  canonicalizeProfileV2,
  computeCanonicalDigestV2,
  computeRawSourceSha256,
} from "./canonical.js";
import {
  getGenuineBoundProfileSnapshotV2,
  type GenuineBoundProfileSnapshotV2,
} from "./bound.js";
import {
  ERROR_CODES,
  PairedProfileV2Error,
  StaleProvenanceV2Error,
} from "./errors.js";
import {
  generateMappingReportV2,
  mapProfileToSolarSailV2,
} from "./mapping.js";
import { deepFreeze } from "./normalize.js";
import type {
  BoundPairedProfileV2,
  MappingReportV2,
  MaterialModeV2,
  PairedProfileV2,
  ProvenanceVerificationStatusV2,
} from "./types.js";

export const PAIRED_SOLAR_MATERIAL_RECEIPT_SCHEMA =
  "tf-paired-solar-material-receipt-v1" as const;
export const PAIRED_SOLAR_MATERIAL_ADAPTER_NAME =
  "@knowledge-forge-ai/theme-forge-solar-sail/paired-v2-material" as const;
export const PAIRED_SOLAR_MATERIAL_ADAPTER_VERSION = "1.0.0" as const;

const MATERIAL_FIELDS = [
  "panelAlpha",
  "borderAlpha",
  "blur",
  "saturation",
  "reducedTransparency",
] as const;

type MaterialFieldV1 = (typeof MATERIAL_FIELDS)[number];
type MaterialLeafValueV1 = number | string;

const CSS_VARIABLES: Readonly<Partial<Record<MaterialFieldV1, string>>> = {
  panelAlpha: "--tfss-material-panel-alpha",
  borderAlpha: "--tfss-material-border-alpha",
  blur: "--tfss-material-blur",
  saturation: "--tfss-material-saturation",
};

const AUTHORED_CSS_VARIABLES: Readonly<Partial<Record<MaterialFieldV1, string>>> = {
  panelAlpha: "--tfss-material-panel-alpha-authored",
  borderAlpha: "--tfss-material-border-alpha-authored",
  blur: "--tfss-material-blur-authored",
  saturation: "--tfss-material-saturation-authored",
};

export interface PairedV2SolarMaterialOptions {
  /**
   * Expected source identity. For verified bounds this is the bound raw-source
   * SHA-256; for unverified assertions the adapter uses the recomputed
   * canonical-profile SHA-256 instead of trusting the assertion.
   */
  expectedSourceProfileSha256?: string;
  /** Explicit Solar target fallback policy; never inferred from the profile. */
  solidFallback?: MaterialFallbackPolicy;
}

export interface SolarMaterialLeafEffectV1 {
  mode: "light" | "dark";
  field: MaterialFieldV1;
  sourcePath: string;
  sourceValue: MaterialLeafValueV1;
  target: "solar-material-sidecar";
  targetPath: string;
  cssVariable?: string;
  authoredCssVariable?: string;
  effectiveCssVariable?: string;
  reason: string;
}

export interface SolarMaterialMappingReceiptV1 {
  schema: typeof PAIRED_SOLAR_MATERIAL_RECEIPT_SCHEMA;
  target: "solar-material-sidecar";
  adapter: {
    name: typeof PAIRED_SOLAR_MATERIAL_ADAPTER_NAME;
    version: typeof PAIRED_SOLAR_MATERIAL_ADAPTER_VERSION;
  };
  profile: {
    name: string;
    version: string;
    canonicalDigest: string;
    canonicalSha256: string;
    sourceProfileSha256: string;
    sourceVerification: ProvenanceVerificationStatusV2;
  };
  theme: {
    schemaVersion: "tfss.theme-v1";
    name: string;
    version: string;
    inputDigest: string;
    outputDigest: string;
    baseReportDigest: string;
  };
  sidecar: {
    schemaVersion: typeof MATERIAL_SCHEMA_VERSION;
    materialInputDigest: string;
    sidecarOutputDigest: string;
    descriptorDigest: string;
    cssOutputDigest: string;
    files: Array<{ path: string; sha256: string }>;
  };
  effects: SolarMaterialLeafEffectV1[];
}

export interface PairedV2SolarMaterialResult {
  specification: ThemeSpecification;
  compilation: CompilationResult;
  report: MappingReportV2;
  canonicalDigest: string;
  canonicalProfileSha256: string;
  sourceProfileSha256: string;
  sidecar?: MaterialSidecarResult;
  receipt?: SolarMaterialMappingReceiptV1;
}

const OPTION_KEYS = ["expectedSourceProfileSha256", "solidFallback"] as const;

function fail(
  message: string,
  code: string = ERROR_CODES.SCHEMA_VALIDATION
): never {
  throw new PairedProfileV2Error(message, code);
}

function readOptions(value: unknown): PairedV2SolarMaterialOptions {
  if (value === undefined) return {};
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    fail("Solar material options must be a non-null object");
  }
  try {
    assertSafeDataV2(value);
  } catch {
    fail("Solar material options must contain safe plain data", ERROR_CODES.UNSAFE_DATA);
  }
  for (const key of Object.getOwnPropertyNames(value)) {
    if (!OPTION_KEYS.includes(key as (typeof OPTION_KEYS)[number])) {
      fail(`Unknown Solar material option '${key}'`);
    }
  }
  return value as PairedV2SolarMaterialOptions;
}

function validateExpectedSourceProfileSha256(value: unknown): string | undefined {
  if (value === undefined) return undefined;
  if (typeof value !== "string" || !/^[a-f0-9]{64}$/.test(value)) {
    fail(
      "Expected a 64-character lowercase SHA-256 source profile identity",
      ERROR_CODES.SCHEMA_VALIDATION
    );
  }
  return value;
}

function readBound(value: unknown): GenuineBoundProfileSnapshotV2 {
  const snapshot = getGenuineBoundProfileSnapshotV2(value);
  if (!snapshot) {
    fail(
      "A genuine bound paired-v2 profile is required",
      ERROR_CODES.UNSAFE_DATA
    );
  }
  return snapshot;
}

function mapGenuineBoundToSolarSail(
  profile: PairedProfileV2,
  provenance: GenuineBoundProfileSnapshotV2["provenance"]
): {
  specification: ThemeSpecification;
  report: MappingReportV2;
  sourceProfileSha256: string;
  canonicalDigest: string;
} {
  const effectiveSha256 =
    provenance.verificationStatus === "unverified-assertion"
      ? ""
      : provenance.rawSourceSha256;
  const mappingOptions = effectiveSha256
    ? { sourceProfileSha256: effectiveSha256 }
    : {};
  const specification = mapProfileToSolarSailV2(profile, mappingOptions);
  const report = generateMappingReportV2(
    profile,
    "solar-sail",
    mappingOptions,
    effectiveSha256 || undefined,
    provenance.verificationStatus === "transformed"
      ? "transformed"
      : effectiveSha256
        ? "source-bytes"
        : "serialized-profile"
  );
  return {
    specification,
    report,
    sourceProfileSha256: effectiveSha256,
    canonicalDigest: provenance.canonicalDigest,
  };
}

function isMaterialValidationError(
  value: unknown
): value is { name: string; code?: unknown; message: string } {
  if (value instanceof MaterialSidecarValidationError) return true;
  if (!value || typeof value !== "object") return false;
  const error = value as Record<string, unknown>;
  return (
    error.name === "MaterialSidecarValidationError" &&
    typeof error.message === "string"
  );
}

function materialErrorCode(code: unknown): string {
  if (code === "UNSAFE_DATA") return ERROR_CODES.UNSAFE_DATA;
  if (
    code === "SOURCE_PROFILE_BINDING_MISMATCH" ||
    code === "COMPILATION_BINDING_MISMATCH"
  ) {
    return ERROR_CODES.STALE_PROVENANCE;
  }
  return ERROR_CODES.SCHEMA_VALIDATION;
}

function rethrowMaterialValidationError(error: unknown): never {
  if (!isMaterialValidationError(error)) throw error;
  throw new PairedProfileV2Error(error.message, materialErrorCode(error.code));
}

function effectiveSourceProfileSha256(
  provenance: BoundPairedProfileV2["provenance"],
  canonicalProfileSha256: string
): string {
  if (provenance.verificationStatus === "unverified-assertion") {
    return canonicalProfileSha256;
  }
  if (!/^[a-f0-9]{64}$/.test(provenance.rawSourceSha256)) {
    fail("Bound source profile identity is not a SHA-256 digest", ERROR_CODES.UNSAFE_DATA);
  }
  return provenance.rawSourceSha256;
}

function materialEffects(material: PairedProfileV2["material"]): SolarMaterialLeafEffectV1[] {
  const effects: SolarMaterialLeafEffectV1[] = [];
  for (const mode of ["light", "dark"] as const) {
    const modeValue = material?.[mode] as MaterialModeV2 | undefined;
    for (const field of MATERIAL_FIELDS) {
      const sourceValue = modeValue?.[field];
      if (sourceValue === undefined) continue;
      const sourcePath = `material.${mode}.${field}`;
      effects.push({
        mode,
        field,
        sourcePath,
        sourceValue,
        target: "solar-material-sidecar",
        targetPath: `material.${mode}.${field}`,
        ...(CSS_VARIABLES[field] ? { cssVariable: CSS_VARIABLES[field] } : {}),
        ...(CSS_VARIABLES[field]
          ? {
              effectiveCssVariable: CSS_VARIABLES[field],
              ...(AUTHORED_CSS_VARIABLES[field]
                ? { authoredCssVariable: AUTHORED_CSS_VARIABLES[field] }
                : {}),
            }
          : {}),
        reason: "Authored material is emitted by the separate Solar sidecar; tfss.theme-v1 remains unchanged.",
      });
    }
  }
  return effects;
}

function buildReceipt(
  profile: PairedProfileV2,
  provenance: BoundPairedProfileV2["provenance"],
  canonicalDigest: string,
  canonicalProfileSha256: string,
  sourceProfileSha256: string,
  compilation: CompilationResult,
  report: MappingReportV2,
  sidecar: MaterialSidecarResult,
  effects: SolarMaterialLeafEffectV1[]
): SolarMaterialMappingReceiptV1 {
  const files = [...sidecar.files.entries()].map(([path, content]) => ({
    path,
    sha256: computeSha256(content),
  }));
  const receipt: SolarMaterialMappingReceiptV1 = {
    schema: PAIRED_SOLAR_MATERIAL_RECEIPT_SCHEMA,
    target: "solar-material-sidecar",
    adapter: {
      name: PAIRED_SOLAR_MATERIAL_ADAPTER_NAME,
      version: PAIRED_SOLAR_MATERIAL_ADAPTER_VERSION,
    },
    profile: {
      name: profile.name,
      version: profile.version,
      canonicalDigest,
      canonicalSha256: canonicalProfileSha256,
      sourceProfileSha256,
      sourceVerification: provenance.verificationStatus,
    },
    theme: {
      schemaVersion: "tfss.theme-v1",
      name: compilation.specification.name,
      version: compilation.specification.version,
      inputDigest: compilation.inputDigest,
      outputDigest: compilation.outputDigest,
      baseReportDigest: report.digest,
    },
    sidecar: {
      schemaVersion: MATERIAL_SCHEMA_VERSION,
      materialInputDigest: sidecar.materialInputDigest,
      sidecarOutputDigest: computeSha256(sidecar.sidecarJson),
      descriptorDigest: computeSha256(sidecar.descriptorJson),
      cssOutputDigest: sidecar.cssOutputDigest,
      files,
    },
    effects,
  };
  return deepFreeze(receipt);
}

/**
 * Map a bound paired-v2 profile to the unchanged Solar theme plus an optional
 * separately named material sidecar and receipt. The base mapper/report remain
 * authoritative and continue to classify material as unsupported.
 */
export function compilePairedV2SolarMaterial(
  boundValue: BoundPairedProfileV2,
  options?: PairedV2SolarMaterialOptions
): PairedV2SolarMaterialResult {
  const snapshot = readBound(boundValue);
  const safeOptions = readOptions(options);
  const profile = snapshot.profile;
  const provenance = snapshot.provenance;
  const canonicalProfile = canonicalizeProfileV2(profile);
  const canonicalDigest = computeCanonicalDigestV2(canonicalProfile);
  const canonicalProfileSha256 = computeRawSourceSha256(canonicalProfile);
  const sourceProfileSha256 = effectiveSourceProfileSha256(
    provenance,
    canonicalProfileSha256
  );
  const expectedSourceProfileSha256 = validateExpectedSourceProfileSha256(
    safeOptions.expectedSourceProfileSha256
  );
  if (
    expectedSourceProfileSha256 !== undefined &&
    expectedSourceProfileSha256 !== sourceProfileSha256
  ) {
    throw new StaleProvenanceV2Error(
      expectedSourceProfileSha256,
      sourceProfileSha256,
      "Solar material source identity does not match the bound profile"
    );
  }

  const mapped = mapGenuineBoundToSolarSail(profile, provenance);
  if (mapped.canonicalDigest !== canonicalDigest) {
    fail("Bound Solar mapping canonical identity does not match the profile", ERROR_CODES.STALE_PROVENANCE);
  }
  if (mapped.sourceProfileSha256 !== (provenance.verificationStatus === "unverified-assertion" ? "" : sourceProfileSha256)) {
    fail("Bound Solar mapping source identity does not match the profile", ERROR_CODES.STALE_PROVENANCE);
  }
  const compilation = compileTheme(mapped.specification);

  const base: PairedV2SolarMaterialResult = {
    specification: mapped.specification,
    compilation,
    report: mapped.report,
    canonicalDigest,
    canonicalProfileSha256,
    sourceProfileSha256,
  };

  let sidecar: MaterialSidecarResult | undefined;
  try {
    const solidFallback = validateMaterialPolicy(safeOptions.solidFallback);
    sidecar = generateMaterialSidecar({
      compilation,
      ...(profile.material !== undefined ? { material: profile.material } : {}),
      ...(compilation.specification.sourceProfileSha256 !== undefined
        ? { sourceProfileSha256: compilation.specification.sourceProfileSha256 }
        : {}),
      ...(solidFallback !== undefined ? { solidFallback } : {}),
    });
  } catch (error) {
    rethrowMaterialValidationError(error);
  }
  if (sidecar === undefined) return base;

  const effects = materialEffects(profile.material);
  const receipt = buildReceipt(
    profile,
    provenance,
    canonicalDigest,
    canonicalProfileSha256,
    sourceProfileSha256,
    compilation,
    mapped.report,
    sidecar,
    effects
  );
  return {
    ...base,
    sidecar,
    receipt,
  };
}
