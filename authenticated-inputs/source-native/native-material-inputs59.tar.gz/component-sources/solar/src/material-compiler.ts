import { canonicalizeJson, compileTheme, computeSha256 } from "./compiler.js";
import type { CompilationResult } from "./types.js";
import {
  MATERIAL_ADAPTER_NAME,
  MATERIAL_ADAPTER_VERSION,
  MATERIAL_DESCRIPTOR_SCHEMA,
  MATERIAL_SCHEMA_VERSION,
  type MaterialDescriptorV1,
  type MaterialModeV1,
  type MaterialPolicyV1,
  type MaterialSidecarResult,
  type MaterialSidecarV1,
} from "./material-types.js";
import {
  MaterialSidecarValidationError,
  materialHasAuthoredLeaves,
  validateExpectedSourceProfileSha256,
  validateMaterialInput,
  validateMaterialPolicy,
} from "./material-validator.js";
import { assertSafeDataV2 } from "./paired-v2/canonical.js";
import type { MaterialModeV2, MaterialV2 } from "./paired-v2/types.js";

type EffectMode = "normal" | "neutral" | "authored" | "forced";

const LIGHT_SELECTORS = [":root"] as const;
const DARK_SELECTORS = [".dark", ":root[data-theme='dark']"] as const;
const LIGHT_MANUAL_REDUCE_SELECTORS = [
  ':root[data-tf-reduced-transparency="reduce"]',
] as const;
const DARK_MANUAL_REDUCE_SELECTORS = [
  ':root[data-tf-reduced-transparency="reduce"] .dark',
  ':root[data-tf-reduced-transparency="reduce"][data-theme="dark"]',
  '.dark:root[data-tf-reduced-transparency="reduce"]',
  '.dark[data-tf-reduced-transparency="reduce"]',
] as const;
const LIGHT_MANUAL_PRESERVE_SELECTORS = [
  ':root[data-tf-reduced-transparency="preserve"]',
] as const;
const DARK_MANUAL_PRESERVE_SELECTORS = [
  ':root[data-tf-reduced-transparency="preserve"] .dark',
  ':root[data-tf-reduced-transparency="preserve"][data-theme="dark"]',
  '.dark:root[data-tf-reduced-transparency="preserve"]',
  '.dark[data-tf-reduced-transparency="preserve"]',
] as const;

const VARS = {
  panelTint: "--tfss-material-panel-tint",
  panelAlphaAuthored: "--tfss-material-panel-alpha-authored",
  panelAlpha: "--tfss-material-panel-alpha",
  panelSolid: "--tfss-material-panel-solid",
  borderTint: "--tfss-material-border-tint",
  borderAlphaAuthored: "--tfss-material-border-alpha-authored",
  borderAlpha: "--tfss-material-border-alpha",
  borderSolid: "--tfss-material-border-solid",
  blurAuthored: "--tfss-material-blur-authored",
  blur: "--tfss-material-blur",
  saturationAuthored: "--tfss-material-saturation-authored",
  saturation: "--tfss-material-saturation",
} as const;

const VAR_ORDER = Object.values(VARS);

export interface MaterialCompilationInput {
  compilation: CompilationResult;
  material?: unknown;
  sourceProfileSha256?: string;
  solidFallback?: unknown;
}

const INPUT_KEYS = ["compilation", "material", "sourceProfileSha256", "solidFallback"] as const;

function fail(
  message: string,
  code: "UNSAFE_DATA" | "SCHEMA_VALIDATION" | "COMPILATION_BINDING_MISMATCH" = "SCHEMA_VALIDATION",
  path?: string
): never {
  throw new MaterialSidecarValidationError(message, code, path);
}

function readInput(value: unknown): MaterialCompilationInput {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    fail("MaterialCompilationInput must be a non-null object");
  }
  const prototype = Object.getPrototypeOf(value);
  if (prototype !== Object.prototype && prototype !== null) {
    fail("MaterialCompilationInput must use a plain prototype");
  }
  try {
    assertSafeDataV2(value);
  } catch {
    fail("Material compilation input must be safe plain data", "UNSAFE_DATA");
  }
  const record = value as Record<string, unknown>;
  for (const key of Object.getOwnPropertyNames(value)) {
    if (!INPUT_KEYS.includes(key as (typeof INPUT_KEYS)[number])) {
      fail(`Unknown material compilation option '${key}'`, "SCHEMA_VALIDATION", key);
    }
  }
  if (!Object.hasOwn(record, "compilation")) {
    fail("Missing compilation", "SCHEMA_VALIDATION", "compilation");
  }
  return record as unknown as MaterialCompilationInput;
}

function rebindCompilation(value: unknown): CompilationResult {
  try {
    assertSafeDataV2(value);
  } catch {
    fail("Compilation result must be safe plain data", "UNSAFE_DATA", "compilation");
  }
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    fail("Compilation result must be an object", "SCHEMA_VALIDATION", "compilation");
  }
  const candidate = value as CompilationResult;
  if (!candidate.specification || !candidate.descriptor || typeof candidate.css !== "string") {
    fail("Compilation result is incomplete", "SCHEMA_VALIDATION", "compilation");
  }
  let actual: CompilationResult;
  try {
    actual = compileTheme(candidate.specification);
  } catch {
    fail(
      "Compilation result specification is not compilable",
      "SCHEMA_VALIDATION",
      "compilation.specification"
    );
  }
  if (canonicalizeJson(actual) !== canonicalizeJson(candidate)) {
    fail(
      "Compilation result does not match the current Solar compiler",
      "COMPILATION_BINDING_MISMATCH",
      "compilation"
    );
  }
  return actual;
}

function modeWithLeaves(mode: MaterialModeV2 | undefined): MaterialModeV1 | undefined {
  if (!mode || Object.keys(mode).length === 0) return undefined;
  return { ...mode };
}

function hasField(mode: MaterialModeV2 | undefined, field: keyof MaterialModeV2): boolean {
  return mode?.[field] !== undefined;
}

function formatNumber(value: number): string {
  return String(value);
}

function authoredVariables(
  material: MaterialV2,
  policy: MaterialPolicyV1 | undefined
): string[] {
  const light = material.light;
  const dark = material.dark;
  const modes = [light, dark];
  const variables = new Set<string>();
  if (modes.some(mode => hasField(mode, "panelAlpha"))) {
    variables.add(VARS.panelTint);
    variables.add(VARS.panelAlphaAuthored);
    variables.add(VARS.panelAlpha);
    if (policy?.solidFallback) variables.add(VARS.panelSolid);
  }
  if (modes.some(mode => hasField(mode, "borderAlpha"))) {
    variables.add(VARS.borderTint);
    variables.add(VARS.borderAlphaAuthored);
    variables.add(VARS.borderAlpha);
    if (policy?.solidFallback) variables.add(VARS.borderSolid);
  }
  if (modes.some(mode => hasField(mode, "blur"))) {
    variables.add(VARS.blurAuthored);
    variables.add(VARS.blur);
  }
  if (modes.some(mode => hasField(mode, "saturation"))) {
    variables.add(VARS.saturationAuthored);
    variables.add(VARS.saturation);
  }
  return VAR_ORDER.filter(variable => variables.has(variable));
}

function resetLines(variables: readonly string[]): string[] {
  return variables.map(variable => `  ${variable}: initial;`);
}

function declarations(
  mode: MaterialModeV2 | undefined,
  variables: readonly string[],
  policy: MaterialPolicyV1 | undefined,
  effect: EffectMode
): string[] {
  const lines = resetLines(variables);
  if (!mode) return lines;

  if (mode.panelAlpha !== undefined) {
    const raw = formatNumber(mode.panelAlpha);
    lines.push(`  ${VARS.panelTint}: ${effect === "forced" ? "Canvas" : "var(--card)"};`);
    if (effect !== "forced") {
      lines.push(`  ${VARS.panelAlphaAuthored}: ${raw};`);
      lines.push(`  ${VARS.panelAlpha}: ${effect === "neutral" || effect === "normal" && mode.reducedTransparency === "reduce" ? "1" : raw};`);
      if (policy?.solidFallback) lines.push(`  ${VARS.panelSolid}: var(--card);`);
    } else {
      lines.push(`  ${VARS.panelAlphaAuthored}: ${raw};`);
      lines.push(`  ${VARS.panelAlpha}: 1;`);
      if (policy?.solidFallback) lines.push(`  ${VARS.panelSolid}: Canvas;`);
    }
  }

  if (mode.borderAlpha !== undefined) {
    const raw = formatNumber(mode.borderAlpha);
    lines.push(`  ${VARS.borderTint}: ${effect === "forced" ? "CanvasText" : "var(--border)"};`);
    if (effect !== "forced") {
      lines.push(`  ${VARS.borderAlphaAuthored}: ${raw};`);
      lines.push(`  ${VARS.borderAlpha}: ${effect === "neutral" || effect === "normal" && mode.reducedTransparency === "reduce" ? "1" : raw};`);
      if (policy?.solidFallback) lines.push(`  ${VARS.borderSolid}: var(--border);`);
    } else {
      lines.push(`  ${VARS.borderAlphaAuthored}: ${raw};`);
      lines.push(`  ${VARS.borderAlpha}: 1;`);
      if (policy?.solidFallback) lines.push(`  ${VARS.borderSolid}: CanvasText;`);
    }
  }

  if (mode.blur !== undefined) {
    lines.push(`  ${VARS.blurAuthored}: ${mode.blur};`);
    lines.push(`  ${VARS.blur}: ${effect === "forced" || effect === "neutral" ? "0px" : effect === "normal" && mode.reducedTransparency === "reduce" ? "0px" : mode.blur};`);
  }

  if (mode.saturation !== undefined) {
    const raw = formatNumber(mode.saturation);
    lines.push(`  ${VARS.saturationAuthored}: ${raw};`);
    lines.push(`  ${VARS.saturation}: ${effect === "forced" || effect === "neutral" ? "1" : effect === "normal" && mode.reducedTransparency === "reduce" ? "1" : raw};`);
  }

  return lines;
}

function rule(selectors: readonly string[], lines: readonly string[]): string {
  return `${selectors.join(",\n")} {\n${lines.join("\n")}\n}`;
}

function indented(value: string): string {
  return value.split("\n").map(line => `  ${line}`).join("\n");
}

function media(query: string, rules: readonly string[]): string {
  return `@media (${query}) {\n${rules.map(indented).join("\n\n")}\n}`;
}

function materialCss(
  material: MaterialV2,
  policy: MaterialPolicyV1 | undefined
): string {
  const variables = authoredVariables(material, policy);
  const header = "/* Generated by Theme Forge Solar Sail — tfss.material-v1 */";
  if (variables.length === 0) return `${header}\n`;

  const blocks = [
    header,
    rule(LIGHT_SELECTORS, declarations(material.light, variables, policy, "normal")),
    rule(DARK_SELECTORS, declarations(material.dark, variables, policy, "normal")),
    media("prefers-reduced-transparency: reduce", [
      rule(LIGHT_SELECTORS, declarations(material.light, variables, policy, "neutral")),
      rule(DARK_SELECTORS, declarations(material.dark, variables, policy, "neutral")),
    ]),
    rule(LIGHT_MANUAL_REDUCE_SELECTORS, declarations(material.light, variables, policy, "neutral")),
    rule(DARK_MANUAL_REDUCE_SELECTORS, declarations(material.dark, variables, policy, "neutral")),
    rule(LIGHT_MANUAL_PRESERVE_SELECTORS, declarations(material.light, variables, policy, "authored")),
    rule(DARK_MANUAL_PRESERVE_SELECTORS, declarations(material.dark, variables, policy, "authored")),
    media("forced-colors: active", [
      rule(LIGHT_SELECTORS, declarations(material.light, variables, policy, "forced")),
      rule(DARK_SELECTORS, declarations(material.dark, variables, policy, "forced")),
      rule(LIGHT_MANUAL_REDUCE_SELECTORS, declarations(material.light, variables, policy, "forced")),
      rule(DARK_MANUAL_REDUCE_SELECTORS, declarations(material.dark, variables, policy, "forced")),
      rule(LIGHT_MANUAL_PRESERVE_SELECTORS, declarations(material.light, variables, policy, "forced")),
      rule(DARK_MANUAL_PRESERVE_SELECTORS, declarations(material.dark, variables, policy, "forced")),
    ]),
  ];
  return `${blocks.join("\n\n")}\n`;
}

function outputMaterial(material: MaterialV2): { light?: MaterialModeV1; dark?: MaterialModeV1 } {
  const light = modeWithLeaves(material.light);
  const dark = modeWithLeaves(material.dark);
  return {
    ...(light ? { light } : {}),
    ...(dark ? { dark } : {}),
  };
}

export function compileMaterialSidecar(input: MaterialCompilationInput): MaterialSidecarResult | undefined {
  const safeInput = readInput(input);
  const compilation = rebindCompilation(safeInput.compilation);
  const material = validateMaterialInput(safeInput.material);
  const expectedSourceProfileSha256 = validateExpectedSourceProfileSha256(
    safeInput.sourceProfileSha256
  );
  const actualSourceProfileSha256 = compilation.specification.sourceProfileSha256;
  if (
    expectedSourceProfileSha256 !== undefined &&
    expectedSourceProfileSha256 !== actualSourceProfileSha256
  ) {
    throw new MaterialSidecarValidationError(
      "Source profile identity does not match the compiled Solar specification",
      "SOURCE_PROFILE_BINDING_MISMATCH",
      "sourceProfileSha256"
    );
  }
  const solidFallback = validateMaterialPolicy(safeInput.solidFallback);
  if (!material || !materialHasAuthoredLeaves(material)) return undefined;
  const policy: MaterialPolicyV1 | undefined = solidFallback
    ? { solidFallback }
    : undefined;
  const output = outputMaterial(material);
  const materialInput = {
    material: output,
    ...(policy ? { policy } : {}),
  };
  const materialInputJson = canonicalizeJson(materialInput);
  const materialInputDigest = computeSha256("tfss.material-input-v1\n" + materialInputJson);
  const sidecar: MaterialSidecarV1 = {
    schemaVersion: MATERIAL_SCHEMA_VERSION,
    theme: {
      schemaVersion: "tfss.theme-v1",
      name: compilation.specification.name,
      version: compilation.specification.version,
      inputDigest: compilation.inputDigest,
      outputDigest: compilation.outputDigest,
    },
    ...output,
    ...(policy ? { policy } : {}),
    ...(actualSourceProfileSha256 ? { sourceProfileSha256: actualSourceProfileSha256 } : {}),
    adapter: {
      name: MATERIAL_ADAPTER_NAME,
      version: MATERIAL_ADAPTER_VERSION,
    },
  };
  const sidecarJson = canonicalizeJson(sidecar);
  const css = materialCss(material, policy);
  const cssOutputDigest = computeSha256(css);
  const descriptor: MaterialDescriptorV1 = {
    schema: MATERIAL_DESCRIPTOR_SCHEMA,
    schemaVersion: 1,
    materialSchemaVersion: MATERIAL_SCHEMA_VERSION,
    themeInputDigest: compilation.inputDigest,
    themeOutputDigest: compilation.outputDigest,
    materialInputDigest,
    cssOutputDigest,
    adapter: {
      name: MATERIAL_ADAPTER_NAME,
      version: MATERIAL_ADAPTER_VERSION,
    },
    ...(actualSourceProfileSha256 ? { sourceProfileSha256: actualSourceProfileSha256 } : {}),
  };
  const descriptorJson = canonicalizeJson(descriptor);
  const files = new Map<string, string>([
    ["material.json", sidecarJson],
    ["material.descriptor.json", descriptorJson],
    ["styles/material.css", css],
  ]);
  return {
    sidecar,
    descriptor,
    sidecarJson,
    descriptorJson,
    css,
    materialInputDigest,
    cssOutputDigest,
    files,
  };
}
