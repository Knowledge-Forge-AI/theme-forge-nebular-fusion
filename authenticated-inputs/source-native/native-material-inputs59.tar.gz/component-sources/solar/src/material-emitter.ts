import { canonicalizeJson, compileTheme } from "./compiler.js";
import type { CompilationResult } from "./types.js";
import {
  type GenerateMaterialSidecarOptions,
  type MaterialSidecarResult,
} from "./material-types.js";
import {
  MaterialSidecarValidationError,
  validateExpectedSourceProfileSha256,
  validateMaterialInput,
  validateMaterialPolicy,
} from "./material-validator.js";
import { compileMaterialSidecar } from "./material-compiler.js";
import { assertSafeDataV2 } from "./paired-v2/canonical.js";

const OPTION_KEYS = [
  "compilation",
  "material",
  "sourceProfileSha256",
  "solidFallback",
] as const;

function fail(message: string, path?: string): never {
  throw new MaterialSidecarValidationError(message, "SCHEMA_VALIDATION", path);
}

function readSafeOptions(value: unknown): GenerateMaterialSidecarOptions {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    fail("GenerateMaterialSidecarOptions must be a non-null object");
  }
  const prototype = Object.getPrototypeOf(value);
  if (prototype !== Object.prototype && prototype !== null) {
    fail("GenerateMaterialSidecarOptions must use a plain prototype");
  }
  if (Object.getOwnPropertySymbols(value).length > 0) {
    fail("GenerateMaterialSidecarOptions cannot contain symbols");
  }

  const record = value as Record<string, unknown>;
  for (const key of Object.getOwnPropertyNames(value)) {
    if (!OPTION_KEYS.includes(key as (typeof OPTION_KEYS)[number])) {
      fail(`Unknown generation option '${key}'`, key);
    }
    const descriptor = Object.getOwnPropertyDescriptor(value, key);
    if (!descriptor || !descriptor.enumerable || !("value" in descriptor)) {
      fail("Generation options cannot contain accessors or hidden properties", key);
    }
    if (descriptor.value === undefined && key !== "material") {
      fail("Undefined optional values must be omitted", key);
    }
    if (descriptor.value !== undefined) {
      try {
        assertSafeDataV2(descriptor.value);
      } catch {
        throw new MaterialSidecarValidationError(
          "Generation options must contain safe plain data",
          "UNSAFE_DATA",
          key
        );
      }
    }
  }
  if (!Object.hasOwn(record, "compilation")) fail("Missing compilation", "compilation");
  return record as unknown as GenerateMaterialSidecarOptions;
}

function verifyCompilation(compilation: unknown): CompilationResult {
  try {
    assertSafeDataV2(compilation);
  } catch {
    throw new MaterialSidecarValidationError(
      "Compilation result must be safe plain data",
      "UNSAFE_DATA",
      "compilation"
    );
  }
  if (!compilation || typeof compilation !== "object" || Array.isArray(compilation)) {
    fail("Compilation result must be an object", "compilation");
  }
  const candidate = compilation as CompilationResult;
  if (!candidate.specification || !candidate.descriptor || typeof candidate.css !== "string") {
    fail("Compilation result is incomplete", "compilation");
  }

  let actual: CompilationResult;
  try {
    actual = compileTheme(candidate.specification);
  } catch {
    throw new MaterialSidecarValidationError(
      "Compilation result specification is not compilable",
      "SCHEMA_VALIDATION",
      "compilation.specification"
    );
  }
  if (canonicalizeJson(actual) !== canonicalizeJson(candidate)) {
    throw new MaterialSidecarValidationError(
      "Compilation result does not match the current Solar compiler",
      "COMPILATION_BINDING_MISMATCH",
      "compilation"
    );
  }
  return actual;
}

/**
 * Emit an optional Solar material sidecar without widening tfss.theme-v1.
 * The supplied compilation is rebound through compileTheme before any digest
 * or sidecar identity is accepted.
 */
export function generateMaterialSidecar(
  options: GenerateMaterialSidecarOptions
): MaterialSidecarResult | undefined {
  const safeOptions = readSafeOptions(options);
  const compilation = verifyCompilation(safeOptions.compilation);
  const material = validateMaterialInput(safeOptions.material);
  const sourceProfileSha256 = validateExpectedSourceProfileSha256(safeOptions.sourceProfileSha256);
  const solidFallback = validateMaterialPolicy(safeOptions.solidFallback);
  if (
    sourceProfileSha256 !== undefined &&
    sourceProfileSha256 !== compilation.specification.sourceProfileSha256
  ) {
    throw new MaterialSidecarValidationError(
      "Source profile identity does not match the compiled Solar specification",
      "SOURCE_PROFILE_BINDING_MISMATCH",
      "sourceProfileSha256"
    );
  }
  return compileMaterialSidecar({
    compilation,
    ...(material !== undefined ? { material } : {}),
    ...(compilation.specification.sourceProfileSha256 !== undefined
      ? { sourceProfileSha256: compilation.specification.sourceProfileSha256 }
      : {}),
    ...(solidFallback !== undefined ? { solidFallback } : {}),
  });
}
