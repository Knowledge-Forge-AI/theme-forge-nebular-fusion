#!/usr/bin/env node
/**
 * Paired Profile Mapper for Forge Console (TFSB67-R1).
 *
 * Demonstrates the shared profile-to-target mapping between:
 * - Solar Sail application theme specification (`tfss.theme-v1`)
 * - Stellar Loom documentation catalog specification (`tfsl.theme-v2`)
 *
 * Confirms that a single shared design profile (`forge-console.profile.json`)
 * maps core palette, radii, and typography to both engine targets while
 * preserving engine-specific overrides (Loom fonts/routes/codePresentation,
 * Solar Sail application surfaces/states).
 *
 * Supports:
 *   --check             Verify consistency between profile and committed target specs.
 *   --test-propagation  Demonstrate that changing a profile token updates both outputs.
 */

import { readFile, writeFile, mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { compileTheme, mapProfileToSolarSail, mapProfileToStellarLoom } from "../dist/index.js";
import { bindSourceProfile, generateMappingReport } from "../dist/profile.js";
import { compileThemeCatalog } from "../../stellar-loom/dist/index-catalog.js";

const __dirname = dirname(fileURLToPath(import.meta.url));
const SOLAR_SAIL_ROOT = resolve(__dirname, "..");
const REPO_ROOT = resolve(SOLAR_SAIL_ROOT, "../..");
const LOOM_ROOT = resolve(REPO_ROOT, "packages/stellar-loom");

const PROFILE_PATH = resolve(SOLAR_SAIL_ROOT, "examples/forge-console.profile.json");
const SS_THEME_PATH = resolve(SOLAR_SAIL_ROOT, "examples/forge-console.theme.json");
const SL_CATALOG_PATH = resolve(LOOM_ROOT, "examples/forge-console-reading-catalog.json");

export { mapProfileToSolarSail, mapProfileToStellarLoom };

export async function runCheck() {
  const profile = bindSourceProfile(await readFile(PROFILE_PATH)).profile;
  const ssSpec = JSON.parse(await readFile(SS_THEME_PATH, "utf8"));
  const slSpec = JSON.parse(await readFile(SL_CATALOG_PATH, "utf8"));

  const ssReport = generateMappingReport(profile, "solar-sail");
  const slReport = generateMappingReport(profile, "stellar-loom", { existingCatalog: slSpec });
  console.log(JSON.stringify({ mappingReports: [ssReport, slReport] }));

  // 1. Check Solar Sail palette consistency (primary, background, foreground, accent)
  const lightPrimarySS = ssSpec.palette.light.primary;
  const darkPrimarySS = ssSpec.palette.dark.primary;
  if (lightPrimarySS !== profile.palette.light.primary || darkPrimarySS !== profile.palette.dark.primary) {
    throw new Error(`Solar Sail primary colors do not match profile: ${lightPrimarySS} vs ${profile.palette.light.primary}`);
  }
  if (ssSpec.palette.light.background !== profile.palette.light.background || ssSpec.palette.dark.background !== profile.palette.dark.background) {
    throw new Error(`Solar Sail background colors do not match profile: ${ssSpec.palette.light.background} vs ${profile.palette.light.background}`);
  }
  if (ssSpec.palette.light.foreground !== profile.palette.light.foreground || ssSpec.palette.dark.foreground !== profile.palette.dark.foreground) {
    throw new Error(`Solar Sail foreground colors do not match profile: ${ssSpec.palette.light.foreground} vs ${profile.palette.light.foreground}`);
  }
  if (ssSpec.palette.light.accent !== profile.palette.light.accent || ssSpec.palette.dark.accent !== profile.palette.dark.accent) {
    throw new Error(`Solar Sail accent colors do not match profile`);
  }

  // 2. Check Stellar Loom palette consistency (primary/accent, page/background, body/foreground)
  const slTokens = slSpec.tokenSets["forge-console"];
  if (slTokens["cyan-light-accent-base"] !== profile.palette.light.primary) {
    throw new Error(`Loom cyan-light-accent-base does not match profile: ${slTokens["cyan-light-accent-base"]}`);
  }
  if (slTokens["cyan-dark-accent-base"] !== profile.palette.dark.primary) {
    throw new Error(`Loom cyan-dark-accent-base does not match profile: ${slTokens["cyan-dark-accent-base"]}`);
  }
  if (slTokens["cyan-light-page"] !== profile.palette.light.background) {
    throw new Error(`Loom cyan-light-page does not match profile background: ${slTokens["cyan-light-page"]}`);
  }
  if (slTokens["cyan-dark-page"] !== profile.palette.dark.background) {
    throw new Error(`Loom cyan-dark-page does not match profile background: ${slTokens["cyan-dark-page"]}`);
  }
  if (slTokens["cyan-light-body"] !== profile.palette.light.foreground) {
    throw new Error(`Loom cyan-light-body does not match profile foreground: ${slTokens["cyan-light-body"]}`);
  }
  if (slTokens["cyan-dark-body"] !== profile.palette.dark.foreground) {
    throw new Error(`Loom cyan-dark-body does not match profile foreground: ${slTokens["cyan-dark-body"]}`);
  }
  if (slTokens["orange-light-accent-base"] !== profile.palette.light.accent) {
    throw new Error(`Loom orange-light-accent-base does not match profile: ${slTokens["orange-light-accent-base"]}`);
  }
  if (slTokens["orange-dark-accent-base"] !== profile.palette.dark.accent) {
    throw new Error(`Loom orange-dark-accent-base does not match profile: ${slTokens["orange-dark-accent-base"]}`);
  }

  // 3. Check surfaces & typography
  if (ssSpec.surfaces.radius !== profile.surfaces.radius) {
    throw new Error("Solar Sail radius does not match profile");
  }
  if (slSpec.surfaces.content !== profile.surfaces.content) {
    throw new Error("Loom content measure does not match profile");
  }

  console.log("✓ Profile consistency check PASSED: forge-console profile faithfully maps to both targets (primary, accent, background, foreground, radius, content).");
  return { status: "pass", profile: profile.name, checkedTokens: ["primary", "accent", "background", "foreground", "radius", "content"] };
}

export async function runPropagationTest() {
  console.log("Testing shared design token propagation across both targets...");
  const baseProfile = JSON.parse(await readFile(PROFILE_PATH, "utf8"));
  const existingSL = JSON.parse(await readFile(SL_CATALOG_PATH, "utf8"));

  // Mutate primary color in profile
  const mutatedProfile = JSON.parse(JSON.stringify(baseProfile));
  mutatedProfile.palette.light.primary = "#00a896";
  mutatedProfile.palette.dark.primary = "#02c39a";

  const mappedSS = mapProfileToSolarSail(mutatedProfile);
  const mappedSL = mapProfileToStellarLoom(mutatedProfile, existingSL);

  if (mappedSS.palette.light.primary !== "#00a896" || mappedSS.palette.dark.primary !== "#02c39a") {
    throw new Error("Solar Sail mapping failed to receive mutated primary token");
  }
  if (
    mappedSL.tokenSets["forge-console"]["cyan-light-accent-base"] !== "#00a896" ||
    mappedSL.tokenSets["forge-console"]["cyan-dark-accent-base"] !== "#02c39a"
  ) {
    throw new Error("Stellar Loom mapping failed to receive mutated primary token");
  }

  // Verify compilation of mutated Solar Sail specification actually propagates the new token into CSS output
  const compiledSS = compileTheme(mappedSS);
  if (!compiledSS.css.includes("#00a896") && !compiledSS.css.includes("0 168 150")) {
    throw new Error("Compiled Solar Sail CSS does not reflect propagated mutated primary token");
  }
  console.log("   ✓ Solar Sail theme compilation verified: compiled CSS contains propagated primary token #00a896.");

  // Verify compilation of mutated Stellar Loom catalog actually propagates the new token into CSS output
  const compiledSL = compileThemeCatalog(mappedSL, { accent: "cyan" });
  const loomCss = Array.from(compiledSL.styles.values()).join("\n");
  if (!loomCss.includes("#00a896")) {
    throw new Error("Compiled Stellar Loom CSS does not reflect propagated mutated primary token #00a896");
  }
  console.log("   ✓ Stellar Loom catalog compilation verified: compiled CSS contains propagated primary token #00a896.");

  // Verify Loom catalog mapping serialization roundtrip
  const scratchDir = await mkdtemp(join(tmpdir(), "map-propagation-"));
  try {
    const ssOut = join(scratchDir, "mapped-solar-sail.json");
    const slOut = join(scratchDir, "mapped-stellar-loom.json");
    await writeFile(ssOut, JSON.stringify(mappedSS, null, 2));
    await writeFile(slOut, JSON.stringify(mappedSL, null, 2));
    const reloadedSS = JSON.parse(await readFile(ssOut, "utf8"));
    const reloadedSL = JSON.parse(await readFile(slOut, "utf8"));
    if (reloadedSS.palette.light.primary !== "#00a896" || reloadedSL.tokenSets["forge-console"]["cyan-light-accent-base"] !== "#00a896") {
      throw new Error("Serialized mapped output failed roundtrip verification");
    }
  } finally {
    await rm(scratchDir, { recursive: true, force: true }).catch(() => {});
  }

  // Engine-specific overrides preserved
  if (!Array.isArray(mappedSL.catalog?.fontLicenses) || mappedSL.codePresentation?.mode !== "expressive-code") {
    throw new Error("Loom engine-specific configuration was inadvertently stripped by mapping");
  }
  if (mappedSS.surfaces.radius !== "0.5rem") {
    throw new Error("Solar Sail radius was inadvertently changed");
  }

  console.log("✓ Dual-engine token propagation test PASSED: editing profile token simultaneously affects both real compiler outputs while preserving engine overrides.");
  return { status: "pass", testToken: "#00a896 / #02c39a" };
}

const args = process.argv.slice(2);
if (args.includes("--check") || args.length === 0) {
  runCheck().catch((err) => {
    console.error("FATAL:", err.message);
    process.exit(1);
  });
}
if (args.includes("--test-propagation")) {
  runPropagationTest().catch((err) => {
    console.error("FATAL:", err.message);
    process.exit(1);
  });
}
