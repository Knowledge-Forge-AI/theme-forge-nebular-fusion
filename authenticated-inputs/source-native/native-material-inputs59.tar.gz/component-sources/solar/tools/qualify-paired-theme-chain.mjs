#!/usr/bin/env node
/**
 * Dual-Chain Paired-Theme Qualification Harness for TFSB68A-R1.
 *
 * Verifies that a single paired design profile (`forge-console.profile.json`)
 * when mutated (e.g. primary color set to `#00a896` / `#02c39a`):
 * 1. Maps cleanly to Solar Sail application theme specification (`tfss.theme-v1`).
 * 2. Maps cleanly to Stellar Loom documentation catalog specification (`tfsl.theme-v2`).
 * 3. Generates and packs real TypeScript packages for both engines.
 * 4. Installs into real independent consumer fixtures:
 *    - Framework Consumer: Vite + React + Tailwind CSS v4 + shadcn/ui.
 *    - Reading Consumer: Astro + Starlight documentation with reading layout.
 * 5. Builds both consumers in isolation (`vite build` and `astro build`).
 * 6. Serves both builds over local HTTP servers and executes Playwright Chromium assertions:
 *    - Framework consumer verifies computed light primary button color `rgb(0, 168, 150)` (#00a896)
 *      and dark primary button color `rgb(2, 195, 154)` (#02c39a).
 *    - Reading consumer verifies Starlight accent CSS custom properties `--tfsl-color-accent-base`
 *      and `--sl-color-accent` evaluate to `#00a896` in light mode and `#02c39a` in dark mode.
 * 7. Captures full visual evidence to `docs/evaluations/evidence/tfsb68a-r1/`.
 */

import { execFileSync, spawnSync } from "node:child_process";
import { existsSync } from "node:fs";
import { createServer } from "node:http";
import { cp, mkdir, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { basename, dirname, extname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { chromium } from "@playwright/test";
import { mapProfileToSolarSail, mapProfileToStellarLoom } from "../dist/index.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const SOLAR_SAIL_ROOT = resolve(__dirname, "..");
const REPO_ROOT = resolve(SOLAR_SAIL_ROOT, "../..");
const LOOM_ROOT = resolve(REPO_ROOT, "packages/stellar-loom");
const EVIDENCE_DIR = resolve(REPO_ROOT, "docs/evaluations/evidence/tfsb68a-r1");

const PROFILE_PATH = resolve(SOLAR_SAIL_ROOT, "examples/forge-console.profile.json");
const LOOM_CATALOG_PATH = resolve(LOOM_ROOT, "examples/forge-console-reading-catalog.json");
const CONSUMER_APP_FIXTURE = resolve(SOLAR_SAIL_ROOT, "consumer-fixture");
const CONSUMER_DOC_FIXTURE = resolve(LOOM_ROOT, "consumer-fixture");

function startStaticServer(rootDir, port = 0) {
  const MIME_TYPES = {
    ".html": "text/html",
    ".css": "text/css",
    ".js": "application/javascript",
    ".json": "application/json",
    ".svg": "image/svg+xml",
    ".png": "image/png",
    ".woff": "font/woff",
    ".woff2": "font/woff2",
  };

  const server = createServer(async (req, res) => {
    try {
      const url = new URL(req.url ?? "/", "http://127.0.0.1");
      let pathname = decodeURIComponent(url.pathname);
      if (pathname.endsWith("/")) {
        pathname += "index.html";
      } else if (!extname(pathname)) {
        pathname += "/index.html";
      }

      const filePath = resolve(rootDir, pathname.replace(/^\//, ""));
      if (!filePath.startsWith(resolve(rootDir))) {
        res.writeHead(403, { "Content-Type": "text/plain" });
        res.end("403 Forbidden");
        return;
      }
      if (!existsSync(filePath)) {
        res.writeHead(404, { "Content-Type": "text/plain" });
        res.end("404 Not Found");
        return;
      }

      const ext = extname(filePath);
      const mime = MIME_TYPES[ext] || "application/octet-stream";
      const content = await readFile(filePath);
      res.writeHead(200, { "Content-Type": mime });
      res.end(content);
    } catch {
      res.writeHead(500, { "Content-Type": "text/plain" });
      res.end("500 Internal Server Error");
    }
  });

  return new Promise((resolvePromise) => {
    server.listen(port, "127.0.0.1", () => {
      const address = server.address();
      const actualPort = typeof address === "object" && address ? address.port : port;
      resolvePromise({
        port: actualPort,
        close: () =>
          new Promise((done) => {
            if (typeof server.closeAllConnections === "function") {
              server.closeAllConnections();
            }
            server.close(done);
          }),
      });
    });
  });
}

export async function runDualChainQualification() {
  console.log("=== TFSB68A-R1: Paired-Theme Dual-Chain Qualification Harness ===");
  await mkdir(EVIDENCE_DIR, { recursive: true });

  const scratchDir = await mkdtemp(join(tmpdir(), "tfsb68a-dual-chain-"));
  console.log(`1. Isolated scratch workspace: ${scratchDir}`);

  let browser;
  let srvApp;
  let srvDoc;

  const metrics = {
    mutatedTokens: {
      lightPrimary: "#00a896",
      darkPrimary: "#02c39a",
    },
    frameworkConsumer: {},
    readingConsumer: {},
    evidenceFiles: [],
  };

  try {
    // Step 1: Load base profile and apply test mutation
    console.log("2. Loading base profile and mutating primary design token...");
    const baseProfile = JSON.parse(await readFile(PROFILE_PATH, "utf8"));
    const mutatedProfile = JSON.parse(JSON.stringify(baseProfile));
    mutatedProfile.palette.light.primary = metrics.mutatedTokens.lightPrimary;
    mutatedProfile.palette.dark.primary = metrics.mutatedTokens.darkPrimary;
    mutatedProfile.targetOverrides = {
      solarSail: {
        surfaces: {
          radius: "0.75rem",
        },
      },
    };

    // Step 2: Validate and map profile to both targets
    console.log("3. Mapping mutated profile to Solar Sail and Stellar Loom targets...");
    const { assertValidPairedProfile } = await import("../dist/profile.js");
    assertValidPairedProfile(mutatedProfile);
    const baseLoomCatalog = JSON.parse(await readFile(LOOM_CATALOG_PATH, "utf8"));
    const mappedSS = mapProfileToSolarSail(mutatedProfile);
    const mappedSL = mapProfileToStellarLoom(mutatedProfile, baseLoomCatalog);

    if (mappedSS.surfaces.radius !== "0.75rem") {
      throw new Error(`Target override radius not preserved in mapped Solar Sail spec: ${mappedSS.surfaces.radius}`);
    }

    const ssSpecPath = join(scratchDir, "mapped-solar-sail.json");
    const slSpecPath = join(scratchDir, "mapped-stellar-loom.json");
    await writeFile(ssSpecPath, JSON.stringify(mappedSS, null, 2));
    await writeFile(slSpecPath, JSON.stringify(mappedSL, null, 2));

    // Step 3: Generate and build Solar Sail application theme package
    console.log("4. Generating Solar Sail application theme package (TypeScript)...");
    const ssMetaPath = join(scratchDir, "ss-meta.json");
    await writeFile(
      ssMetaPath,
      JSON.stringify(
        {
          name: "@knowledge-forge-ai/app-theme-forge-console",
          version: "0.1.0",
          description: "Forge Console application theme for Tailwind CSS v4 and shadcn/ui",
        },
        null,
        2
      )
    );

    const ssThemeDir = join(scratchDir, "ss-theme-pkg");
    execFileSync(process.execPath, [
      resolve(SOLAR_SAIL_ROOT, "bin/tfss.js"),
      "generate",
      ssSpecPath,
      "--package",
      ssMetaPath,
      "--out",
      ssThemeDir,
      "--language",
      "typescript",
      "--json",
    ]);

    execFileSync("npm", ["install", "--ignore-scripts"], { cwd: ssThemeDir, stdio: "pipe" });
    execFileSync("npm", ["run", "build"], { cwd: ssThemeDir, stdio: "pipe" });
    const packSsRaw = execFileSync("npm", ["pack", "--json"], { cwd: ssThemeDir, encoding: "utf8" });
    const ssTarball = join(ssThemeDir, JSON.parse(packSsRaw)[0].filename);
    console.log(`   Packed Solar Sail theme: ${basename(ssTarball)}`);

    // Step 4: Generate and build Stellar Loom documentation theme package
    console.log("5. Generating Stellar Loom documentation theme package (TypeScript)...");
    const slMetaPath = join(scratchDir, "sl-meta.json");
    await writeFile(
      slMetaPath,
      JSON.stringify(
        {
          name: "@knowledge-forge-ai/starlight-theme-forge-console",
          version: "0.1.0",
          description: "Forge Console Starlight documentation theme",
        },
        null,
        2
      )
    );

    const slThemeDir = join(scratchDir, "sl-theme-pkg");
    execFileSync(process.execPath, [
      resolve(LOOM_ROOT, "bin/tfsl.js"),
      "generate",
      slSpecPath,
      "--package",
      slMetaPath,
      "--out",
      slThemeDir,
      "--accent",
      "cyan",
      "--reading-layout",
      "--language",
      "typescript",
      "--json",
    ]);

    execFileSync("npm", ["install", "--ignore-scripts"], { cwd: slThemeDir, stdio: "pipe" });
    execFileSync("npm", ["run", "build"], { cwd: slThemeDir, stdio: "pipe" });
    const packSlRaw = execFileSync("npm", ["pack", "--json"], { cwd: slThemeDir, encoding: "utf8" });
    const slTarball = join(slThemeDir, JSON.parse(packSlRaw)[0].filename);
    console.log(`   Packed Stellar Loom theme: ${basename(slTarball)}`);

    // Step 5: Install Solar Sail theme into Vite + React Framework Consumer
    console.log("6. Installing Solar Sail theme into Framework Consumer fixture...");
    const appConsumerDir = join(scratchDir, "app-consumer");
    await cp(CONSUMER_APP_FIXTURE, appConsumerDir, {
      recursive: true,
      filter: (src) => !["node_modules", "dist"].includes(basename(src)),
    });
    execFileSync("npm", ["ci", "--ignore-scripts"], { cwd: appConsumerDir, stdio: "pipe" });
    execFileSync(
      "npm",
      ["install", "--ignore-scripts", "--no-save", "--package-lock=false", ssTarball],
      { cwd: appConsumerDir, stdio: "pipe" }
    );

    console.log("   Building Framework Consumer via vite build (Tailwind CSS v4)...");
    const viteBuildProc = spawnSync("npm", ["run", "build"], {
      cwd: appConsumerDir,
      stdio: "pipe",
      encoding: "utf8",
    });
    if (viteBuildProc.status !== 0) {
      console.error(viteBuildProc.stderr);
      throw new Error(`Framework Consumer vite build failed (exit code: ${viteBuildProc.status})`);
    }
    console.log("   ✓ Framework Consumer built cleanly.");

    // Step 6: Install Stellar Loom theme into Astro/Starlight Reading Consumer
    console.log("7. Installing Stellar Loom theme into Reading Consumer fixture...");
    const docConsumerDir = join(scratchDir, "doc-consumer");
    await cp(CONSUMER_DOC_FIXTURE, docConsumerDir, {
      recursive: true,
      filter: (src) => !["node_modules", "dist", ".astro"].includes(basename(src)),
    });
    execFileSync("npm", ["ci", "--ignore-scripts"], { cwd: docConsumerDir, stdio: "pipe" });
    execFileSync(
      "npm",
      ["install", "--ignore-scripts", "--no-save", "--package-lock=false", slTarball],
      { cwd: docConsumerDir, stdio: "pipe" }
    );

    console.log("   Building Reading Consumer via astro build...");
    const astroBuildProc = spawnSync("npm", ["exec", "--", "astro", "build"], {
      cwd: docConsumerDir,
      env: {
        ...process.env,
        CONSUMER_SCENARIO: "reading",
        THEME_PACKAGE_NAME: "@knowledge-forge-ai/starlight-theme-forge-console",
        ASTRO_OUT_DIR: join(docConsumerDir, "dist"),
      },
      stdio: "pipe",
      encoding: "utf8",
    });
    if (astroBuildProc.status !== 0) {
      console.error(astroBuildProc.stderr);
      throw new Error(`Reading Consumer astro build failed (exit code: ${astroBuildProc.status})`);
    }
    console.log("   ✓ Reading Consumer built cleanly.");

    // Step 7: Launch static HTTP servers and Playwright browser
    console.log("8. Starting local servers and launching Playwright Chromium...");
    srvApp = await startStaticServer(join(appConsumerDir, "dist"));
    srvDoc = await startStaticServer(join(docConsumerDir, "dist"));
    browser = await chromium.launch({ headless: true });
    const page = await browser.newPage();

    // -------------------------------------------------------------
    // Test A: Framework Consumer Assertions
    // -------------------------------------------------------------
    console.log("9. Executing Framework Consumer browser assertions...");
    await page.setViewportSize({ width: 1280, height: 800 });
    await page.goto(`http://127.0.0.1:${srvApp.port}/`);

    const lightBtnBg = await page.evaluate(() => {
      const btn = document.getElementById("theme-toggle-btn");
      return btn ? window.getComputedStyle(btn).backgroundColor : "";
    });
    console.log(`   Framework light primary button bg: ${lightBtnBg} (expected rgb(0, 168, 150))`);
    if (lightBtnBg !== "rgb(0, 168, 150)") {
      throw new Error(`Framework light primary color mismatch: expected rgb(0, 168, 150), got ${lightBtnBg}`);
    }
    metrics.frameworkConsumer.lightPrimaryBtnBg = lightBtnBg;

    const fwLightScreenshot = join(EVIDENCE_DIR, "framework-consumer-light.png");
    await page.screenshot({ path: fwLightScreenshot });
    metrics.evidenceFiles.push(fwLightScreenshot);

    // Toggle to Dark Mode
    await page.click("#theme-toggle-btn");
    await page.mouse.move(0, 0);
    await page.waitForFunction(() => document.documentElement.classList.contains("dark"));
    await page.waitForTimeout(350); // Allow transition-colors (150ms) to settle and clear hover state

    const darkBtnBg = await page.evaluate(() => {
      const btn = document.getElementById("theme-toggle-btn");
      return btn ? window.getComputedStyle(btn).backgroundColor : "";
    });
    console.log(`   Framework dark primary button bg: ${darkBtnBg} (expected rgb(2, 195, 154))`);
    if (darkBtnBg !== "rgb(2, 195, 154)") {
      throw new Error(`Framework dark primary color mismatch: expected rgb(2, 195, 154), got ${darkBtnBg}`);
    }
    metrics.frameworkConsumer.darkPrimaryBtnBg = darkBtnBg;

    const fwDarkScreenshot = join(EVIDENCE_DIR, "framework-consumer-dark.png");
    await page.screenshot({ path: fwDarkScreenshot });
    metrics.evidenceFiles.push(fwDarkScreenshot);

    // Check target override radius preservation (0.75rem)
    const computedRadius = await page.evaluate(() => {
      return window.getComputedStyle(document.documentElement).getPropertyValue("--radius").trim();
    });
    console.log(`   Framework target override --radius: ${computedRadius} (expected 0.75rem / .75rem)`);
    if (computedRadius !== "0.75rem" && computedRadius !== ".75rem") {
      throw new Error(`Framework Consumer target override radius mismatch: expected 0.75rem, got ${computedRadius}`);
    }
    metrics.frameworkConsumer.targetOverrideRadius = computedRadius;

    // Mobile Viewport
    await page.setViewportSize({ width: 390, height: 844 });
    const fwMobileScreenshot = join(EVIDENCE_DIR, "framework-consumer-mobile.png");
    await page.screenshot({ path: fwMobileScreenshot });
    metrics.evidenceFiles.push(fwMobileScreenshot);
    console.log("   ✓ Framework Consumer passed all assertions (#00a896 light, #02c39a dark, target override 0.75rem).");

    // -------------------------------------------------------------
    // Test B: Reading Consumer Assertions
    // -------------------------------------------------------------
    console.log("10. Executing Starlight Reading Consumer browser assertions...");
    await page.setViewportSize({ width: 1440, height: 900 });
    await page.goto(`http://127.0.0.1:${srvDoc.port}/`);

    // Light mode accent check
    await page.evaluate(() => {
      document.documentElement.dataset.theme = "light";
    });
    const lightLoomAccent = await page.evaluate(() => {
      const s = window.getComputedStyle(document.documentElement);
      return (
        s.getPropertyValue("--tfsl-color-accent-base").trim() ||
        s.getPropertyValue("--sl-color-accent").trim()
      );
    });
    console.log(`   Reading light accent: ${lightLoomAccent} (expected #00a896)`);
    if (lightLoomAccent !== "#00a896" && lightLoomAccent !== "rgb(0, 168, 150)") {
      throw new Error(`Reading Consumer light accent mismatch: expected #00a896, got ${lightLoomAccent}`);
    }
    metrics.readingConsumer.lightAccent = lightLoomAccent;

    // Check reading container width constraint (<= 704px)
    const containerMetrics = await page.evaluate(() => {
      const el = document.querySelector(".main-pane .sl-container") || document.querySelector(".sl-container");
      return el ? Math.round(el.getBoundingClientRect().width) : 0;
    });
    console.log(`   Reading container width: ${containerMetrics}px (expected <= 704px)`);
    if (containerMetrics > 704) {
      throw new Error(`Reading container exceeded 704px limit: ${containerMetrics}px`);
    }
    metrics.readingConsumer.containerWidth = containerMetrics;

    const docLightScreenshot = join(EVIDENCE_DIR, "reading-consumer-light.png");
    await page.screenshot({ path: docLightScreenshot });
    metrics.evidenceFiles.push(docLightScreenshot);

    // Dark mode accent check
    await page.evaluate(() => {
      document.documentElement.dataset.theme = "dark";
    });
    const darkLoomAccent = await page.evaluate(() => {
      const s = window.getComputedStyle(document.documentElement);
      return (
        s.getPropertyValue("--tfsl-color-accent-base").trim() ||
        s.getPropertyValue("--sl-color-accent").trim()
      );
    });
    console.log(`   Reading dark accent: ${darkLoomAccent} (expected #02c39a)`);
    if (darkLoomAccent !== "#02c39a" && darkLoomAccent !== "rgb(2, 195, 154)") {
      throw new Error(`Reading Consumer dark accent mismatch: expected #02c39a, got ${darkLoomAccent}`);
    }
    metrics.readingConsumer.darkAccent = darkLoomAccent;

    const docDarkScreenshot = join(EVIDENCE_DIR, "reading-consumer-dark.png");
    await page.screenshot({ path: docDarkScreenshot });
    metrics.evidenceFiles.push(docDarkScreenshot);

    // Mobile Viewport
    await page.setViewportSize({ width: 390, height: 844 });
    const docMobileScreenshot = join(EVIDENCE_DIR, "reading-consumer-mobile.png");
    await page.screenshot({ path: docMobileScreenshot });
    metrics.evidenceFiles.push(docMobileScreenshot);
    console.log("   ✓ Reading Consumer passed all assertions (#00a896 light, #02c39a dark, reading layout <= 704px).");

    console.log("=================================================================");
    console.log("✓ DUAL-CHAIN QUALIFICATION SUCCEEDED: #00a896 verified across both engines!");
    console.log(`  Evidence stored in: ${EVIDENCE_DIR}`);
    console.log("=================================================================");

    return {
      status: "passed",
      metrics,
    };
  } finally {
    if (browser) {
      await browser.close().catch(() => {});
    }
    if (srvApp) {
      await srvApp.close().catch(() => {});
    }
    if (srvDoc) {
      await srvDoc.close().catch(() => {});
    }
    await rm(scratchDir, { recursive: true, force: true }).catch(() => {});
  }
}

if (process.argv[1] === __filename) {
  runDualChainQualification().catch((err) => {
    console.error("FATAL:", err.stack || err.message);
    process.exit(1);
  });
}
