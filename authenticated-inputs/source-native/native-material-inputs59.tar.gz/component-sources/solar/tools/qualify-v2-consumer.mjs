/** Real packed v2 API and paired browser consumers; run only in the disposable lane. */
import assert from "node:assert/strict";
import {execFileSync} from "node:child_process";
import {createHash} from "node:crypto";
import {createServer} from "node:http";
import {readFile,writeFile,mkdir,mkdtemp,cp,rm,readdir} from "node:fs/promises";
import {existsSync} from "node:fs";
import {join,resolve,basename,extname,sep} from "node:path";
import {tmpdir} from "node:os";
import {fileURLToPath} from "node:url";
const root=resolve(import.meta.dirname,"../../..");
const ssRoot=join(root,"packages/solar-sail"), slRoot=join(root,"packages/stellar-loom");
const hash=x=>createHash("sha256").update(x).digest("hex");
const run=(cmd,args,cwd,env={})=>execFileSync(cmd,args,{cwd,env:{...process.env,...env},encoding:"utf8",timeout:120000,maxBuffer:8*1024*1024});
const npm=(args,cwd)=>run("npm",args,cwd);
const offline=["--offline","--cache","/npmcache","--ignore-scripts"];
async function pack(dir,out){const result=JSON.parse(npm(["pack","--json","--pack-destination",out],dir));return join(out,result[0].filename);}
async function writeFiles(dir,files){await mkdir(dir,{recursive:true});for(const [p,b] of files){await mkdir(join(dir,p,".."),{recursive:true});await writeFile(join(dir,p),b);}}
async function server(dir){
 const s=createServer(async(req,res)=>{try{let p=decodeURIComponent(new URL(req.url,"http://localhost").pathname);if(p.endsWith("/"))p+="index.html";const f=resolve(dir,"."+p);if(!f.startsWith(resolve(dir)+sep)){res.writeHead(403).end();return;}const b=await readFile(f);res.setHeader("content-type",({".html":"text/html",".css":"text/css",".js":"application/javascript",".svg":"image/svg+xml",".woff2":"font/woff2"})[extname(f)]??"application/octet-stream");res.end(b);}catch{res.writeHead(404).end();}});
 await new Promise(r=>s.listen(0,"127.0.0.1",r));return {url:`http://127.0.0.1:${s.address().port}/`,close:()=>new Promise((r,j)=>{s.closeAllConnections();s.close(e=>e?j(e):r());})};
}
export async function sourceInventory(dir){const entries=[];async function walk(d){for(const e of await readdir(d,{withFileTypes:true})){const f=join(d,e.name);if(e.isDirectory())await walk(f);else if(e.isFile())entries.push({path:f.slice(dir.length+1),sha256:hash(await readFile(f))});}}await walk(dir);return entries.sort((a,b)=>Buffer.compare(Buffer.from(a.path),Buffer.from(b.path)));}
export async function authorProfiles(ss){
 const original=await readFile(join(ssRoot,"examples/flexoki.profile.json"));
 const upgrade=ss.migrateV1ToV2(original);assert.equal(upgrade.isLossless,true);
 const flexoki=structuredClone(upgrade.profile);flexoki.radius={control:"8px",surface:"8px"};
 flexoki.typography={body:{family:"system-ui"},heading:{family:"system-ui"},code:{family:"monospace"}};
 flexoki.spacing={base:"8px",density:"comfortable"};flexoki.reading={measure:"704px"};
 flexoki.code={frame:"editor",copy:"standard",syntax:{light:{keyword:"#24837b"},dark:{keyword:"#3aa99f"}}};
 delete flexoki.targetOverrides;
 const material=structuredClone(flexoki);material.name="material-paired";material.radius={control:"12px",surface:"12px"};
 Object.assign(material.color.light,{canvas:"#fdf8fd",canvasText:"#1d1b20",surface:"#f7f2fa",surfaceText:"#1d1b20",primaryAction:"#6750a4",primaryActionText:"#ffffff",highlight:"#7d5260"});
 Object.assign(material.color.dark,{canvas:"#141218",canvasText:"#e6e1e5",surface:"#211f26",surfaceText:"#e6e1e5",primaryAction:"#d0bcff",primaryActionText:"#381e72",highlight:"#efb8c8"});
 material.spacing.density="compact";
 const changed=structuredClone(material);changed.name="material-control";changed.radius={control:"24px",surface:"24px"};changed.typography.heading.family="Georgia, serif";
 return {flexoki,material,changed};
}
export async function compilePair(ss,profile){
 const loom=await import(join(slRoot,"dist/index-catalog.js"));
 const catalog=JSON.parse(await readFile(join(slRoot,"examples/loom-flexoki-catalog.json"),"utf8"));
 catalog.catalog.sidebar={mode:"nested",groupIds:["guides"]};
 const bytes=ss.canonicalizeProfileV2(profile),bound=ss.bindSourceProfileV2(bytes);
 const mappingOptions={catalog,tokenSetKey:"flexoki-palette",primaryFamily:"cyan",secondaryFamily:"orange",defaultAccent:"cyan",familyBindings:{"system-ui":"system-sans","monospace":"system-mono","Georgia, serif":"system-serif"}};
 const solar=bound.mapToSolarSail(),stellar=bound.mapToStellarLoom(mappingOptions);
 const metadata={name:"@knowledge-forge-ai/app-theme-forge-console",version:"0.1.0",description:"B2 paired consumer",license:"AGPL-3.0-or-later"};
 const loomMetadata={...metadata,name:"@knowledge-forge-ai/starlight-theme-forge-console"};
 const ssOptions={themeSpec:solar.specification,metadata:metadata,language:"typescript"};
 const slOptions={themeSpec:stellar.catalog,metadata:loomMetadata,language:"javascript",accent:"cyan",strictContrast:false,sourceProfileSha256:bound.provenance.rawSourceSha256,syntaxPalette:stellar.syntax,readingLayout:true,bookChrome:{chapterNavigation:true,chapterProgress:true,keyboardShortcuts:true}};
 const solarPackage=ss.generateThemePackage(ssOptions),loomPackage=loom.generateThemePackageCatalog(slOptions);
 return {profile,bytes,bound,solar,stellar,mappingOptions,metadata,loomMetadata,ssOptions,slOptions,solarPackage,loomPackage};
}
export async function qualifyV2Consumer(){
 if(process.platform!=="linux"||process.env.CI!=="true"||!process.env.EVIDENCE_OUT)throw Error("Disposable Linux environment required");
 const out=join(process.env.EVIDENCE_OUT,"consumer");await mkdir(out,{recursive:true});
 const scratch=await mkdtemp(join(tmpdir(),"tfsb-b2-consumers-"));let browser;const servers=[];
 const receipt={schema:"tfsb71b2-consumer-v1",status:"running",cases:[],limitations:["System font stacks; no resolved external font or cross-platform pixel equivalence claim","Archive hashes identify this run, not reproducible npm archive bytes"]};
 try{
  const archive=await pack(ssRoot,scratch);receipt.compilerArchiveSha256=hash(await readFile(archive));
  const tool=join(scratch,"tool");await mkdir(tool);await writeFile(join(tool,"package.json"),JSON.stringify({private:true,type:"module"}));npm(["install","--no-save",...offline,archive],tool);
  const ss=await import(join(tool,"node_modules/@knowledge-forge-ai/theme-forge-solar-sail/dist/index.js"));
  for(const f of ["migrateV1ToV2","bindSourceProfileV2","canonicalizeProfileV2"])assert.equal(typeof ss[f],"function",`missing packed root export ${f}`);
  const profiles=await authorProfiles(ss);const {chromium}=await import("@playwright/test");browser=await chromium.launch({headless:true});
  for(const [id,profile] of Object.entries(profiles)){
   console.log(`Qualifying ${id}`);const pair=await compilePair(ss,profile);
   assert(pair.solar.report.entries.some(e=>e.sourcePath==="spacing.density"&&e.classification==="unsupported"));
   assert(pair.stellar.report.entries.some(e=>e.sourcePath==="code.syntax.light.keyword"&&["consumed","normalized"].includes(e.classification)));
   const record={id,sourceSha256:pair.bound.provenance.rawSourceSha256,reports:{solar:pair.solar.report,loom:pair.stellar.report},screenshots:[],measurements:[]};
   for(const [target,pkg] of [["solar",pair.solarPackage],["loom",pair.loomPackage]]){
    const dir=join(scratch,id+"-"+target+"-package");await writeFiles(dir,pkg.files);
    if(target==="solar")run(process.execPath,[join(ssRoot,"node_modules/typescript/bin/tsc"),"-p","tsconfig.json"],dir);
    const tar=await pack(dir,scratch);record[target+"ArchiveSha256"]=hash(await readFile(tar));
    const fixture=join(target==="solar"?ssRoot:slRoot,"consumer-fixture"),consumer=join(scratch,id+"-"+target+"-consumer");
    await cp(fixture,consumer,{recursive:true,filter:p=>!["node_modules","dist",".astro"].includes(basename(p))});
    npm(["ci",...offline],consumer);npm(["install","--no-save",...offline,tar],consumer);
    if(target==="solar")await writeFile(join(consumer,"src/App.tsx"),`import React from 'react';import './index.css';export function App(){return <main className="bg-background text-foreground font-sans" style={{minHeight:'100vh'}}><h1 id="title" className="font-heading">Paired profile</h1><button id="primary" className="bg-primary text-primary-foreground" style={{borderRadius:'var(--radius)'}}>Primary action</button><div id="surface" className="bg-card text-card-foreground" style={{borderRadius:'var(--radius)'}}>Surface</div></main>}export default App;`);
    if(target==="solar")npm(["run","build"],consumer);else run("npm",["exec","--","astro","build"],consumer,{CONSUMER_SCENARIO:"reading",THEME_PACKAGE_NAME:pair.loomMetadata.name,ASTRO_OUT_DIR:join(consumer,"dist")});
    const srv=await server(join(consumer,"dist"));servers.push(srv);const page=await browser.newPage();const errors=[];page.on("pageerror",e=>errors.push(e.message));page.on("requestfailed",r=>errors.push(r.failure()?.errorText??"request failed"));
    for(const width of [1280,390])for(const mode of ["light","dark"]){
     await page.setViewportSize({width,height:800});await page.goto(srv.url);
     await page.evaluate(({target,mode})=>{document.documentElement.classList.toggle('dark',mode==='dark');document.documentElement.dataset.theme=mode;}, {target,mode});
     const expected=profile.color[mode].primaryAction;
     if(target==="solar")await page.waitForFunction(expected=>{const rgb=expected.match(/../g).map(n=>parseInt(n,16));return getComputedStyle(document.querySelector('#primary')).backgroundColor===`rgb(${rgb.join(', ')})`;},expected.slice(1));
     const measurement=await page.evaluate(target=>{const root=getComputedStyle(document.documentElement);const el=target==='solar'?document.querySelector('#surface'):document.querySelector('.sl-link-card');return {accent:target==='solar'?getComputedStyle(document.querySelector('#primary')).backgroundColor:root.getPropertyValue('--tfsl-color-accent-base').trim(),radius:el?getComputedStyle(el).borderRadius:null,font:getComputedStyle(document.querySelector(target==='solar'?'#title':'h1')).fontFamily,overflow:document.documentElement.scrollWidth>innerWidth,reading:document.querySelector('.main-pane .sl-container')?.getBoundingClientRect().width??null,loomRadius:root.getPropertyValue('--tfsl-radius').trim()};},target);
     if(target==="solar"){assert.equal(measurement.radius,profile.radius.control);assert(measurement.font.includes(id==="changed"?"Georgia":"system-ui"));}
     else {assert([expected,`rgb(${expected.slice(1).match(/../g).map(n=>parseInt(n,16)).join(', ')})`].includes(measurement.accent));assert(measurement.reading>0&&measurement.reading<=704);assert.equal(measurement.loomRadius,profile.radius.surface);assert(measurement.font.includes(id==="changed"?"Georgia":"Segoe UI"));}
     assert.equal(measurement.overflow,false);record.measurements.push({target,width,mode,...measurement});
     const file=`${id}-${target}-${width}-${mode}.png`;await page.screenshot({path:join(out,file)});record.screenshots.push({path:file,sha256:hash(await readFile(join(out,file)))});
    }
    assert.deepEqual(errors,[]);await page.close();await srv.close();servers.splice(servers.indexOf(srv),1);
   }
   receipt.cases.push(record);
  }
  receipt.sources={solar:await sourceInventory(join(ssRoot,"src")),loom:await sourceInventory(join(slRoot,"src"))};receipt.status="passed";
 }finally{const cleanup=await Promise.allSettled([...servers.map(s=>s.close()),browser?.close()]);await rm(scratch,{recursive:true,force:true});assert(cleanup.every(r=>r.status==="fulfilled"));assert(!existsSync(scratch));}
 receipt.cleanup={scratchAbsent:true,browserClosed:true,serversClosed:true};await writeFile(join(out,"qualification.json"),JSON.stringify(receipt,null,2)+"\n");return receipt;
}
if(process.argv[1]===fileURLToPath(import.meta.url))qualifyV2Consumer().then(()=>console.log("B2 consumers passed"),e=>{console.error(e);process.exitCode=1;});
