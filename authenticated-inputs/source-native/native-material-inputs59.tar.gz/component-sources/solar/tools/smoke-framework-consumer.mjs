#!/usr/bin/env node
/**
 * Real Application Consumer Qualification Harness for TFSB67-R1.
 *
 * Verifies Deliverables A & C:
 * 1. Packs Solar Sail engine (@knowledge-forge-ai/theme-forge-solar-sail).
 * 2. Generates Forge Console theme in both JavaScript and TypeScript modes.
 * 3. Proves JS/TS parity: compiled CSS is bit-for-bit identical between modes.
 * 4. TypeScript build closure: compiles generated TS package in isolation via `npm run build` (tsc).
 * 5. TypeScript source provenance proof: performs disposable source edit/rebuild to prove
 *    that exported runtime is genuinely produced from TypeScript source.
 * 6. Packs the built TS theme package.
 * 7. Installs packed theme into an independent Vite + React + Tailwind CSS v4 + shadcn/ui consumer fixture.
 * 8. Executes real Tailwind compilation (`vite build`).
 * 9. Serves the built site over a local HTTP server and executes Playwright Chromium browser tests:
 *    - Light mode computed styles (palette roles, card background, primary button).
 *    - Dark mode interactive toggle (class="dark", dark palette roles).
 *    - Border radius geometry (button rounded-md, card rounded-lg).
 *    - Keyboard focus: simulates Tab key navigation and asserts focus-visible ring styles.
 *    - Responsive layout: desktop (1280x800) and mobile (390x844) viewport overflow checks.
 *    - Consumer custom CSS override precedence (#e11d48).
 *    - Meaningful changed-input control: alters theme token, rebuilds, and asserts browser style updates.
 * 10. Saves visual evidence to `docs/evaluations/evidence/tfsb67-r1/`.
 */

import { execFileSync, spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import { existsSync } from "node:fs";
import { createServer } from "node:http";
import { cp, mkdtemp, readFile, readdir, rm, stat, writeFile, mkdir } from "node:fs/promises";
import { tmpdir } from "node:os";
import { basename, dirname, extname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { chromium } from "@playwright/test";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const SOLAR_SAIL_ROOT = resolve(__dirname, "..");
const REPO_ROOT = resolve(SOLAR_SAIL_ROOT, "../..");
const CONSUMER_FIXTURE_DIR = resolve(SOLAR_SAIL_ROOT, "consumer-fixture");
const EVIDENCE_DIR = resolve(REPO_ROOT, "docs/evaluations/evidence/tfsb67-r1");
const THEME_SPEC_PATH = resolve(SOLAR_SAIL_ROOT, "examples/forge-console.theme.json");
const THEME_META_PATH = resolve(SOLAR_SAIL_ROOT, "examples/package-metadata.json");

function sha256(bufOrStr) {
  return createHash("sha256").update(bufOrStr).digest("hex");
}

function startStaticServer(rootDir, port = 0) {
  const MIME_TYPES = {
    ".html": "text/html",
    ".css": "text/css",
    ".js": "application/javascript",
    ".json": "application/json",
    ".svg": "image/svg+xml",
    ".png": "image/png",
  };

  const server = createServer(async (req, res) => {
    try {
      const url = new URL(req.url ?? "/", "http://127.0.0.1");
      let pathname = decodeURIComponent(url.pathname);
      if (pathname.endsWith("/")) {
        pathname += "index.html";
      } else if (!extname(pathname)) {
        pathname += "/index.html";
      }

      const filePath = resolve(rootDir, pathname.replace(/^\//, ""));
      if (!filePath.startsWith(resolve(rootDir))) {
        res.writeHead(403, { "Content-Type": "text/plain" });
        res.end("403 Forbidden");
        return;
      }
      if (!existsSync(filePath)) {
        res.writeHead(404, { "Content-Type": "text/plain" });
        res.end("404 Not Found");
        return;
      }

      const ext = extname(filePath);
      const mime = MIME_TYPES[ext] || "application/octet-stream";
      const content = await readFile(filePath);
      res.writeHead(200, { "Content-Type": mime });
      res.end(content);
    } catch (err) {
      res.writeHead(500, { "Content-Type": "text/plain" });
      res.end("500 Internal Server Error");
    }
  });

  return new Promise((resolvePromise) => {
    server.listen(port, "127.0.0.1", () => {
      const address = server.address();
      const actualPort = typeof address === "object" && address ? address.port : port;
      resolvePromise({
        port: actualPort,
        close: () =>
          new Promise((done) => {
            if (typeof server.closeAllConnections === "function") {
              server.closeAllConnections();
            }
            server.close(done);
          }),
      });
    });
  });
}

export async function runFrameworkConsumerQualification() {
  console.log("=== Deliverables A & C: Real Application Consumer Qualification ===");
  await mkdir(EVIDENCE_DIR, { recursive: true });

  const scratchDir = await mkdtemp(join(tmpdir(), "tfss-framework-consumer-"));
  console.log(`1. Isolated scratch directory: ${scratchDir}`);

  let browser;
  let srvApp;
  let ssTarballPath = null;

  const result = {
    deliverable: "Deliverables A & C — Real Application Consumer",
    status: "running",
    metrics: {},
    screenshots: {},
  };

  try {
    // Step 1: Pack Solar Sail
    console.log("2. Packing Solar Sail engine...");
    execFileSync("npm", ["run", "build"], { cwd: SOLAR_SAIL_ROOT, stdio: "inherit" });
    const ssPackRaw = execFileSync("npm", ["pack", "--json"], { cwd: SOLAR_SAIL_ROOT, encoding: "utf8" });
    const ssTarballName = JSON.parse(ssPackRaw)[0].filename;
    ssTarballPath = join(SOLAR_SAIL_ROOT, ssTarballName);
    console.log(`   Packed Solar Sail: ${ssTarballName}`);

    // Install packed TFSS into scratch tool environment
    const toolEnvDir = join(scratchDir, "tool-env");
    await mkdir(toolEnvDir, { recursive: true });
    await writeFile(join(toolEnvDir, "package.json"), JSON.stringify({ private: true, type: "module" }));
    execFileSync("npm", ["install", "--ignore-scripts", "--no-save", ssTarballPath], { cwd: toolEnvDir, stdio: "pipe" });
    const installedTfssBin = join(toolEnvDir, "node_modules/@knowledge-forge-ai/theme-forge-solar-sail/bin/tfss.js");

    // Step 2: Generate Themes in JS and TS Modes
    console.log("3. Generating Forge Console theme packages in JS and TS modes...");
    const jsThemeDir = join(scratchDir, "theme-js");
    const tsThemeDir = join(scratchDir, "theme-ts");

    execFileSync(process.execPath, [
      installedTfssBin,
      "generate",
      THEME_SPEC_PATH,
      "--package",
      THEME_META_PATH,
      "--out",
      jsThemeDir,
      "--language",
      "javascript",
      "--json",
    ]);

    execFileSync(process.execPath, [
      installedTfssBin,
      "generate",
      THEME_SPEC_PATH,
      "--package",
      THEME_META_PATH,
      "--out",
      tsThemeDir,
      "--language",
      "typescript",
      "--json",
    ]);

    // Step 3: JS/TS Parity Assertion (Finding B10 & Review Finding F10)
    console.log("4. Verifying JS/TS parity for equal semantic inputs...");
    const jsCss = await readFile(join(jsThemeDir, "styles/theme.css"), "utf8");
    const tsCss = await readFile(join(tsThemeDir, "styles/theme.css"), "utf8");
    if (jsCss !== tsCss) {
      throw new Error("CSS output mismatch between JavaScript and TypeScript generation modes");
    }
    console.log(`   ✓ JS/TS parity verified: CSS output is bit-for-bit identical (${Buffer.byteLength(jsCss)} bytes).`);

    const jsThemeJson = JSON.parse(await readFile(join(jsThemeDir, "theme.json"), "utf8"));
    const tsThemeJson = JSON.parse(await readFile(join(tsThemeDir, "theme.json"), "utf8"));
    if (JSON.stringify(jsThemeJson) !== JSON.stringify(tsThemeJson)) {
      throw new Error("theme.json mismatch between JavaScript and TypeScript generation modes");
    }

    // Verify TS src/index.ts inlined themeSpec matches theme.json exactly
    const tsSrcIndex = await readFile(join(tsThemeDir, "src/index.ts"), "utf8");
    const inlinedMatch = tsSrcIndex.match(/export const themeSpec: ThemeSpecification = ([\s\S]*?);\nexport const themeCss/);
    if (!inlinedMatch) {
      throw new Error("Failed to parse inlined themeSpec from src/index.ts");
    }
    const tsInlinedSpec = JSON.parse(inlinedMatch[1]);
    if (JSON.stringify(tsInlinedSpec) !== JSON.stringify(tsThemeJson)) {
      throw new Error("Spec divergence: inlined themeSpec in src/index.ts does not match theme.json");
    }
    console.log("   ✓ Spec parity verified: inlined TS themeSpec deep-equals theme.json and JS theme.json.");

    // Step 4: TypeScript Build Closure & Source Provenance Proof (Finding B11 & Review Finding F2)
    console.log("5. Exercising TypeScript build and verifying export provenance...");
    const tsPkgJson = JSON.parse(await readFile(join(tsThemeDir, "package.json"), "utf8"));
    if (!tsPkgJson.files?.includes("tsconfig.json")) {
      throw new Error("tsconfig.json is missing from package.json files list in TypeScript mode");
    }
    console.log("   ✓ TypeScript package manifest verified: tsconfig.json is included in files list.");

    execFileSync("npm", ["install", "--ignore-scripts"], { cwd: tsThemeDir, stdio: "pipe" });
    execFileSync("npm", ["run", "build"], { cwd: tsThemeDir, stdio: "pipe" });

    if (!existsSync(join(tsThemeDir, "dist/index.js")) || !existsSync(join(tsThemeDir, "dist/index.d.ts"))) {
      throw new Error("TypeScript compilation failed to produce dist/index.{js,d.ts}");
    }

    // Provenance rebuild check: disposable edit on src/index.ts
    const originalTsSource = await readFile(join(tsThemeDir, "src/index.ts"), "utf8");
    const marker = 'export const PROVENANCE_REBUILD_PROOF = "tfsb67-r1-provenance-verified";';
    await writeFile(join(tsThemeDir, "src/index.ts"), originalTsSource + "\n" + marker + "\n");
    execFileSync("npm", ["run", "build"], { cwd: tsThemeDir, stdio: "pipe" });

    const rebuiltJs = await readFile(join(tsThemeDir, "dist/index.js"), "utf8");
    if (!rebuiltJs.includes("PROVENANCE_REBUILD_PROOF")) {
      throw new Error("Disposable TypeScript rebuild did not propagate to exported dist/index.js");
    }
    console.log("   ✓ TypeScript source provenance verified: editing src/index.ts directly updates dist/index.js via tsc.");

    // Restore clean source and rebuild
    await writeFile(join(tsThemeDir, "src/index.ts"), originalTsSource);
    execFileSync("npm", ["run", "build"], { cwd: tsThemeDir, stdio: "pipe" });

    // Step 5: Pack Compiled TS Theme Package
    console.log("6. Packing compiled TypeScript theme package via npm pack...");
    const packThemeRaw = execFileSync("npm", ["pack", "--json"], { cwd: tsThemeDir, encoding: "utf8" });
    const themeTarballName = JSON.parse(packThemeRaw)[0].filename;
    const themeTarballPath = join(tsThemeDir, themeTarballName);
    console.log(`   Packed theme package: ${themeTarballName}`);

    // Verify tarball includes tsconfig.json
    const tarballContents = execFileSync("tar", ["-tf", themeTarballPath], { encoding: "utf8" });
    if (!tarballContents.includes("package/tsconfig.json")) {
      throw new Error("Packed theme tarball is missing package/tsconfig.json");
    }
    console.log("   ✓ Packed theme tarball verified: contains package/tsconfig.json.");

    // Step 6: Install into Independent Vite + React + Tailwind v4 Consumer Fixture
    console.log("7. Installing theme into independent Vite/React consumer fixture...");
    const consumerDir = join(scratchDir, "consumer-app");
    await cp(CONSUMER_FIXTURE_DIR, consumerDir, {
      recursive: true,
      filter: (src) => !["node_modules", "dist"].includes(basename(src)),
    });

    console.log("   Running npm ci in consumer fixture...");
    execFileSync("npm", ["ci", "--ignore-scripts"], { cwd: consumerDir, stdio: "pipe" });

    console.log("   Installing packed theme into consumer...");
    execFileSync("npm", ["install", "--ignore-scripts", "--no-save", "--package-lock=false", themeTarballPath], {
      cwd: consumerDir,
      stdio: "pipe",
    });

    // Step 7: Execute Real Tailwind Compilation via Vite Build
    console.log("8. Building application with Vite (compiling Tailwind CSS v4)...");
    const buildStartTime = Date.now();
    const viteBuildProc = spawnSync("npm", ["run", "build"], {
      cwd: consumerDir,
      stdio: "pipe",
      encoding: "utf8",
    });
    const buildDurationMs = Date.now() - buildStartTime;

    if (viteBuildProc.status !== 0) {
      console.error(viteBuildProc.stderr);
      throw new Error(`Vite build failed (exit code ${viteBuildProc.status})`);
    }
    if (!existsSync(join(consumerDir, "dist/index.html"))) {
      throw new Error("Vite build succeeded but dist/index.html is missing");
    }
    console.log(`   ✓ Vite build and Tailwind v4 compilation succeeded in ${buildDurationMs}ms.`);

    // Step 8: Playwright Headless Browser Assertions
    console.log("9. Launching Playwright Chromium for application consumer verification...");
    srvApp = await startStaticServer(join(consumerDir, "dist"));

    browser = await chromium.launch({ headless: true });
    const page = await browser.newPage();

    const browserErrors = [];
    const consoleErrors = [];
    const failedRequests = [];

    page.on("pageerror", (err) => {
      browserErrors.push(err.message || String(err));
    });
    page.on("console", (msg) => {
      if (msg.type() === "error") {
        consoleErrors.push(msg.text());
      }
    });
    page.on("requestfailed", (req) => {
      failedRequests.push(`${req.method()} ${req.url()} - ${req.failure()?.errorText || "failed"}`);
    });

    // -------------------------------------------------------------
    // Test A: Light Mode Computed Styles & Semantic Roles
    // -------------------------------------------------------------
    await page.setViewportSize({ width: 1280, height: 800 });
    await page.goto(`http://127.0.0.1:${srvApp.port}/`);

    const lightStyles = await page.evaluate(() => {
      const body = window.getComputedStyle(document.body);
      const card = window.getComputedStyle(document.getElementById("test-card"));
      const title = window.getComputedStyle(document.getElementById("card-title"));
      const btn = window.getComputedStyle(document.getElementById("theme-toggle-btn"));
      const secBtn = window.getComputedStyle(document.getElementById("action-btn"));
      const overrideEl = window.getComputedStyle(document.getElementById("override-marker"));
      const tokenOverrideBtn = window.getComputedStyle(document.getElementById("override-token-btn"));

      return {
        bodyBg: body.backgroundColor,
        bodyColor: body.color,
        cardBg: card.backgroundColor,
        cardColor: card.color,
        cardBorder: card.borderColor,
        cardRadius: card.borderRadius,
        titleColor: title.color,
        btnBg: btn.backgroundColor,
        btnColor: btn.color,
        btnRadius: btn.borderRadius,
        secBtnBg: secBtn.backgroundColor,
        overrideBg: overrideEl.backgroundColor,
        overrideBorder: overrideEl.borderColor,
        tokenOverrideBg: tokenOverrideBtn.backgroundColor,
      };
    });

    const lightScreenshotPath = join(EVIDENCE_DIR, "vite-app-light.png");
    await page.screenshot({ path: lightScreenshotPath });

    console.log(`   Light mode body background: ${lightStyles.bodyBg} (expected rgb(255, 248, 240))`);
    console.log(`   Light mode primary button bg: ${lightStyles.btnBg} (expected rgb(18, 100, 117))`);
    console.log(`   Light mode primary button radius: ${lightStyles.btnRadius} (expected 6.4px / engine scale)`);
    console.log(`   Light mode card radius: ${lightStyles.cardRadius} (expected 8px / 0.5rem)`);
    console.log(`   Consumer custom override bg: ${lightStyles.overrideBg} (expected rgb(225, 29, 72))`);
    console.log(`   Consumer cascade token override bg: ${lightStyles.tokenOverrideBg} (expected rgb(147, 51, 234))`);

    if (lightStyles.bodyBg !== "rgb(255, 248, 240)") throw new Error(`Unexpected light body bg: ${lightStyles.bodyBg}`);
    if (lightStyles.btnBg !== "rgb(18, 100, 117)") throw new Error(`Unexpected light button bg: ${lightStyles.btnBg}`);
    if (lightStyles.btnRadius !== "6.4px") throw new Error(`Unexpected button border radius: ${lightStyles.btnRadius} (expected 6.4px)`);
    if (lightStyles.cardRadius !== "8px") throw new Error(`Unexpected card border radius: ${lightStyles.cardRadius}`);
    if (lightStyles.overrideBg !== "rgb(225, 29, 72)") throw new Error(`Consumer custom CSS override failed: ${lightStyles.overrideBg}`);
    if (lightStyles.tokenOverrideBg !== "rgb(147, 51, 234)") {
      throw new Error(`Consumer cascade token override failed: ${lightStyles.tokenOverrideBg} (expected rgb(147, 51, 234))`);
    }
    console.log(`   ✓ Non-!important token override precedence verified: button inside consumer scope inherits overridden --primary.`);

    // Verify consumer executed imported TS runtime export (Review Finding F9)
    const activeThemeName = await page.evaluate(() => document.getElementById("theme-spec-marker")?.getAttribute("data-theme-name"));
    if (activeThemeName !== "forge-console") {
      throw new Error(`Consumer failed to execute TS-compiled runtime export: activeThemeName=${activeThemeName}`);
    }
    console.log(`   ✓ Consumer imported TS runtime export verified: theme "${activeThemeName}" active in DOM.`);

    // -------------------------------------------------------------
    // Test B: Interactive Dark Mode Toggle
    // -------------------------------------------------------------
    console.log("   Clicking theme toggle button for dark mode transition...");
    await page.click("#theme-toggle-btn");
    await page.mouse.move(0, 0);
    await page.waitForFunction(() => document.documentElement.classList.contains("dark"));
    await page.waitForTimeout(250); // Allow transition-colors (150ms) to settle

    const darkStyles = await page.evaluate(() => {
      const body = window.getComputedStyle(document.body);
      const card = window.getComputedStyle(document.getElementById("test-card"));
      const btn = window.getComputedStyle(document.getElementById("theme-toggle-btn"));

      return {
        bodyBg: body.backgroundColor,
        bodyColor: body.color,
        cardBg: card.backgroundColor,
        cardBorder: card.borderColor,
        btnBg: btn.backgroundColor,
        btnColor: btn.color,
      };
    });

    const darkScreenshotPath = join(EVIDENCE_DIR, "vite-app-dark.png");
    await page.screenshot({ path: darkScreenshotPath });

    console.log(`   Dark mode body background: ${darkStyles.bodyBg} (expected rgb(17, 19, 24))`);
    console.log(`   Dark mode primary button bg: ${darkStyles.btnBg} (expected rgb(105, 211, 228))`);

    if (darkStyles.bodyBg !== "rgb(17, 19, 24)") throw new Error(`Unexpected dark body bg: ${darkStyles.bodyBg}`);
    if (darkStyles.btnBg !== "rgb(105, 211, 228)") throw new Error(`Unexpected dark button bg: ${darkStyles.btnBg}`);

    // Return to light mode
    await page.click("#theme-toggle-btn");
    await page.mouse.move(0, 0);
    await page.waitForFunction(() => !document.documentElement.classList.contains("dark"));
    await page.waitForTimeout(250); // Allow transition-colors (150ms) to settle

    // -------------------------------------------------------------
    // Test C: Keyboard Tab Focus & :focus-visible Ring (Review Finding F3)
    // -------------------------------------------------------------
    console.log("   Simulating keyboard Tab navigation for focus-visible test...");
    // Tab from #theme-toggle-btn into #action-btn
    await page.keyboard.press("Tab");
    const activeElementId = await page.evaluate(() => document.activeElement?.id);
    const activeElementTag = await page.evaluate(() => document.activeElement?.tagName);
    console.log(`   Active element after Tab: <${activeElementTag} id="${activeElementId}">`);

    const focusStyles = await page.evaluate(() => {
      const el = document.activeElement;
      if (!el) return null;
      const s = window.getComputedStyle(el);
      return {
        id: el.id,
        outline: s.outline,
        outlineColor: s.outlineColor,
        outlineStyle: s.outlineStyle,
        outlineWidth: s.outlineWidth,
        boxShadow: s.boxShadow,
      };
    });

    const focusScreenshotPath = join(EVIDENCE_DIR, "vite-app-focus.png");
    await page.screenshot({ path: focusScreenshotPath });

    console.log(`   Focus styles for #${focusStyles?.id}: boxShadow="${focusStyles?.boxShadow}", outline="${focusStyles?.outline}"`);
    if (activeElementId !== "action-btn") {
      throw new Error(`Expected Tab navigation to focus #action-btn, got <${activeElementTag} id="${activeElementId}">`);
    }
    const hasFocusRing = (focusStyles?.boxShadow && focusStyles.boxShadow !== "none") ||
                         (focusStyles?.outlineStyle && focusStyles.outlineStyle !== "none");
    if (!hasFocusRing) {
      throw new Error(`Expected focus-visible ring or outline on active element, got boxShadow="${focusStyles?.boxShadow}", outline="${focusStyles?.outline}"`);
    }
    console.log(`   ✓ Keyboard focus-visible ring verified: #${activeElementId} has active ring.`);

    // -------------------------------------------------------------
    // Test D: Viewport Stability (Desktop 1280x800 and Mobile 390x844)
    // -------------------------------------------------------------
    const desktopScrollWidth = await page.evaluate(() => document.documentElement.scrollWidth);
    if (desktopScrollWidth > 1280) throw new Error(`Horizontal overflow on desktop: scrollWidth ${desktopScrollWidth} > 1280`);

    await page.setViewportSize({ width: 390, height: 844 });
    const mobileScrollWidth = await page.evaluate(() => document.documentElement.scrollWidth);
    if (mobileScrollWidth > 390) throw new Error(`Horizontal overflow on mobile: scrollWidth ${mobileScrollWidth} > 390`);

    const mobileScreenshotPath = join(EVIDENCE_DIR, "vite-app-mobile.png");
    await page.screenshot({ path: mobileScreenshotPath });
    console.log(`   Responsive viewports verified: desktop scrollWidth ${desktopScrollWidth}px, mobile scrollWidth ${mobileScrollWidth}px.`);

    // Assert browser error and network request failure state (Review Finding F5)
    if (browserErrors.length > 0) {
      throw new Error(`Browser uncaught errors encountered: ${browserErrors.join("; ")}`);
    }
    if (failedRequests.length > 0) {
      throw new Error(`Failed network requests encountered: ${failedRequests.join("; ")}`);
    }
    console.log(`   ✓ Browser error monitoring verified: 0 uncaught errors, 0 failed requests.`);

    // -------------------------------------------------------------
    // Test E: Meaningful Changed-Input Control (Section 3 Requirement)
    // -------------------------------------------------------------
    console.log("10. Testing meaningful changed-input control (altering token in spec)...");
    const changedSpec = JSON.parse(await readFile(THEME_SPEC_PATH, "utf8"));
    // Change light primary color from #126475 to #0d9488 (teal)
    changedSpec.palette.light.primary = "#0d9488";
    const changedSpecPath = join(scratchDir, "changed-spec.json");
    await writeFile(changedSpecPath, JSON.stringify(changedSpec, null, 2));

    const changedThemeDir = join(scratchDir, "theme-changed-ts");
    execFileSync(process.execPath, [
      installedTfssBin,
      "generate",
      changedSpecPath,
      "--package",
      THEME_META_PATH,
      "--out",
      changedThemeDir,
      "--language",
      "typescript",
      "--json",
    ]);

    execFileSync("npm", ["install", "--ignore-scripts"], { cwd: changedThemeDir, stdio: "pipe" });
    execFileSync("npm", ["run", "build"], { cwd: changedThemeDir, stdio: "pipe" });
    const packChangedRaw = execFileSync("npm", ["pack", "--json"], { cwd: changedThemeDir, encoding: "utf8" });
    const changedTarballPath = join(changedThemeDir, JSON.parse(packChangedRaw)[0].filename);

    // Install into a disposable changed consumer copy
    const changedConsumerDir = join(scratchDir, "consumer-changed");
    await cp(CONSUMER_FIXTURE_DIR, changedConsumerDir, {
      recursive: true,
      filter: (src) => !["node_modules", "dist"].includes(basename(src)),
    });
    execFileSync("npm", ["ci", "--ignore-scripts"], { cwd: changedConsumerDir, stdio: "pipe" });
    execFileSync("npm", ["install", "--ignore-scripts", "--no-save", "--package-lock=false", changedTarballPath], {
      cwd: changedConsumerDir,
      stdio: "pipe",
    });
    execFileSync("npm", ["run", "build"], { cwd: changedConsumerDir, stdio: "pipe" });

    const srvChanged = await startStaticServer(join(changedConsumerDir, "dist"));
    try {
      await page.setViewportSize({ width: 1280, height: 800 });
      await page.goto(`http://127.0.0.1:${srvChanged.port}/`);
      const changedBtnBg = await page.evaluate(() => {
        return window.getComputedStyle(document.getElementById("theme-toggle-btn")).backgroundColor;
      });
      console.log(`   Changed token primary button bg: ${changedBtnBg} (expected rgb(13, 148, 136))`);
      if (changedBtnBg !== "rgb(13, 148, 136)") {
        throw new Error(`Changed-input control failed: expected rgb(13, 148, 136), got ${changedBtnBg}`);
      }
      console.log("   ✓ Changed-input control verified: modifying theme token propagated to rebuilt consumer browser value.");
    } finally {
      await srvChanged.close();
    }

    result.status = "passed";
    result.metrics = {
      lightBodyBg: lightStyles.bodyBg,
      lightPrimaryBtnBg: lightStyles.btnBg,
      lightCardRadius: lightStyles.cardRadius,
      buttonRadiusComputed: lightStyles.btnRadius,
      darkBodyBg: darkStyles.bodyBg,
      darkPrimaryBtnBg: darkStyles.btnBg,
      focusActiveElement: activeElementId,
      focusStyles,
      browserErrorsCount: browserErrors.length,
      failedRequestsCount: failedRequests.length,
      consumerOverrideBg: lightStyles.overrideBg,
      desktopScrollWidth,
      mobileScrollWidth,
      changedControlObserved: "rgb(13, 148, 136)",
      buildDurationMs,
    };
    result.screenshots = {
      appLight: { path: lightScreenshotPath, sha256: sha256(await readFile(lightScreenshotPath)) },
      appDark: { path: darkScreenshotPath, sha256: sha256(await readFile(darkScreenshotPath)) },
      appFocus: { path: focusScreenshotPath, sha256: sha256(await readFile(focusScreenshotPath)) },
      appMobile: { path: mobileScreenshotPath, sha256: sha256(await readFile(mobileScreenshotPath)) },
    };

    console.log("\n=== Deliverables A & C Application Consumer Qualification PASSED Successfully ===");
    return result;
  } finally {
    if (browser) await browser.close().catch(() => {});
    if (srvApp) await srvApp.close().catch(() => {});
    if (ssTarballPath) await rm(ssTarballPath, { force: true }).catch(() => {});
    await rm(scratchDir, { recursive: true, force: true }).catch(() => {});
  }
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  runFrameworkConsumerQualification().then(
    (res) => {
      console.log(JSON.stringify(res, null, 2));
      process.exit(0);
    },
    (err) => {
      console.error("FATAL: Framework Consumer Qualification failed:", err);
      process.exit(1);
    }
  );
}
