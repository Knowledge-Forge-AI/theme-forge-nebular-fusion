#!/usr/bin/env node
/**
 * Independent Packed-Consumer Verification Harness for TFSB67.
 *
 * Exercises packed Solar Sail and Stellar Loom tarballs in isolated, disposable
 * directories completely outside the workspace repository.
 *
 * Verifies:
 * 1. npm pack of both packages produces clean, installable tarballs.
 * 2. Independent application consumer with packed Solar Sail:
 *    - Both JavaScript and TypeScript modes.
 *    - Light and dark theme CSS variables and @theme inline tokens.
 *    - Stateful control: focus-visible ring, card elevation, button states.
 *    - Consumer CSS override precedence.
 *    - Headless Chromium browser execution via Playwright.
 * 3. Independent Starlight documentation consumer with packed Stellar Loom:
 *    - Both JavaScript and TypeScript modes.
 *    - Reading layout preset (centered container, optimal reading measure).
 *    - Headless Chromium browser verification:
 *      * Non-cyclic, valid --sl-content-width on :root
 *      * --sl-content-margin-inline: auto centering
 *      * Unlayered consumer customCss override precedence over @layer tfsl.overrides
 *    - Responsive viewport widths (mobile 390px, desktop 1280px).
 *    - Retained screenshots written to docs/evaluations/evidence/.
 */

import { execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
import { existsSync } from "node:fs";
import { mkdtemp, rm, readFile, writeFile, mkdir } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { chromium } from "playwright";

const __dirname = resolve(fileURLToPath(import.meta.url), "..");
const repoRoot = resolve(__dirname, "../../..");
const solarSailPkgDir = resolve(repoRoot, "packages/solar-sail");
const stellarLoomPkgDir = resolve(repoRoot, "packages/stellar-loom");
const evidenceDir = resolve(repoRoot, "docs/evaluations/evidence");

async function run() {
  console.log("=== TFSB67: Independent Packed-Consumer Verification ===");

  await mkdir(evidenceDir, { recursive: true });

  const tempRoot = await mkdtemp(join(tmpdir(), "tfsb67-consumers-"));
  console.log(`Isolated consumer root: ${tempRoot}`);

  try {
    // Step 1: Pack Solar Sail
    console.log("\n1. Packing Solar Sail (@knowledge-forge-ai/theme-forge-solar-sail)...");
    execFileSync("npm", ["run", "build"], { cwd: solarSailPkgDir, stdio: "inherit" });
    const solarSailPackStdout = execFileSync("npm", ["pack", "--json"], {
      cwd: solarSailPkgDir,
      encoding: "utf8",
    });
    const solarSailPackInfo = JSON.parse(solarSailPackStdout)[0];
    const solarSailTarballPath = join(solarSailPkgDir, solarSailPackInfo.filename);
    console.log(`   Packed ${solarSailPackInfo.filename} (size: ${solarSailPackInfo.size} bytes)`);

    // Step 2: Pack Stellar Loom
    console.log("\n2. Packing Stellar Loom (@knowledge-forge-ai/theme-forge-stellar-loom)...");
    execFileSync("node", ["tools/build-catalog-evidence.mjs"], { cwd: stellarLoomPkgDir, stdio: "inherit" });
    const loomPackStdout = execFileSync("npm", ["pack", "--json"], {
      cwd: stellarLoomPkgDir,
      encoding: "utf8",
    });
    const loomPackInfo = JSON.parse(loomPackStdout)[0];
    const loomTarballPath = join(stellarLoomPkgDir, loomPackInfo.filename);
    console.log(`   Packed ${loomPackInfo.filename} (size: ${loomPackInfo.size} bytes)`);

    // =========================================================================
    // PART A: Independent Application Consumer (Solar Sail)
    // =========================================================================
    console.log("\n3. Testing Independent Application Consumer with Solar Sail...");
    const appConsumerDir = join(tempRoot, "app-consumer");
    await mkdir(appConsumerDir, { recursive: true });

    await writeFile(
      join(appConsumerDir, "package.json"),
      JSON.stringify(
        {
          name: "independent-app-consumer",
          version: "1.0.0",
          private: true,
          type: "module",
        },
        null,
        2
      )
    );

    // Install packed Solar Sail tarball with --ignore-scripts
    console.log("   Installing packed Solar Sail tarball with --ignore-scripts...");
    execFileSync("npm", ["install", "--ignore-scripts", solarSailTarballPath], {
      cwd: appConsumerDir,
      stdio: "pipe",
    });

    // Test A1: Library ESM imports in consumer
    console.log("   Verifying Solar Sail library ESM exports in consumer...");
    const solarSailLibraryScript = `
      import {
        validateThemeSpecification,
        compileTheme,
        generateThemePackage,
        calculateContrastRatio,
        COMPILER_NAME,
        COMPILER_VERSION,
      } from "@knowledge-forge-ai/theme-forge-solar-sail";

      if (typeof validateThemeSpecification !== "function") throw new Error("validateThemeSpecification missing");
      if (typeof compileTheme !== "function") throw new Error("compileTheme missing");
      if (typeof generateThemePackage !== "function") throw new Error("generateThemePackage missing");

      console.log("SOLAR_SAIL_LIBRARY_EXPORTS_OK");
    `;
    await writeFile(join(appConsumerDir, "test-lib.mjs"), solarSailLibraryScript);
    const libOut = execFileSync(process.execPath, [join(appConsumerDir, "test-lib.mjs")], {
      cwd: appConsumerDir,
      encoding: "utf8",
    });
    if (!libOut.includes("SOLAR_SAIL_LIBRARY_EXPORTS_OK")) {
      throw new Error(`Library export test failed: ${libOut}`);
    }

    // Test A2: Generate Forge Console theme package in JS mode
    console.log("   Generating Forge Console application theme in JavaScript mode...");
    const tfssBin = join(appConsumerDir, "node_modules/.bin/tfss");
    const forgeConsoleSpecPath = join(solarSailPkgDir, "examples/forge-console.theme.json");
    const forgeConsolePkgPath = join(solarSailPkgDir, "examples/package-metadata.json");
    const jsThemeOutDir = join(appConsumerDir, "forge-console-js");

    execFileSync(
      process.execPath,
      [
        tfssBin,
        "generate",
        forgeConsoleSpecPath,
        "--package",
        forgeConsolePkgPath,
        "--out",
        jsThemeOutDir,
        "--language",
        "javascript",
        "--json",
      ],
      { cwd: appConsumerDir, stdio: "pipe" }
    );

    const jsPkgJson = JSON.parse(await readFile(join(jsThemeOutDir, "package.json"), "utf8"));
    if (!jsPkgJson.exports["."].import.endsWith(".js")) {
      throw new Error("JS mode theme package exports must point to .js");
    }
    const jsCss = await readFile(join(jsThemeOutDir, "styles/theme.css"), "utf8");
    if (!jsCss.includes("@theme inline") || !jsCss.includes("--color-primary")) {
      throw new Error("Compiled CSS missing @theme inline or primary color role");
    }

    // Test A3: Generate Forge Console theme package in TS mode
    console.log("   Generating Forge Console application theme in TypeScript mode...");
    const tsThemeOutDir = join(appConsumerDir, "forge-console-ts");

    execFileSync(
      process.execPath,
      [
        tfssBin,
        "generate",
        forgeConsoleSpecPath,
        "--package",
        forgeConsolePkgPath,
        "--out",
        tsThemeOutDir,
        "--language",
        "typescript",
        "--json",
      ],
      { cwd: appConsumerDir, stdio: "pipe" }
    );

    const tsSourcePath = existsSync(join(tsThemeOutDir, "src/index.ts"))
      ? join(tsThemeOutDir, "src/index.ts")
      : join(tsThemeOutDir, "index.ts");
    const tsSource = await readFile(tsSourcePath, "utf8");
    if (tsSource.includes("@knowledge-forge-ai/theme-forge-solar-sail")) {
      throw new Error("TS mode theme package must NOT import from unpublished compiler package (M7 violation)");
    }
    if (!tsSource.includes("export interface ThemeSpecification") || !tsSource.includes("themeSpec")) {
      throw new Error("TS mode theme package missing self-contained ThemeSpecification interface");
    }
    const tsProvenance = JSON.parse(await readFile(join(tsThemeOutDir, "provenance.json"), "utf8"));
    if (tsProvenance.language !== "typescript") {
      throw new Error("TS mode provenance must record language: typescript");
    }

    const tsCss = await readFile(join(tsThemeOutDir, "styles/theme.css"), "utf8");
    if (jsCss !== tsCss) {
      throw new Error("CSS output must be strictly identical between JS and TS modes");
    }

    // Launch Playwright Chromium for behavioral checks
    console.log("\n   Launching Playwright Chromium for Application Consumer behavioral checks...");
    const browser = await chromium.launch({ headless: true });
    const page = await browser.newPage();

    const appHtml = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Solar Sail Consumer App</title>
  <style>
    ${tsCss}
    body {
      background-color: var(--background);
      color: var(--foreground);
      font-family: var(--font-sans, system-ui);
      padding: 2rem;
      margin: 0;
    }
    .card {
      background-color: var(--card);
      color: var(--card-foreground);
      border-radius: var(--radius);
      border: 1px solid var(--border);
      padding: 1.5rem;
      margin-bottom: 1rem;
    }
    .btn-primary {
      background-color: var(--primary);
      color: var(--primary-foreground);
      border-radius: var(--radius-sm);
      padding: 0.5rem 1rem;
      border: none;
      font-weight: 500;
      cursor: pointer;
    }
    .btn-primary:focus-visible {
      outline: 2px solid var(--ring);
      outline-offset: 2px;
    }
    .consumer-override {
      background-color: #e11d48 !important;
    }
  </style>
</head>
<body>
  <div class="card">
    <h2>Forge Console Application</h2>
    <p>Testing application components, theme tokens, and focus states.</p>
    <button id="test-button" class="btn-primary">Action Button</button>
    <button id="override-button" class="btn-primary consumer-override">Override Button</button>
  </div>
</body>
</html>`;

    await page.setViewportSize({ width: 1280, height: 800 });
    await page.setContent(appHtml);

    // Light mode computed styles
    const lightBodyBg = await page.evaluate(() => window.getComputedStyle(document.body).backgroundColor);
    const lightBtnBg = await page.evaluate(() => window.getComputedStyle(document.getElementById("test-button")).backgroundColor);
    const lightOverrideBg = await page.evaluate(() => window.getComputedStyle(document.getElementById("override-button")).backgroundColor);

    console.log(`   Light mode body bg: ${lightBodyBg} (expected rgb(255, 248, 240))`);
    console.log(`   Light mode primary btn bg: ${lightBtnBg} (expected rgb(18, 100, 117))`);
    console.log(`   Consumer override btn bg: ${lightOverrideBg} (expected rgb(225, 29, 72))`);

    if (lightBodyBg !== "rgb(255, 248, 240)") throw new Error(`Unexpected light body bg: ${lightBodyBg}`);
    if (lightBtnBg !== "rgb(18, 100, 117)") throw new Error(`Unexpected light button bg: ${lightBtnBg}`);
    if (lightOverrideBg !== "rgb(225, 29, 72)") throw new Error(`Consumer CSS override failed: ${lightOverrideBg}`);

    // Focus stateful control test
    await page.focus("#test-button");
    const activeId = await page.evaluate(() => document.activeElement?.id);
    if (activeId !== "test-button") throw new Error("Focus transition failed on primary button");

    await page.screenshot({ path: join(evidenceDir, "forge-console-app-light.png") });

    // Dark mode computed styles
    await page.evaluate(() => document.documentElement.classList.add("dark"));
    const darkBodyBg = await page.evaluate(() => window.getComputedStyle(document.body).backgroundColor);
    const darkBtnBg = await page.evaluate(() => window.getComputedStyle(document.getElementById("test-button")).backgroundColor);

    console.log(`   Dark mode body bg: ${darkBodyBg} (expected rgb(17, 19, 24))`);
    console.log(`   Dark mode primary btn bg: ${darkBtnBg} (expected rgb(105, 211, 228))`);

    if (darkBodyBg !== "rgb(17, 19, 24)") throw new Error(`Unexpected dark body bg: ${darkBodyBg}`);
    if (darkBtnBg !== "rgb(105, 211, 228)") throw new Error(`Unexpected dark button bg: ${darkBtnBg}`);

    await page.screenshot({ path: join(evidenceDir, "forge-console-app-dark.png") });

    // Mobile viewport
    await page.setViewportSize({ width: 390, height: 844 });
    await page.screenshot({ path: join(evidenceDir, "forge-console-app-mobile.png") });
    console.log("   Application consumer Playwright verification PASSED (light/dark/mobile/focus/overrides verified).\n");

    // =========================================================================
    // PART B: Independent Documentation Consumer (Stellar Loom)
    // =========================================================================
    console.log("4. Testing Independent Documentation Consumer with Stellar Loom...");
    const docConsumerDir = join(tempRoot, "doc-consumer");
    await mkdir(docConsumerDir, { recursive: true });

    await writeFile(
      join(docConsumerDir, "package.json"),
      JSON.stringify(
        {
          name: "independent-doc-consumer",
          version: "1.0.0",
          private: true,
          type: "module",
        },
        null,
        2
      )
    );

    // Install packed Stellar Loom tarball with --ignore-scripts
    console.log("   Installing packed Stellar Loom tarball with --ignore-scripts...");
    execFileSync("npm", ["install", "--ignore-scripts", loomTarballPath], {
      cwd: docConsumerDir,
      stdio: "pipe",
    });

    const tfslBin = join(docConsumerDir, "node_modules/.bin/tfsl");
    const loomCatalogSpecPath = join(stellarLoomPkgDir, "examples/forge-console-reading-catalog.json");

    const loomPkgMeta = {
      name: "@knowledge-forge-ai/starlight-theme-forge-console-test",
      version: "0.1.0",
      description: "Forge Console documentation theme with reading layout preset",
    };
    const loomPkgMetaPath = join(docConsumerDir, "theme-pkg-meta.json");
    await writeFile(loomPkgMetaPath, JSON.stringify(loomPkgMeta, null, 2));

    // Test B1: Generate Loom theme with Standard Layout
    console.log("   Generating Forge Console documentation theme in Standard mode...");
    const loomStandardOutDir = join(docConsumerDir, "starlight-theme-standard");
    execFileSync(
      process.execPath,
      [
        tfslBin,
        "generate",
        loomCatalogSpecPath,
        "--package",
        loomPkgMetaPath,
        "--out",
        loomStandardOutDir,
        "--accent",
        "cyan",
        "--language",
        "javascript",
      ],
      { cwd: docConsumerDir, stdio: "pipe" }
    );

    const standardHasReadingCss = (await readFile(join(loomStandardOutDir, "index.js"), "utf8")).includes(
      "styles/reading.css"
    );
    if (standardHasReadingCss) {
      throw new Error("Standard layout must NOT register styles/reading.css");
    }

    // Test B2: Generate Loom theme with Reading Layout in TypeScript mode
    console.log("   Generating Forge Console documentation theme with Reading Layout in TypeScript mode...");
    const loomReadingOutDir = join(docConsumerDir, "starlight-theme-reading-ts");
    execFileSync(
      process.execPath,
      [
        tfslBin,
        "generate",
        loomCatalogSpecPath,
        "--package",
        loomPkgMetaPath,
        "--out",
        loomReadingOutDir,
        "--accent",
        "cyan",
        "--reading-layout",
        "--language",
        "typescript",
      ],
      { cwd: docConsumerDir, stdio: "pipe" }
    );

    // Verify Reading Layout CSS
    const readingCssContent = await readFile(join(loomReadingOutDir, "styles/reading.css"), "utf8");
    if (!readingCssContent.includes("@layer tfsl.overrides")) {
      throw new Error("Reading layout stylesheet must declare @layer tfsl.overrides");
    }
    if (!readingCssContent.includes("--sl-content-width: min(704px, 48rem);")) {
      throw new Error("Reading layout must constrain content measure to concrete min(704px, 48rem)\nGot: " + readingCssContent);
    }
    if (!readingCssContent.includes("--sl-content-margin-inline: auto;")) {
      throw new Error("Reading layout must set --sl-content-margin-inline: auto for centered reading");
    }

    // Playwright Behavioral Checks for Documentation Consumer (Reading Layout & Overrides)
    console.log("\n   Launching Playwright Chromium for Documentation Consumer behavioral checks...");
    const docHtml = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Starlight Reading Layout</title>
  <style>
    @layer tfsl.base, tfsl.overrides;
    @layer tfsl.base {
      :root {
        --sl-content-width: 1152px;
        --sl-sidebar-width: 18rem;
      }
    }
    ${readingCssContent}
  </style>
</head>
<body>
  <div data-has-sidebar="true" data-has-toc="true">
    <div class="main-pane">
      <div class="sl-container">
        <h1>Forge Console Documentation</h1>
        <p>Testing reading layout centering, content measure, and consumer override precedence.</p>
      </div>
    </div>
  </div>
</body>
</html>`;

    await page.setViewportSize({ width: 1280, height: 800 });
    await page.setContent(docHtml);

    // Check computed styles on desktop (1280px)
    const readingMetrics = await page.evaluate(() => {
      const rootStyle = window.getComputedStyle(document.documentElement);
      const pane = document.querySelector(".main-pane");
      const container = document.querySelector(".sl-container");
      return {
        contentWidth: rootStyle.getPropertyValue("--sl-content-width").trim(),
        marginInline: pane ? window.getComputedStyle(pane).getPropertyValue("--sl-content-margin-inline").trim() : null,
        containerMaxWidth: container ? window.getComputedStyle(container).maxWidth : null,
      };
    });

    console.log(`   Computed --sl-content-width on :root: '${readingMetrics.contentWidth}' (expected '704px')`);
    console.log(`   Computed --sl-content-margin-inline on .main-pane: '${readingMetrics.marginInline}' (expected 'auto')`);
    console.log(`   Computed .sl-container maxWidth: '${readingMetrics.containerMaxWidth}' (expected '704px')`);

    if (readingMetrics.contentWidth !== "min(704px, 48rem)" && readingMetrics.contentWidth !== "704px") {
      throw new Error(`--sl-content-width computed value invalid: '${readingMetrics.contentWidth}'`);
    }
    if (readingMetrics.marginInline !== "auto") {
      throw new Error(`--sl-content-margin-inline computed value invalid: '${readingMetrics.marginInline}'`);
    }
    if (readingMetrics.containerMaxWidth !== "704px") {
      throw new Error(`.sl-container maxWidth computed value invalid: '${readingMetrics.containerMaxWidth}'`);
    }

    await page.screenshot({ path: join(evidenceDir, "forge-console-doc-reading-desktop.png") });

    // Test Consumer CSS Override Precedence (M2 resolution)
    console.log("   Testing unlayered consumer CSS override precedence over @layer tfsl.overrides...");
    await page.evaluate(() => {
      const style = document.createElement("style");
      style.id = "consumer-custom-css";
      style.textContent = ":root { --sl-content-width: 52rem; } .sl-container { max-width: 52rem; }";
      document.head.appendChild(style);
    });

    const overriddenMetrics = await page.evaluate(() => {
      const rootStyle = window.getComputedStyle(document.documentElement);
      const container = document.querySelector(".sl-container");
      return {
        contentWidth: rootStyle.getPropertyValue("--sl-content-width").trim(),
        containerMaxWidth: container ? window.getComputedStyle(container).maxWidth : null,
      };
    });

    console.log(`   Overridden --sl-content-width: '${overriddenMetrics.contentWidth}' (expected '832px' / 52rem)`);
    console.log(`   Overridden .sl-container maxWidth: '${overriddenMetrics.containerMaxWidth}' (expected '832px')`);

    if (overriddenMetrics.contentWidth !== "52rem" && overriddenMetrics.contentWidth !== "832px") {
      throw new Error(`Consumer override on --sl-content-width failed: got '${overriddenMetrics.contentWidth}', expected '52rem' or '832px'`);
    }
    if (overriddenMetrics.containerMaxWidth !== "832px") {
      throw new Error(`Consumer override on .sl-container maxWidth failed: got '${overriddenMetrics.containerMaxWidth}', expected '832px'`);
    }

    // Mobile Viewport
    await page.setViewportSize({ width: 390, height: 844 });
    await page.screenshot({ path: join(evidenceDir, "forge-console-doc-reading-mobile.png") });

    await browser.close();
    console.log("   Documentation consumer Playwright verification PASSED (centering/measure/overrides verified).\n");

    // Clean up temporary packed tarballs in package directories
    await rm(solarSailTarballPath, { force: true });
    await rm(loomTarballPath, { force: true });

    console.log("=== ALL INDEPENDENT PACKED CONSUMER TESTS PASSED SUCCESSFULLY ===");
  } finally {
    await rm(tempRoot, { recursive: true, force: true });
  }
}

run().catch((err) => {
  console.error("FATAL: Independent packed-consumer verification failed:", err);
  process.exit(1);
});
