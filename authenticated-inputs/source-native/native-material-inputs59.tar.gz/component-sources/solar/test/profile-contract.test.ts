import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { createHash } from "node:crypto";
import {
  PAIRED_PROFILE_SCHEMA_VERSION,
  MAPPING_REPORT_SCHEMA_VERSION,
  validatePairedProfile,
  assertValidPairedProfile,
  generateMappingReport,
  mapProfileToSolarSail,
  mapProfileToSolarSailWithReport,
  mapProfileToStellarLoom,
  mapProfileToStellarLoomWithReport,
  mapProfileToSyntaxPalette,
  bindSourceProfile,
  fromUnverifiedProfile,
  canonicalizeProfile,
  parseThemeJson,
  StaleProvenanceError,
  PairedProfileValidationError,
  type PairedProfile,
} from "../src/profile.js";
import { SafeDataError } from "../src/input.js";
import { compileTheme } from "../src/compiler.js";
import { generateThemePackage } from "../src/emitter.js";
import { assertSafePreSerialization } from "../../stellar-loom/src/catalog/validator.js";

const SOLAR_SAIL_ROOT = resolve(import.meta.dirname, "..");
const REPO_ROOT = resolve(SOLAR_SAIL_ROOT, "../..");
const FLEXOKI_PROFILE_PATH = resolve(SOLAR_SAIL_ROOT, "examples/flexoki.profile.json");
const FORGE_PROFILE_PATH = resolve(SOLAR_SAIL_ROOT, "examples/forge-console.profile.json");

describe("Paired Profile v1 Strict Validation", () => {
  it("validates canonical Flexoki profile successfully", () => {
    const raw = readFileSync(FLEXOKI_PROFILE_PATH, "utf8");
    const profile = JSON.parse(raw);
    const result = validatePairedProfile(profile);

    expect(result.valid).toBe(true);
    expect(result.errors).toHaveLength(0);
    expect(result.profile).toBeDefined();
    expect(result.profile?.name).toBe("flexoki");
  });

  it("validates canonical Forge Console profile successfully", () => {
    const raw = readFileSync(FORGE_PROFILE_PATH, "utf8");
    const profile = JSON.parse(raw);
    const result = validatePairedProfile(profile);

    expect(result.valid).toBe(true);
    expect(result.errors).toHaveLength(0);
    expect(result.profile?.name).toBe("forge-console");
  });

  it("rejects non-object or array input", () => {
    expect(validatePairedProfile(null).valid).toBe(false);
    expect(validatePairedProfile([]).valid).toBe(false);
    expect(validatePairedProfile("profile").valid).toBe(false);
  });

  it("rejects invalid schemaVersion", () => {
    const raw = readFileSync(FORGE_PROFILE_PATH, "utf8");
    const profile = JSON.parse(raw);
    profile.schemaVersion = "tf-paired-profile-v2";

    const result = validatePairedProfile(profile);
    expect(result.valid).toBe(false);
    expect(result.errors.some((e) => e.includes("schemaVersion"))).toBe(true);
  });

  it("rejects invalid profile name or version", () => {
    const raw = readFileSync(FORGE_PROFILE_PATH, "utf8");
    const invalidName = JSON.parse(raw);
    invalidName.name = "Forge Console UPPERCASE";
    expect(validatePairedProfile(invalidName).valid).toBe(false);

    const invalidVer = JSON.parse(raw);
    invalidVer.version = "not-a-semver";
    expect(validatePairedProfile(invalidVer).valid).toBe(false);
  });

  it("rejects missing mandatory color role in palette", () => {
    const raw = readFileSync(FORGE_PROFILE_PATH, "utf8");
    const profile = JSON.parse(raw);
    delete profile.palette.light.primary;

    const result = validatePairedProfile(profile);
    expect(result.valid).toBe(false);
    expect(result.errors.some((e) => e.includes("palette.light.primary"))).toBe(true);
  });

  it("rejects invalid color string values", () => {
    const raw = readFileSync(FORGE_PROFILE_PATH, "utf8");
    const profile = JSON.parse(raw);
    profile.palette.dark.ring = "not-a-valid-hex-or-css-function";

    const result = validatePairedProfile(profile);
    expect(result.valid).toBe(false);
    expect(result.errors.some((e) => e.includes("palette.dark.ring"))).toBe(true);
  });

  it("rejects non-CSS surface radius", () => {
    const raw = readFileSync(FORGE_PROFILE_PATH, "utf8");
    const profile = JSON.parse(raw);
    profile.surfaces.radius = "curved";

    const result = validatePairedProfile(profile);
    expect(result.valid).toBe(false);
    expect(result.errors.some((e) => e.includes("surfaces.radius"))).toBe(true);
  });

  it("rejects invalid surface content measure", () => {
    const raw = readFileSync(FORGE_PROFILE_PATH, "utf8");
    const profile = JSON.parse(raw);
    profile.surfaces.content = -100;

    const result = validatePairedProfile(profile);
    expect(result.valid).toBe(false);
    expect(result.errors.some((e) => e.includes("surfaces.content"))).toBe(true);
  });

  it("rejects missing fontSans typography", () => {
    const raw = readFileSync(FORGE_PROFILE_PATH, "utf8");
    const profile = JSON.parse(raw);
    delete profile.typography.fontSans;

    const result = validatePairedProfile(profile);
    expect(result.valid).toBe(false);
    expect(result.errors.some((e) => e.includes("typography.fontSans"))).toBe(true);
  });

  it("fails closed on prototype pollution, symbols, and accessor properties", () => {
    const profile = JSON.parse(readFileSync(FORGE_PROFILE_PATH, "utf8"));

    // Symbol keys
    const symbolProfile = { ...profile, [Symbol("hack")]: true };
    expect(validatePairedProfile(symbolProfile).valid).toBe(false);

    // Accessors / getters
    const getterProfile = { ...profile };
    Object.defineProperty(getterProfile, "evil", {
      get() {
        return "trojan";
      },
      enumerable: true,
    });
    expect(validatePairedProfile(getterProfile).valid).toBe(false);

    // Non-enumerable properties
    const nonEnumProfile = { ...profile };
    Object.defineProperty(nonEnumProfile, "hidden", {
      value: "secret",
      enumerable: false,
    });
    expect(validatePairedProfile(nonEnumProfile).valid).toBe(false);
  });

  it("assertValidPairedProfile throws PairedProfileValidationError on invalid input", () => {
    expect(() => assertValidPairedProfile({ bad: true })).toThrow(PairedProfileValidationError);
  });
});

describe("Additive Truthful Mapping Report", () => {
  const profile: PairedProfile = JSON.parse(readFileSync(FLEXOKI_PROFILE_PATH, "utf8"));

  it("produces comprehensive mapping report for Solar Sail accounting for every leaf", () => {
    const report = generateMappingReport(profile, "solar-sail");

    expect(report.schema).toBe(MAPPING_REPORT_SCHEMA_VERSION);
    expect(report.target).toBe("solar-sail");
    expect(report.profileName).toBe("flexoki");

    // Every entry has classification, sourcePath, reason
    for (const entry of report.entries) {
      expect(entry.sourcePath).toBeTruthy();
      expect(entry.reason).toBeTruthy();
      expect([
        "consumed",
        "unsupported",
        "target-specific",
        "overridden",
        "normalized",
        "degraded",
      ]).toContain(entry.classification);
    }

    // Check unsupported surfaces.content for Solar Sail
    const contentEntry = report.entries.find((e) => e.sourcePath === "surfaces.content");
    expect(contentEntry).toBeDefined();
    expect(contentEntry?.classification).toBe("unsupported");

    // Check target-specific overrides classification
    const loomOverrideEntry = report.entries.find((e) => e.sourcePath.startsWith("targetOverrides.loom"));
    expect(loomOverrideEntry).toBeDefined();
    expect(loomOverrideEntry?.classification).toBe("target-specific");

    // Summary matches entries exactly
    const summary = report.summary;
    expect(summary.totalLeaves).toBe(report.entries.length);
    expect(summary.consumed).toBe(report.entries.filter((e) => e.classification === "consumed").length);
    expect(summary.unsupported).toBe(report.entries.filter((e) => e.classification === "unsupported").length);
    expect(summary.targetSpecific).toBe(report.entries.filter((e) => e.classification === "target-specific").length);
    expect(summary.overridden).toBe(report.entries.filter((e) => e.classification === "overridden").length);
  });

  it("records overridden surfaces.radius when targetOverrides.solarSail.surfaces.radius is present", () => {
    const mutated = structuredClone(profile);
    mutated.targetOverrides = {
      ...mutated.targetOverrides,
      solarSail: { surfaces: { radius: "1.25rem" } },
    };

    const report = generateMappingReport(mutated, "solar-sail");
    const radiusEntry = report.entries.find((e) => e.sourcePath === "surfaces.radius");
    expect(radiusEntry?.classification).toBe("overridden");
    expect(radiusEntry?.targetValue).toBe("1.25rem");

    const overrideEntry = report.entries.find((e) => e.sourcePath === "targetOverrides.solarSail.surfaces.radius");
    expect(overrideEntry?.classification).toBe("target-specific");
  });

  it("produces comprehensive mapping report for Stellar Loom accounting for every leaf", () => {
    const report = generateMappingReport(profile, "stellar-loom");

    expect(report.schema).toBe(MAPPING_REPORT_SCHEMA_VERSION);
    expect(report.target).toBe("stellar-loom");

    // Surfaces radius is unsupported in Loom catalog specification
    const radiusEntry = report.entries.find((e) => e.sourcePath === "surfaces.radius");
    expect(radiusEntry?.classification).toBe("unsupported");

    // Typography fontSans is unsupported in Loom catalog specification
    const typoEntry = report.entries.find((e) => e.sourcePath === "typography.fontSans");
    expect(typoEntry?.classification).toBe("unsupported");

    // Content is consumed
    const contentEntry = report.entries.find((e) => e.sourcePath === "surfaces.content");
    expect(contentEntry?.classification).toBe("consumed");

    // Palette roles not in Loom tokenSets are reported unsupported
    const popoverEntry = report.entries.find((e) => e.sourcePath === "palette.light.popover");
    expect(popoverEntry?.classification).toBe("unsupported");
  });

  it("mapProfileToSolarSailWithReport and mapProfileToStellarLoomWithReport return both spec and report", () => {
    const ssResult = mapProfileToSolarSailWithReport(profile);
    expect(ssResult.specification.schemaVersion).toBe("tfss.theme-v1");
    expect(ssResult.report.target).toBe("solar-sail");

    const slResult = mapProfileToStellarLoomWithReport(profile);
    expect(slResult.catalog.schemaVersion).toBe("tfsl.theme-v2");
    expect(slResult.report.target).toBe("stellar-loom");
  });
});

describe("Source-Aware API & Provenance Verification", () => {
  const profileRaw = readFileSync(FLEXOKI_PROFILE_PATH, "utf8");
  const canonicalDigest = createHash("sha256").update(profileRaw).digest("hex");

  it("binds actual source bytes and verifies matching expected digest", () => {
    const bound = bindSourceProfile(profileRaw, { expectedSha256: canonicalDigest });

    expect(bound.provenance.rawSourceSha256).toBe(canonicalDigest);
    expect(bound.provenance.verificationStatus).toBe("verified");
    expect(bound.provenance.isTransformed).toBe(false);
    expect(bound.provenance.byteLength).toBe(Buffer.byteLength(profileRaw, "utf8"));
    expect(bound.provenance.normalizedSha256).toMatch(/^[a-f0-9]{64}$/);
    expect(bound.profile.name).toBe("flexoki");
  });

  it("rejects stale provenance when expectedSha256 does not match actual bytes", () => {
    const staleHash = "0000000000000000000000000000000000000000000000000000000000000000";
    expect(() => bindSourceProfile(profileRaw, { expectedSha256: staleHash })).toThrow(
      StaleProvenanceError
    );
  });

  it("maintains distinct normalized identity for transformed profiles while marking provenance as transformed", () => {
    const bound = bindSourceProfile(profileRaw, { expectedSha256: canonicalDigest });
    const initialNormalized = bound.provenance.normalizedSha256;

    const transformed = bound.transform((draft) => {
      draft.palette.light.primary = "#112233";
    });

    expect(transformed.provenance.isTransformed).toBe(true);
    expect(transformed.provenance.verificationStatus).toBe("transformed");
    // Ancestor source hash preserved
    expect(transformed.provenance.parentSourceSha256).toBe(canonicalDigest);
    expect(transformed.mapToSolarSail().sourceProfileSha256).not.toBe(canonicalDigest);
    // Normalized hash must be distinct because semantic token changed
    expect(transformed.provenance.normalizedSha256).not.toBe(initialNormalized);
    expect(transformed.profile.palette.light.primary).toBe("#112233");
  });

  it("distinguishes raw source formatting from normalized identity", () => {
    const parsed = JSON.parse(profileRaw);
    const compactRaw = JSON.stringify(parsed);
    const formattedRaw = JSON.stringify(parsed, null, 4);

    const boundCompact = bindSourceProfile(compactRaw);
    const boundFormatted = bindSourceProfile(formattedRaw);

    // Raw hashes differ because whitespace differs
    expect(boundCompact.provenance.rawSourceSha256).not.toBe(
      boundFormatted.provenance.rawSourceSha256
    );

    // Normalized semantic hashes are strictly identical
    expect(boundCompact.provenance.normalizedSha256).toBe(
      boundFormatted.provenance.normalizedSha256
    );
  });

  it("fromUnverifiedProfile records unverified-assertion status", () => {
    const parsed = JSON.parse(profileRaw);
    const bound = fromUnverifiedProfile(parsed, { assertedSha256: "asserted-hash" });

    expect(bound.provenance.verificationStatus).toBe("unverified-assertion");
    expect(bound.provenance.rawSourceSha256).toBe("asserted-hash");
    expect(bound.provenance.isTransformed).toBe(false);
  });
});

describe("Embedded Hash Non-Trust and Loom Hidden Property Removal", () => {
  const profileRaw = readFileSync(FLEXOKI_PROFILE_PATH, "utf8");

  it("does not trust embedded sha256 or sourceProfileSha256 inside profile object", () => {
    const untrustedProfile = JSON.parse(profileRaw);
    untrustedProfile.sha256 = "spoofed-digest-1";
    untrustedProfile.sourceProfileSha256 = "spoofed-digest-2";

    expect(() => mapProfileToSolarSail(untrustedProfile)).toThrow(PairedProfileValidationError);
    const ssWithAssert = mapProfileToSolarSail(JSON.parse(profileRaw), { sourceProfileSha256: "a".repeat(64) });
    expect(ssWithAssert.sourceProfileSha256).toBe("a".repeat(64));
  });

  it("removes hidden Loom property and passes Loom assertSafePreSerialization", () => {
    const profile = JSON.parse(profileRaw);
    expect(() => mapProfileToStellarLoom(profile, {}, { sourceProfileSha256: "some-hash" })).toThrow(/compileThemeCatalog/);
    const mappedLoom = mapProfileToStellarLoom(profile);

    // No non-enumerable sourceProfileSha256 property on mapped catalog
    const desc = Object.getOwnPropertyDescriptor(mappedLoom, "sourceProfileSha256");
    expect(desc).toBeUndefined();

    // Must cleanly pass Loom's strict data safety assertion without ACCESSOR_FORBIDDEN
    expect(() => assertSafePreSerialization(mappedLoom)).not.toThrow();
  });

  it("preserves override-wins radius precedence for Solar Sail", () => {
    const profile: PairedProfile = JSON.parse(profileRaw);
    profile.surfaces.radius = "0.25rem";
    profile.targetOverrides = {
      solarSail: {
        surfaces: {
          radius: "1.0rem",
        },
      },
    };

    const ssSpec = mapProfileToSolarSail(profile);
    expect(ssSpec.surfaces.radius).toBe("1.0rem");
  });
});


describe("source binding and coverage adversarial regressions", () => {
  const raw = readFileSync(FLEXOKI_PROFILE_PATH, "utf8");
  it("cannot mutate nested bound input or carry a stale hash through a transform", () => {
    const bound = bindSourceProfile(raw);
    expect(() => { bound.profile.palette.light.primary = "#123456"; }).toThrow();
    const transformed = bound.transform(draft => { draft.palette.light.primary = "#123456"; });
    const bytes = canonicalizeProfile(transformed.profile);
    expect(transformed.mapToSolarSail().sourceProfileSha256).toBe(createHash("sha256").update(bytes).digest("hex"));
    expect(transformed.mapToStellarLoom().sourceProfileSha256).not.toBe(bound.provenance.rawSourceSha256);
  });
  it("reports every nested syntax leaf and unsupported own-target intent without claiming normalization", () => {
    const p = JSON.parse(raw); p.palette.light.primary = "#ABCDEF";
    p.targetOverrides.solarSail = { spacing: { unit: "1rem" } };
    const { specification, report } = mapProfileToSolarSailWithReport(p);
    expect(specification.palette.light.primary).toBe("#ABCDEF");
    expect(report.entries.find(e => e.sourcePath === "palette.light.primary")?.classification).toBe("consumed");
    expect(report.entries.find(e => e.sourcePath === "targetOverrides.solarSail.spacing.unit")?.classification).toBe("unsupported");
    expect(report.entries.find(e => e.sourcePath === "targetOverrides.syntax.syntax.light.comment")?.classification).toBe("target-specific");
    expect(() => mapProfileToSolarSail(p)).toThrow(/Unsupported/);
    expect(JSON.parse(JSON.stringify(report))).toEqual(report);
  });
});

describe("TFNC13 Studio document custody v1 owner contract pins", () => {
  const sidebar = {
    sidebar: "#111827",
    sidebarForeground: "#f9fafb",
    sidebarPrimary: "#2563eb",
    sidebarPrimaryForeground: "#ffffff",
    sidebarAccent: "#374151",
    sidebarAccentForeground: "#f3f4f6",
    sidebarBorder: "#4b5563",
    sidebarRing: "#60a5fa",
  };
  const sha256 = (text: string) => createHash("sha256").update(text, "utf8").digest("hex");

  function makeCustodyProfile(): PairedProfile {
    const profile: PairedProfile = JSON.parse(readFileSync(FORGE_PROFILE_PATH, "utf8"));
    profile.description = "Studio custody — café ☀";
    Object.assign(profile.palette.light, sidebar);
    Object.assign(profile.palette.dark, sidebar);
    profile.surfaces.content = 768;
    const syntax = mapProfileToSyntaxPalette(profile);
    syntax.syntax.light.keyword = "#123456";
    syntax.syntax.dark.keyword = "#abcdef";
    profile.targetOverrides = {
      solarSail: { surfaces: { radius: "0.75rem" } },
      loom: { primaryFamily: "cyan", secondaryFamily: "orange" },
      syntax,
    };
    return profile;
  }

  it.each(["string", "UTF-8 bytes"])("binds exact %s and preserves optional document intent in a frozen profile", (inputKind) => {
    const profile = makeCustodyProfile();
    // A content override is retained as document intent even though Solar Sail cannot map it.
    profile.targetOverrides!.solarSail = { surfaces: { radius: "0.75rem", content: 800 } };
    const raw = JSON.stringify(profile, null, 2) + "\n";
    const bound = bindSourceProfile(inputKind === "string" ? raw : Buffer.from(raw, "utf8"));

    expect(bound.profile.schemaVersion).toBe("tf-paired-profile-v1");
    expect(bound.profile).toEqual(profile);
    for (const mode of ["light", "dark"] as const) {
      expect(bound.profile.palette[mode]).toMatchObject(sidebar);
      expect(Object.isFrozen(bound.profile.palette[mode])).toBe(true);
    }
    expect(bound.profile.surfaces.content).toBe(768);
    expect(bound.profile.targetOverrides).toEqual(profile.targetOverrides);
    expect(Object.isFrozen(bound.profile)).toBe(true);
    expect(Object.isFrozen(bound.profile.targetOverrides?.syntax?.syntax?.light)).toBe(true);
    expect(Object.isFrozen(bound.provenance)).toBe(true);
    // Raw-byte binding is verified; fromUnverifiedProfile owns caller assertions.
    expect(bound.provenance.verificationStatus).toBe("verified");
    expect(bound.provenance.rawSourceSha256).toMatch(/^[0-9a-f]{64}$/);
    expect(bound.provenance.rawSourceSha256).toBe(sha256(raw));
    expect(bound.provenance.byteLength).toBe(Buffer.byteLength(raw, "utf8"));
    expect(bound.provenance.normalizedSha256).toMatch(/^[0-9a-f]{64}$/);
    expect(bound.provenance.normalizedSha256).toBe(sha256(canonicalizeProfile(bound.profile)));
  });

  it.each([
    ["duplicate name", '"name":"shadow-name",', "DUPLICATE_KEY"],
    ["escaped duplicate name", '"\\u006eame":"shadow-name",', "DUPLICATE_KEY"],
    ["__proto__", '"__proto__":{},', "FORBIDDEN_PROPERTY"],
    ["constructor", '"constructor":{},', "FORBIDDEN_PROPERTY"],
    ["prototype", '"prototype":{},', "FORBIDDEN_PROPERTY"],
  ])("rejects %s in both the parser and direct source binding", (_label, injected, code) => {
    const raw = JSON.stringify(makeCustodyProfile()).replace("{", `{${injected}`);
    // Both owner entrypoints use the duplicate-aware parser; JSON.parse alone loses duplicates.
    expect(() => JSON.parse(raw)).not.toThrow();
    for (const parse of [parseThemeJson, bindSourceProfile]) {
      expect(() => parse(raw)).toThrow(SafeDataError);
      expect(() => parse(raw)).toThrow(expect.objectContaining({ code }));
    }
  });

  it("resolves the legacy schema alias before binding and preserves normalized identity", () => {
    const profile = makeCustodyProfile();
    const raw = JSON.stringify(profile);
    const legacyRaw = raw.replace('"schemaVersion":', '"schema":');
    expect(() => bindSourceProfile(legacyRaw)).toThrow(PairedProfileValidationError);

    const resolved = parseThemeJson(legacyRaw) as Record<string, unknown>;
    expect(resolved.schema).toBe("tf-paired-profile-v1");
    resolved.schemaVersion = resolved.schema;
    delete resolved.schema;
    const canonical = bindSourceProfile(raw);
    const normalized = bindSourceProfile(JSON.stringify(resolved, null, 2));

    expect(normalized.profile).toEqual(canonical.profile);
    expect(normalized.provenance.normalizedSha256).toBe(canonical.provenance.normalizedSha256);
    expect(normalized.provenance.rawSourceSha256).not.toBe(canonical.provenance.rawSourceSha256);
  });

  it("compiles and generates an in-memory package with sidebar tokens and Loom overrides", () => {
    const profile = bindSourceProfile(JSON.stringify(makeCustodyProfile())).profile;
    const specification = mapProfileToSolarSail(profile);
    const compiled = compileTheme(specification);
    const metadata = JSON.parse(readFileSync(resolve(SOLAR_SAIL_ROOT, "examples/package-metadata.json"), "utf8"));
    const exported = generateThemePackage({ themeSpec: specification, metadata });

    expect(specification.surfaces.radius).toBe("0.75rem");
    expect(compiled.specification.palette.light).toMatchObject(sidebar);
    expect(compiled.specification.palette.dark).toMatchObject(sidebar);
    for (const [role, color] of Object.entries(sidebar)) {
      const cssName = role.replace(/[A-Z]/g, (letter) => `-${letter.toLowerCase()}`);
      expect(compiled.css).toContain(`--${cssName}: ${color};`);
    }
    expect(exported.files.get("styles/theme.css")).toBe(compiled.css);
    expect(exported.themeSpec.palette.light).toMatchObject(sidebar);
    expect(exported.themeSpec.palette.dark).toMatchObject(sidebar);
    expect(profile.targetOverrides?.loom).toEqual({ primaryFamily: "cyan", secondaryFamily: "orange" });
    expect(profile.targetOverrides?.syntax?.syntax?.light.keyword).toBe("#123456");
  });

  it("fails closed when mapping unsupported Solar Sail content override intent", () => {
    const profile = makeCustodyProfile();
    profile.targetOverrides!.solarSail = { surfaces: { content: 800 } };
    const bound = bindSourceProfile(JSON.stringify(profile));
    expect(bound.profile.targetOverrides?.solarSail).toEqual({ surfaces: { content: 800 } });
    expect(() => mapProfileToSolarSail(bound.profile)).toThrow(PairedProfileValidationError);
  });

  it("binds owner-valid v1 extension keys in targetOverrides and integer surfaces.content beyond u32", () => {
    const profile = makeCustodyProfile() as Record<string, any>;
    profile.surfaces.content = 5_000_000_000;
    profile.targetOverrides.loom = {
      ...profile.targetOverrides.loom,
      customLoomExtension: { enabled: true },
    };
    profile.targetOverrides.solarSail = {
      ...profile.targetOverrides.solarSail,
      customSolarSailExtension: "active",
    };
    profile.targetOverrides.syntax = {
      ...profile.targetOverrides.syntax,
      customSyntaxTopKey: "v1-ext",
      syntax: {
        ...profile.targetOverrides.syntax.syntax,
        customNestedSyntaxKey: "#112233",
      },
    };
    const raw = JSON.stringify(profile, null, 2) + "\n";
    const bound = bindSourceProfile(raw);

    expect(bound.provenance.verificationStatus).toBe("verified");
    expect(bound.provenance.isTransformed).toBe(false);
    expect(bound.provenance.rawSourceSha256).toBe(sha256(raw));
    expect(bound.provenance.normalizedSha256).toBe(sha256(canonicalizeProfile(bound.profile)));
    expect(bound.profile.surfaces.content).toBe(5_000_000_000);
    expect((bound.profile.targetOverrides?.loom as Record<string, unknown>)?.customLoomExtension).toEqual({
      enabled: true,
    });
    expect((bound.profile.targetOverrides?.solarSail as Record<string, unknown>)?.customSolarSailExtension).toBe(
      "active"
    );
  });

  it("records transformed provenance and parentSourceSha256 when transforming an edited child v1 document", () => {
    const parentProfile = makeCustodyProfile();
    const parentRaw = JSON.stringify(parentProfile, null, 2) + "\n";
    const parentBound = bindSourceProfile(parentRaw);
    expect(parentBound.provenance.verificationStatus).toBe("verified");
    expect(parentBound.provenance.isTransformed).toBe(false);
    expect(parentBound.provenance.parentSourceSha256).toBeUndefined();

    const childBound = parentBound.transform((draft) => {
      draft.name = "forge-console-edited-child";
    });
    const expectedCanonical = canonicalizeProfile(childBound.profile);

    expect(childBound.provenance.verificationStatus).toBe("transformed");
    expect(childBound.provenance.isTransformed).toBe(true);
    expect(childBound.provenance.parentSourceSha256).toBe(parentBound.provenance.rawSourceSha256);
    expect(childBound.provenance.rawSourceSha256).toBe(sha256(expectedCanonical));
    expect(childBound.provenance.normalizedSha256).toBe(sha256(expectedCanonical));
  });
});
