import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { createHash } from "node:crypto";
import {
  PAIRED_PROFILE_V2_SCHEMA_VERSION,
  bindSourceProfileV2,
  canonicalizeProfileV2,
  computeCanonicalDigestV2,
  mapProfileToSolarSailWithReportV2,
  mapProfileToStellarLoomWithReportV2,
  validatePairedProfileV2,
  type ColorModeTokensV2,
  type PairedProfileV2,
} from "../src/paired-v2/index.js";

const SOLAR_SAIL_ROOT = resolve(import.meta.dirname, "..");
const REAL_PROFILE_PATH = resolve(SOLAR_SAIL_ROOT, "../../themes/shadcn-terminal-nova/terminal-nova.profile.json");
const REAL_LOOM_CATALOG_PATH = resolve(SOLAR_SAIL_ROOT, "../../themes/terminal-nova/v0.3/terminal-nova.theme.json");

const PRE_MATERIAL_BASELINE = {
  source: {
    bytes: 2215,
    sha256: "11521e5ead9ba6cd589ecd7193c07d630e63f9fb9c639def67363da5ff648af0",
  },
  solar: {
    specification: { bytes: 1836, sha256: "93a8cf9039cfe1b262bdab511f0d8b4811eeb50bc54c8975f40016635857d1d0" },
    report: { bytes: 17048, sha256: "5943455b37aa8824ff412d58b3d7ef458bf667a8065ff03af10addc6b2c6e2e6" },
    defaults: { bytes: 3, sha256: "37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570" },
    reportDigest: "c908dc01d8e5a1000cc9cee021151c12972a4aa351ffb301f01b0736987194f6",
  },
  loom: {
    catalog: { bytes: 9178, sha256: "f298a655d25ced6c590a76bcf648874d8d42f792365f3722c210a4bc48bc28fc" },
    report: { bytes: 25205, sha256: "81e049057c6c50b50b722583a04379ea4a8ea67624b640eee6065b095faf0ae7" },
    defaults: { bytes: 237, sha256: "eea88a347923ce777817920f1cb21307fcb0918cbd6176cd316a3d742d7dbf6a" },
    reportDigest: "f9a427ebf3a96ce3ebd81e6d8ca8be0f5f89627268aebba8f1072bf854e90bfb",
  },
} as const;

function canonicalSha256(value: unknown): { bytes: number; sha256: string } {
  const canonical = canonicalizeProfileV2(value);
  return {
    bytes: Buffer.byteLength(canonical, "utf8"),
    sha256: createHash("sha256").update(canonical, "utf8").digest("hex"),
  };
}

function loadRealNoMaterialProfile(): PairedProfileV2 {
  return JSON.parse(readFileSync(REAL_PROFILE_PATH, "utf8")) as PairedProfileV2;
}

function realLoomOptions(profile: PairedProfileV2) {
  const loom = profile.targetOverrides!.loom!;
  return {
    catalog: JSON.parse(readFileSync(REAL_LOOM_CATALOG_PATH, "utf8")),
    tokenSetKey: loom.tokenSetKey!,
    primaryFamily: loom.primaryFamily!,
    secondaryFamily: loom.secondaryFamily!,
    defaultAccent: loom.defaultAccent!,
  };
}

function makeColors(values: Pick<ColorModeTokensV2, "canvas" | "canvasText" | "surface" | "surfaceText" | "elevatedSurface" | "elevatedSurfaceText" | "primaryAction" | "primaryActionText" | "secondaryAction" | "secondaryActionText" | "mutedSurface" | "mutedText" | "highlight" | "highlightText" | "danger" | "dangerText" | "border" | "fieldBorder" | "focus">): ColorModeTokensV2 {
  return values;
}

function makeBaseProfile(): PairedProfileV2 {
  return {
    schemaVersion: PAIRED_PROFILE_V2_SCHEMA_VERSION,
    name: "material-contract",
    version: "1.0.0",
    color: {
      light: makeColors({
        canvas: "#ffffff",
        canvasText: "#111111",
        surface: "#f8f8f8",
        surfaceText: "#111111",
        elevatedSurface: "#ffffff",
        elevatedSurfaceText: "#111111",
        primaryAction: "#0066cc",
        primaryActionText: "#ffffff",
        secondaryAction: "#e5e5e5",
        secondaryActionText: "#111111",
        mutedSurface: "#f0f0f0",
        mutedText: "#666666",
        highlight: "#ff9900",
        highlightText: "#000000",
        danger: "#cc0000",
        dangerText: "#ffffff",
        border: "#cccccc",
        fieldBorder: "#999999",
        focus: "#0066cc",
      }),
      dark: makeColors({
        canvas: "#111111",
        canvasText: "#ffffff",
        surface: "#1a1a1a",
        surfaceText: "#ffffff",
        elevatedSurface: "#222222",
        elevatedSurfaceText: "#ffffff",
        primaryAction: "#3399ff",
        primaryActionText: "#000000",
        secondaryAction: "#333333",
        secondaryActionText: "#ffffff",
        mutedSurface: "#222222",
        mutedText: "#999999",
        highlight: "#ffaa33",
        highlightText: "#000000",
        danger: "#ff3333",
        dangerText: "#ffffff",
        border: "#444444",
        fieldBorder: "#666666",
        focus: "#3399ff",
      }),
    },
  };
}

function makeMaterialProfile(): PairedProfileV2 {
  return {
    ...makeBaseProfile(),
    material: {
      light: {
        panelAlpha: 0.9,
        borderAlpha: 0.7,
        blur: "12px",
        saturation: 1.1,
        reducedTransparency: "preserve",
      },
      dark: {
        panelAlpha: 0.86,
        borderAlpha: 0,
        blur: "0px",
        saturation: 2,
        reducedTransparency: "reduce",
      },
    },
  };
}

function loomOptions() {
  return {
    catalog: JSON.parse(readFileSync(resolve(SOLAR_SAIL_ROOT, "../stellar-loom/examples/loom-flexoki-catalog.json"), "utf8")),
    tokenSetKey: "flexoki-palette",
    primaryFamily: "cyan",
    secondaryFamily: "orange",
    defaultAccent: "cyan",
    familyBindings: { monospace: "system-mono" },
  };
}

describe("Paired Profile v2 material source contract", () => {
  it("preserves no-material canonical, output, report, defaults, and digest identity", () => {
    const profile = loadRealNoMaterialProfile();
    expect(profile.material).toBeUndefined();
    const parsed = validatePairedProfileV2(JSON.parse(canonicalizeProfileV2(profile)));
    expect(parsed.valid).toBe(true);
    expect(parsed.profile).toEqual(profile);

    const roundTrip = parsed.profile!;
    const solar = mapProfileToSolarSailWithReportV2(roundTrip);
    const solarSpecification = canonicalSha256(solar.specification);
    const solarReport = canonicalSha256(solar.report);
    const solarDefaults = canonicalSha256(solar.report.defaults);
    expect(canonicalSha256(roundTrip)).toEqual(PRE_MATERIAL_BASELINE.source);
    expect(solarSpecification).toEqual(PRE_MATERIAL_BASELINE.solar.specification);
    expect(solarReport).toEqual(PRE_MATERIAL_BASELINE.solar.report);
    expect(solarDefaults).toEqual(PRE_MATERIAL_BASELINE.solar.defaults);
    expect(solar.report.digest).toBe(PRE_MATERIAL_BASELINE.solar.reportDigest);
    expect(solar.specification).not.toHaveProperty("material");

    const options = realLoomOptions(roundTrip);
    const loom = mapProfileToStellarLoomWithReportV2(roundTrip, options.catalog, options);
    expect(canonicalSha256(loom.catalog)).toEqual(PRE_MATERIAL_BASELINE.loom.catalog);
    expect(canonicalSha256(loom.report)).toEqual(PRE_MATERIAL_BASELINE.loom.report);
    expect(canonicalSha256(loom.report.defaults)).toEqual(PRE_MATERIAL_BASELINE.loom.defaults);
    expect(loom.report.digest).toBe(PRE_MATERIAL_BASELINE.loom.reportDigest);
    expect(loom.catalog).not.toHaveProperty("material");

    const canonical = canonicalizeProfileV2(profile);
    expect(canonicalizeProfileV2(roundTrip)).toBe(canonical);
    expect(computeCanonicalDigestV2(canonicalizeProfileV2(roundTrip))).toBe(computeCanonicalDigestV2(canonical));
  });

  it("retains explicit identity material values as authored source and report identity", () => {
    const omitted = makeBaseProfile();
    const explicit = {
      ...makeBaseProfile(),
      material: { light: { panelAlpha: 1, blur: "0px" } },
    } satisfies PairedProfileV2;
    const omittedCanonical = canonicalizeProfileV2(omitted);
    const explicitCanonical = canonicalizeProfileV2(explicit);
    expect(explicitCanonical).not.toBe(omittedCanonical);
    expect(computeCanonicalDigestV2(explicitCanonical)).not.toBe(computeCanonicalDigestV2(omittedCanonical));

    const omittedSolar = mapProfileToSolarSailWithReportV2(omitted);
    const explicitSolar = mapProfileToSolarSailWithReportV2(explicit);
    expect(explicitSolar.specification).toEqual(omittedSolar.specification);
    expect(explicitSolar.report.sourceSha256).not.toBe(omittedSolar.report.sourceSha256);
    expect(explicitSolar.report.digest).not.toBe(omittedSolar.report.digest);
    expect(explicitSolar.report.entries.filter((entry) => entry.sourcePath.startsWith("material."))).toHaveLength(2);
    expect(explicitSolar.report.entries.filter((entry) => entry.sourcePath.startsWith("material.")).every((entry) => entry.classification === "unsupported")).toBe(true);

    const options = loomOptions();
    const omittedLoom = mapProfileToStellarLoomWithReportV2(omitted, options.catalog, options);
    const explicitLoom = mapProfileToStellarLoomWithReportV2(explicit, options.catalog, options);
    expect(explicitLoom.catalog).toEqual(omittedLoom.catalog);
    expect(explicitLoom.report.sourceSha256).not.toBe(omittedLoom.report.sourceSha256);
    expect(explicitLoom.report.digest).not.toBe(omittedLoom.report.digest);
  });

  it("round-trips and binds authored light/dark material without inventing output", () => {
    const profile = makeMaterialProfile();
    const source = canonicalizeProfileV2(profile);
    const bound = bindSourceProfileV2(source);

    expect(bound.profile.material).toEqual(profile.material);
    expect(bound.provenance.canonicalDigest).toBe(computeCanonicalDigestV2(source));
    expect(bound.mapToSolarSail().specification).not.toHaveProperty("material");
    expect(bound.mapToSolarSail().report.entries.filter((entry) => entry.sourcePath.startsWith("material.")).every((entry) => entry.classification === "unsupported")).toBe(true);

    const transformed = bound.transform((draft) => {
      draft.material!.dark!.blur = "64px";
    });
    expect(transformed.profile.material?.dark?.blur).toBe("64px");
    expect(transformed.provenance.isTransformed).toBe(true);
  });

  it("accounts for every authored material leaf as unsupported for both targets", () => {
    const profile = makeMaterialProfile();
    const paths = [
      "material.dark.blur",
      "material.dark.borderAlpha",
      "material.dark.panelAlpha",
      "material.dark.reducedTransparency",
      "material.dark.saturation",
      "material.light.blur",
      "material.light.borderAlpha",
      "material.light.panelAlpha",
      "material.light.reducedTransparency",
      "material.light.saturation",
    ];
    const solar = mapProfileToSolarSailWithReportV2(profile);
    const options = loomOptions();
    const loom = mapProfileToStellarLoomWithReportV2(profile, options.catalog, options);

    for (const report of [solar.report, loom.report]) {
      const materialEntries = report.entries.filter((entry) => entry.sourcePath.startsWith("material."));
      expect(materialEntries.map((entry) => entry.sourcePath).sort()).toEqual(paths);
      expect(materialEntries.every((entry) => entry.classification === "unsupported")).toBe(true);
      expect(materialEntries.every((entry) => entry.targetPath === undefined)).toBe(true);
      expect(materialEntries.every((entry) => entry.reason.includes("material"))).toBe(true);
      expect(report.defaults.some((entry) => entry.targetPath.startsWith("material."))).toBe(false);
    }
    expect(solar.report.groups.find((group) => group.group === "material")?.applicable).toBe(false);
    expect(loom.report.groups.find((group) => group.group === "material")?.applicable).toBe(false);
  });

  it("rejects invalid material values and closed-schema violations", () => {
    const cases: Array<[string, (profile: PairedProfileV2 & { material?: any }) => void]> = [
      ["boolean alpha", (profile) => { profile.material = { light: { panelAlpha: true } }; }],
      ["alpha above one", (profile) => { profile.material = { light: { panelAlpha: 1.01 } }; }],
      ["negative border alpha", (profile) => { profile.material = { dark: { borderAlpha: -0.01 } }; }],
      ["blur in rem", (profile) => { profile.material = { light: { blur: "1rem" } }; }],
      ["blur above 64px", (profile) => { profile.material = { light: { blur: "64.1px" } }; }],
      ["saturation above two", (profile) => { profile.material = { dark: { saturation: 2.01 } }; }],
      ["non-finite saturation", (profile) => { profile.material = { dark: { saturation: Number.NaN } }; }],
      ["negative zero alpha", (profile) => { profile.material = { light: { panelAlpha: -0 } }; }],
      ["invalid reduced transparency", (profile) => { profile.material = { light: { reducedTransparency: "fallback" } }; }],
      ["unknown material field", (profile) => { profile.material = { light: { tint: 0.5 } }; }],
      ["unknown material mode", (profile) => { profile.material = { high: { panelAlpha: 0.5 } }; }],
    ];

    for (const [label, mutate] of cases) {
      const profile = makeBaseProfile() as PairedProfileV2 & { material?: any };
      mutate(profile);
      const result = validatePairedProfileV2(profile);
      expect(result.valid, label).toBe(false);
      expect(result.errors.length, label).toBeGreaterThan(0);
    }
  });

  it("rejects accessor and custom-prototype material objects through safe-data validation", () => {
    const accessorProfile = makeBaseProfile() as PairedProfileV2 & { material?: any };
    accessorProfile.material = { light: {} };
    Object.defineProperty(accessorProfile.material.light, "panelAlpha", {
      enumerable: true,
      get: () => 0.5,
    });
    expect(validatePairedProfileV2(accessorProfile).valid).toBe(false);

    const prototypeProfile = makeBaseProfile() as PairedProfileV2 & { material?: any };
    prototypeProfile.material = { light: Object.create({ panelAlpha: 0.5 }) };
    expect(validatePairedProfileV2(prototypeProfile).valid).toBe(false);
  });
});

