import { describe, expect, it } from "vitest";
import { readFileSync, readdirSync } from "node:fs";
import { resolve } from "node:path";
import { parseThemeJson, assertSafeData, SafeDataError } from "../src/input.js";
import {
  validateThemeSpecification,
  validatePackageMetadata,
  isValidColor,
  isValidCssLength,
  isValidFontStack,
} from "../src/validator.js";

const fixturesDir = resolve(import.meta.dirname, "fixtures/negative-corpus");
const examplePath = resolve(import.meta.dirname, "../examples/forge-console.theme.json");
const validTheme = JSON.parse(readFileSync(examplePath, "utf8"));

describe("Negative Corpus: parseThemeJson & UTF-8 / Duplicate-Key Rejection", () => {
  it("rejects raw duplicate keys in JSON text", () => {
    const raw = readFileSync(resolve(fixturesDir, "raw-duplicate-keys.raw.json"), "utf8");
    expect(() => parseThemeJson(raw)).toThrowError(/Duplicate JSON key/i);
  });

  it("rejects duplicate decoded unicode escape keys (e.g. \\u006e\\u0061\\u006d\\u0065 vs name)", () => {
    const raw = readFileSync(resolve(fixturesDir, "raw-duplicate-decoded-keys.raw.json"), "utf8");
    expect(() => parseThemeJson(raw)).toThrowError(/Duplicate JSON key/i);
  });

  it("rejects UTF-8 BOM", () => {
    const raw = readFileSync(resolve(fixturesDir, "utf8-bom.raw.json"), "utf8");
    expect(() => parseThemeJson(raw)).toThrowError(/BOM is forbidden/i);
  });

  it("rejects invalid UTF-8 bytes when supplied as Uint8Array", () => {
    const invalidBytes = new Uint8Array([0xff, 0xfe, 0xfd]);
    expect(() => parseThemeJson(invalidBytes)).toThrowError(/Invalid UTF-8/i);
  });

  it("successfully parses valid UTF-8 Uint8Array without duplicates", () => {
    const validBytes = new TextEncoder().encode(JSON.stringify(validTheme));
    const parsed = parseThemeJson(validBytes);
    expect(parsed).toBeDefined();
    expect((parsed as any).name).toBe("forge-console");
  });

  it("rejects proto-poison key in JSON", () => {
    const raw = readFileSync(resolve(fixturesDir, "proto-poison-key.raw.json"), "utf8");
    expect(() => parseThemeJson(raw)).toThrowError(/Forbidden property/i);
  });

  it("rejects trailing garbage after valid JSON", () => {
    expect(() => parseThemeJson('{"a": 1} trailing')).toThrowError(/Unexpected trailing/i);
  });

  it("rejects JSON depth exceeding limit", () => {
    let deep = '{"a":';
    for (let i = 0; i < 25; i++) deep += '{"nest":';
    deep += "1";
    for (let i = 0; i < 26; i++) deep += "}";
    expect(() => parseThemeJson(deep)).toThrowError(/depth limit exceeded/i);
  });
});

describe("Negative Corpus: Unsafe Object Factories & Getter Safety", () => {
  it("rejects accessor properties without invoking the getter", () => {
    let getterInvoked = false;
    const evilObj = structuredClone(validTheme);
    Object.defineProperty(evilObj, "evilGetter", {
      get() {
        getterInvoked = true;
        throw new Error("Getter should never be invoked!");
      },
      enumerable: true,
      configurable: true,
    });

    expect(() => assertSafeData(evilObj)).toThrowError(/Accessor property.*forbidden/i);
    expect(getterInvoked).toBe(false);

    const res = validateThemeSpecification(evilObj);
    expect(res.valid).toBe(false);
    expect(getterInvoked).toBe(false);
  });

  it("rejects setter-only accessors", () => {
    const evilObj = structuredClone(validTheme);
    Object.defineProperty(evilObj, "evilSetter", {
      set(_val: any) {},
      enumerable: true,
      configurable: true,
    });

    expect(() => assertSafeData(evilObj)).toThrowError(/Accessor property.*forbidden/i);
  });

  it("rejects non-enumerable / hidden properties", () => {
    const evilObj = structuredClone(validTheme);
    Object.defineProperty(evilObj, "hiddenSecret", {
      value: "secret",
      enumerable: false,
      configurable: true,
    });

    expect(() => assertSafeData(evilObj)).toThrowError(/Non-enumerable property.*forbidden/i);
  });

  it("rejects symbol properties", () => {
    const evilObj = structuredClone(validTheme);
    (evilObj as any)[Symbol("forbiddenSymbol")] = "bad";

    expect(() => assertSafeData(evilObj)).toThrowError(/Symbol properties are forbidden/i);
  });

  it("rejects circular references", () => {
    const evilObj = structuredClone(validTheme);
    (evilObj as any).self = evilObj;

    expect(() => assertSafeData(evilObj)).toThrowError(/Circular reference detected/i);
    const res = validateThemeSpecification(evilObj);
    expect(res.valid).toBe(false);
  });

  it("rejects custom prototypes / prototype pollution attempts", () => {
    const customProto = Object.create({ polluted: true });
    expect(() => assertSafeData(customProto)).toThrowError(/Invalid object prototype/i);
  });

  it("rejects nonfinite numbers (NaN, Infinity, -Infinity)", () => {
    expect(() => assertSafeData(NaN)).toThrowError(/Nonfinite numbers are forbidden/i);
    expect(() => assertSafeData(Infinity)).toThrowError(/Nonfinite numbers are forbidden/i);
    expect(() => assertSafeData(-Infinity)).toThrowError(/Nonfinite numbers are forbidden/i);

    const objWithNan = { ...validTheme, surfaces: { radius: NaN } };
    const res = validateThemeSpecification(objWithNan);
    expect(res.valid).toBe(false);
  });

  it("rejects sparse arrays", () => {
    const sparse = new Array(5);
    expect(() => assertSafeData(sparse)).toThrowError(/Sparse or extended arrays forbidden/i);
  });

  it("rejects arrays with non-index properties", () => {
    const arr: any = [1, 2, 3];
    arr.customProp = "forbidden";
    expect(() => assertSafeData(arr)).toThrowError(/(?:Array contains non-index property|Sparse or extended arrays forbidden)/i);
  });

  it("rejects forbidden property names (__proto__, prototype, constructor)", () => {
    const badKey1 = Object.create(null);
    badKey1["__proto__"] = {};
    expect(() => assertSafeData(badKey1)).toThrowError(/Forbidden property name/i);

    const badKey2 = Object.create(null);
    badKey2["prototype"] = {};
    expect(() => assertSafeData(badKey2)).toThrowError(/Forbidden property name/i);

    const badKey3 = Object.create(null);
    badKey3["constructor"] = {};
    expect(() => assertSafeData(badKey3)).toThrowError(/Forbidden property name/i);
  });
});

describe("Negative Corpus: Fixture Files Rejection", () => {
  const cases: Array<{ id: string; file: string; boundary: string; code: string; pathPrefix?: string }> = JSON.parse(readFileSync(resolve(fixturesDir, "cases.json"), "utf8"));
  it.each(cases)("rejects $id at its declared boundary", entry => {
    const bytes = readFileSync(resolve(fixturesDir, entry.file));
    if (entry.boundary === "bytes") {
      expect(() => parseThemeJson(bytes)).toThrow();
      try { parseThemeJson(bytes); } catch (error) { expect((error as SafeDataError).code).toBe(entry.code); }
    } else {
      const res = validateThemeSpecification(parseThemeJson(bytes));
      expect(res.valid).toBe(false);
      expect(res.diagnostics.some(d => d.code === entry.code && (d.path ?? "").startsWith(entry.pathPrefix!))).toBe(true);
    }
  });
});

describe("Negative Corpus: CSS Sink Safety & Grammar Enforcement", () => {
  it("rejects CSS injection inside colors", () => {
    expect(isValidColor("oklch(0.5 0.1 20); } body { color: red; } /*")).toBe(false);
    expect(isValidColor("rgb(0, 0, 0); background: red;")).toBe(false);
    expect(isValidColor("hsl(0, 0%, 0%) /* comment */")).toBe(false);
    expect(isValidColor("var(--primary; color: red)")).toBe(false);
    expect(isValidColor("oklch(0.5 0.1 20 <script>)")).toBe(false);
    expect(isValidColor("url('javascript:alert(1)')")).toBe(false);
  });

  it("rejects unsupported color functions and named colors", () => {
    expect(isValidColor("red")).toBe(false);
    expect(isValidColor("blue")).toBe(false);
    expect(isValidColor("papayawhip")).toBe(false);
    expect(isValidColor("transparent")).toBe(false);
    expect(isValidColor("currentColor")).toBe(false);
    expect(isValidColor("color-mix(in srgb, red, blue)")).toBe(false);
    expect(isValidColor("lab(50% 20 30)")).toBe(false);
    expect(isValidColor("hwb(120 10% 20%)")).toBe(false);
  });

  it("accepts valid supported color formats", () => {
    expect(isValidColor("#fff")).toBe(true);
    expect(isValidColor("#ffff")).toBe(true);
    expect(isValidColor("#126475")).toBe(true);
    expect(isValidColor("#12647580")).toBe(true);
    expect(isValidColor("rgb(18, 100, 117)")).toBe(true);
    expect(isValidColor("rgba(18, 100, 117, 0.5)")).toBe(true);
    expect(isValidColor("rgb(18 100 117 / 0.5)")).toBe(true);
    expect(isValidColor("hsl(210, 50%, 40%)")).toBe(true);
    expect(isValidColor("hsla(210, 50%, 40%, 0.8)")).toBe(true);
    expect(isValidColor("hsl(210 50% 40% / 0.8)")).toBe(true);
    expect(isValidColor("oklch(0.55 0.12 210)")).toBe(true);
    expect(isValidColor("oklch(0.55 0.12 210 / 0.8)")).toBe(true);
    expect(isValidColor("oklch(98% 0.01 210)")).toBe(true);
    expect(isValidColor("var(--primary)")).toBe(true);
    expect(isValidColor("var(--primary, #126475)")).toBe(true);
  });

  it("rejects CSS injection inside surfaces.radius", () => {
    expect(isValidCssLength("0.5rem; } body { display: none; }")).toBe(false);
    expect(isValidCssLength("calc(10px + 20px)")).toBe(false);
    expect(isValidCssLength("10")).toBe(false); // unitless
    expect(isValidCssLength("")).toBe(false);
    expect(isValidCssLength("auto")).toBe(false);
  });

  it("accepts valid CSS lengths", () => {
    expect(isValidCssLength("0")).toBe(true);
    expect(isValidCssLength("0px")).toBe(true);
    expect(isValidCssLength("0.5rem")).toBe(true);
    expect(isValidCssLength("8px")).toBe(true);
    expect(isValidCssLength("1em")).toBe(true);
    expect(isValidCssLength("100%")).toBe(true);
  });

  it("rejects CSS injection and invalid font stacks in typography", () => {
    expect(isValidFontStack("sans-serif; } body { color: red; }")).toBe(false);
    expect(isValidFontStack("sans-serif /* comment */")).toBe(false);
    expect(isValidFontStack("url('https://evil.com/font.woff2')")).toBe(false);
    expect(isValidFontStack("@import 'evil.css'")).toBe(false);
    expect(isValidFontStack("")).toBe(false);
  });

  it("accepts valid font stacks", () => {
    expect(isValidFontStack("system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif")).toBe(true);
    expect(isValidFontStack("ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace")).toBe(true);
    expect(isValidFontStack('"Segoe UI", Tahoma, Geneva, Verdana, sans-serif')).toBe(true);
    expect(isValidFontStack("Inter, sans-serif")).toBe(true);
  });
});

describe("Positive Baseline: Symmetric Extension Roles & Alpha Handling", () => {
  it("accepts symmetric optional chart roles (chart1..5 in both light and dark)", () => {
    const chartTheme = structuredClone(validTheme);
    chartTheme.palette.light.chart1 = "oklch(0.646 0.222 41.116)";
    chartTheme.palette.light.chart2 = "oklch(0.6 0.118 184.704)";
    chartTheme.palette.light.chart3 = "oklch(0.398 0.07 227.392)";
    chartTheme.palette.light.chart4 = "oklch(0.828 0.189 84.429)";
    chartTheme.palette.light.chart5 = "oklch(0.769 0.188 70.08)";

    chartTheme.palette.dark.chart1 = "oklch(0.488 0.243 264.376)";
    chartTheme.palette.dark.chart2 = "oklch(0.696 0.17 162.48)";
    chartTheme.palette.dark.chart3 = "oklch(0.769 0.188 70.08)";
    chartTheme.palette.dark.chart4 = "oklch(0.627 0.265 303.9)";
    chartTheme.palette.dark.chart5 = "oklch(0.645 0.246 16.439)";

    const res = validateThemeSpecification(chartTheme);
    expect(res.valid).toBe(true);
    expect(res.errors).toHaveLength(0);
    expect(res.specification?.palette.light.chart1).toBe("oklch(0.646 0.222 41.116)");
    expect(res.specification?.palette.dark.chart1).toBe("oklch(0.488 0.243 264.376)");
  });

  it("accepts symmetric optional sidebar roles", () => {
    const sidebarTheme = structuredClone(validTheme);
    sidebarTheme.palette.light.sidebar = "#f7f7f8";
    sidebarTheme.palette.light.sidebarForeground = "#262a33";
    sidebarTheme.palette.light.sidebarPrimary = "#126475";
    sidebarTheme.palette.light.sidebarPrimaryForeground = "#ffffff";
    sidebarTheme.palette.light.sidebarAccent = "#eee4da";
    sidebarTheme.palette.light.sidebarAccentForeground = "#262a33";
    sidebarTheme.palette.light.sidebarBorder = "#d1c4b8";
    sidebarTheme.palette.light.sidebarRing = "#126475";

    sidebarTheme.palette.dark.sidebar = "#14161b";
    sidebarTheme.palette.dark.sidebarForeground = "#eee9e3";
    sidebarTheme.palette.dark.sidebarPrimary = "#69d3e4";
    sidebarTheme.palette.dark.sidebarPrimaryForeground = "#111318";
    sidebarTheme.palette.dark.sidebarAccent = "#262a33";
    sidebarTheme.palette.dark.sidebarAccentForeground = "#ddd7d0";
    sidebarTheme.palette.dark.sidebarBorder = "#393d48";
    sidebarTheme.palette.dark.sidebarRing = "#69d3e4";

    const res = validateThemeSpecification(sidebarTheme);
    expect(res.valid).toBe(true);
    expect(res.errors).toHaveLength(0);
  });

  it("preserves UNEVALUATED_CONTRAST for alpha-bearing colors", () => {
    const alphaTheme = structuredClone(validTheme);
    alphaTheme.palette.light.foreground = "#262a33cc"; // 8-digit hex with alpha
    alphaTheme.palette.light.background = "#fff8f0";

    const res = validateThemeSpecification(alphaTheme);
    expect(res.valid).toBe(true);
    expect(res.diagnostics.some((d) => d.code === "UNEVALUATED_CONTRAST")).toBe(true);
  });

  it("returns deeply frozen owned data that cannot be mutated by caller", () => {
    const inputTheme = structuredClone(validTheme);
    const res = validateThemeSpecification(inputTheme);
    expect(res.valid).toBe(true);
    expect(res.specification).toBeDefined();
    expect(Object.isFrozen(res.specification)).toBe(true);
    expect(Object.isFrozen(res.specification?.palette)).toBe(true);
    expect(Object.isFrozen(res.specification?.palette.light)).toBe(true);

    // Mutating inputTheme does not affect returned specification
    inputTheme.name = "mutated-name";
    expect(res.specification?.name).toBe("forge-console");
  });
});

describe("Package Metadata Validation Hardening", () => {
  const validMetadata = {
    name: "@knowledge-forge-ai/app-theme-forge-console",
    version: "0.1.0",
    description: "Forge Console application theme",
    license: "AGPL-3.0-or-later",
    private: true,
  };

  it("accepts valid metadata and returns frozen owned data", () => {
    const res = validatePackageMetadata(validMetadata);
    expect(res.name).toBe("@knowledge-forge-ai/app-theme-forge-console");
    expect(Object.isFrozen(res)).toBe(true);
  });

  it("rejects unknown keys in package metadata", () => {
    expect(() =>
      validatePackageMetadata({ ...validMetadata, unknownKey: "bad" })
    ).toThrowError(/Unknown package metadata key/i);
  });

  it("rejects invalid package name formats and traversal attempts", () => {
    expect(() =>
      validatePackageMetadata({ ...validMetadata, name: "../malicious" })
    ).toThrowError(/valid npm package identifier/i);

    expect(() =>
      validatePackageMetadata({ ...validMetadata, name: "UPPERCASE_NAME" })
    ).toThrowError(/valid npm package identifier/i);

    expect(() =>
      validatePackageMetadata({ ...validMetadata, name: "name with spaces" })
    ).toThrowError(/valid npm package identifier/i);
  });

  it("rejects invalid SemVer in package metadata", () => {
    expect(() =>
      validatePackageMetadata({ ...validMetadata, version: "v1.0" })
    ).toThrowError(/follow semantic versioning/i);
  });

  it("rejects invalid optional types in package metadata", () => {
    expect(() =>
      validatePackageMetadata({ ...validMetadata, description: 12345 })
    ).toThrowError(/must be a single-line string/i);

    expect(() =>
      validatePackageMetadata({ ...validMetadata, author: true })
    ).toThrowError(/must be a single-line string/i);

    expect(() =>
      validatePackageMetadata({ ...validMetadata, private: "true" })
    ).toThrowError(/must be a boolean/i);
  });
});


describe("bounded numeric and byte regressions", () => {
  it("rejects raw-byte BOM and excessive numeric/color nesting without recursive exhaustion", () => {
    expect(() => parseThemeJson(new Uint8Array([239, 187, 191, 123, 125]))).toThrow(/BOM/);
    expect(isValidColor(`rgb(${"9".repeat(400)} 0 0)`)).toBe(false);
    expect(isValidColor("var(--x,".repeat(30) + "#fff" + ")".repeat(30))).toBe(false);
    expect(isValidCssLength("9".repeat(400) + "px")).toBe(false);
    expect(isValidColor("rgb(300 0 0)")).toBe(false);
    expect(isValidColor("rgb(10%, 2, 3)")).toBe(false);
    expect(isValidColor("rgb(0 0 0 / 2)")).toBe(false);
  });
  it("preserves intentionally supported undefined metadata optionals", () => {
    expect(validatePackageMetadata({ name: "fixture", version: "1.0.0", description: undefined })).toEqual(validatePackageMetadata({ name: "fixture", version: "1.0.0" }));
  });
});


it("rejects every C0, DEL and C1 control before CSS token trimming", () => {
  for (const code of [...Array.from({ length: 32 }, (_, i) => i), ...Array.from({ length: 33 }, (_, i) => i + 127)]) {
    const control = String.fromCharCode(code);
    for (const [validate, token] of [[isValidColor, "#fff"], [isValidCssLength, "0.5rem"], [isValidFontStack, "sans-serif"]] as const) {
      expect(validate(control + token)).toBe(false);
      expect(validate(token + control)).toBe(false);
    }
  }
});
it("characterizes uncapped finite hue and chroma without asserting gamut validity", () => {
  expect(isValidColor("oklch(0.5 999999 180)")).toBe(true);
  expect(isValidColor("hsl(1000000turn 50% 50%)")).toBe(true);
});
