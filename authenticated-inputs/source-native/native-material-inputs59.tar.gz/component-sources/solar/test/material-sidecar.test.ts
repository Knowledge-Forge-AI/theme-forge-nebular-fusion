import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";
import {
  MaterialSidecarValidationError,
  canonicalizeJson,
  compileTheme,
  compileMaterialSidecar,
  generateMaterialSidecar,
} from "../src/index.js";

const themePath = resolve(import.meta.dirname, "../examples/forge-console.theme.json");
const validTheme = JSON.parse(readFileSync(themePath, "utf8"));

function compilation() {
  return compileTheme(validTheme);
}

function generate(material: unknown, options: Record<string, unknown> = {}) {
  return generateMaterialSidecar({
    compilation: compilation(),
    material,
    ...options,
  });
}

describe("Solar tfss.material-v1 sidecar", () => {
  it("omits sidecar files and leaves the compiled base result untouched", () => {
    const compiled = compilation();
    const before = canonicalizeJson(compiled);

    expect(generateMaterialSidecar({ compilation: compiled })).toBeUndefined();
    expect(generate({})).toBeUndefined();
    expect(generate({ light: {} })).toBeUndefined();
    expect(canonicalizeJson(compiled)).toBe(before);
  });

  it("binds the actual compilation and emits deterministic semantic CSS", () => {
    const material = {
      light: { panelAlpha: 0.9, borderAlpha: 0.7, blur: "0px", saturation: 1.1 },
      dark: { borderAlpha: 0.6, reducedTransparency: "preserve" as const },
    };
    const first = generate(material);
    const second = generate(material);

    expect(first).toBeDefined();
    expect(second).toEqual(first);
    expect([...first!.files.keys()]).toEqual([
      "material.json",
      "material.descriptor.json",
      "styles/material.css",
    ]);
    expect(first!.sidecar.theme.schemaVersion).toBe("tfss.theme-v1");
    expect(first!.sidecar.theme.inputDigest).toBe(compilation().inputDigest);
    expect(first!.sidecar.theme.outputDigest).toBe(compilation().outputDigest);
    expect(first!.descriptor.materialInputDigest).toBe(first!.materialInputDigest);
    expect(first!.descriptor.cssOutputDigest).toBe(first!.cssOutputDigest);
    expect(first!.files.get("material.json")).toBe(first!.sidecarJson);
    expect(first!.files.get("material.descriptor.json")).toBe(first!.descriptorJson);
    expect(first!.files.get("styles/material.css")).toBe(first!.css);

    expect(first!.css).toContain("--tfss-material-panel-tint: var(--card);");
    expect(first!.css).toContain("--tfss-material-border-tint: var(--border);");
    expect(first!.css).toContain("--tfss-material-blur-authored: 0px;");
    expect(first!.css).toContain("--tfss-material-blur: 0px;");
    expect(first!.css).toContain("--tfss-material-saturation: 1.1;");
    expect(first!.css).toContain("@media (prefers-reduced-transparency: reduce)");
    expect(first!.css).toContain("data-tf-reduced-transparency=\"reduce\"");
    expect(first!.css).toContain("@media (forced-colors: active)");
    expect(first!.css).not.toContain("opacity:");
    expect(first!.css).not.toContain("border-width:");
    expect(first!.css).not.toContain("border-style:");
  });

  it("resets the full authored variable union at each light/dark cascade boundary", () => {
    const result = generate({
      light: { panelAlpha: 0.5 },
      dark: { blur: "4px" },
    });
    expect(result).toBeDefined();

    const darkStart = result!.css.indexOf(".dark,\n:root[data-theme='dark']");
    expect(darkStart).toBeGreaterThan(0);
    const lightScope = result!.css.slice(0, darkStart);
    const darkScope = result!.css.slice(darkStart, result!.css.indexOf("@media"));

    expect(lightScope).toContain("--tfss-material-blur: initial;");
    expect(lightScope).toContain("--tfss-material-panel-alpha: 0.5;");
    expect(darkScope).toContain("--tfss-material-panel-alpha: initial;");
    expect(darkScope).toContain("--tfss-material-blur: 4px;");
    expect(darkScope).toContain("--tfss-material-panel-tint: initial;");
  });

  it("uses reduced baselines and makes OS/manual reduction neutralize every mode", () => {
    const result = generate({
      light: { panelAlpha: 0.25, blur: "5px", saturation: 1.4, reducedTransparency: "reduce" },
      dark: { panelAlpha: 0.65, borderAlpha: 0.55, blur: "6px", saturation: 1.2 },
    });
    expect(result).toBeDefined();

    const css = result!.css;
    const mediaStart = css.indexOf("@media (prefers-reduced-transparency: reduce)");
    const manualReduceStart = css.indexOf(':root[data-tf-reduced-transparency="reduce"] {');
    const manualPreserveStart = css.indexOf(':root[data-tf-reduced-transparency="preserve"] {');
    const forcedStart = css.indexOf("@media (forced-colors: active)");
    expect(mediaStart).toBeGreaterThan(0);
    expect(manualReduceStart).toBeGreaterThan(mediaStart);
    expect(manualPreserveStart).toBeGreaterThan(manualReduceStart);
    expect(forcedStart).toBeGreaterThan(manualPreserveStart);

    const normal = css.slice(0, mediaStart);
    const osReduced = css.slice(mediaStart, manualReduceStart);
    const manualReduced = css.slice(manualReduceStart, manualPreserveStart);
    const manualPreserved = css.slice(manualPreserveStart, forcedStart);

    expect(normal).toContain("--tfss-material-panel-alpha-authored: 0.25;");
    expect(normal).toContain("--tfss-material-panel-alpha: 1;");
    expect(normal).toContain("--tfss-material-blur-authored: 5px;");
    expect(normal).toContain("--tfss-material-blur: 0px;");
    expect(osReduced.match(/--tfss-material-panel-alpha: 1;/g)?.length).toBe(2);
    expect(osReduced.match(/--tfss-material-blur: 0px;/g)?.length).toBe(2);
    expect(manualReduced.match(/--tfss-material-saturation: 1;/g)?.length).toBe(2);
    expect(manualPreserved).toContain("--tfss-material-panel-alpha: 0.25;");
    expect(manualPreserved).toContain("--tfss-material-panel-alpha: 0.65;");
    expect(manualPreserved).toContain("--tfss-material-blur: 5px;");
    expect(manualPreserved).toContain("--tfss-material-blur: 6px;");
    const forced = css.slice(forcedStart);
    for (const selector of [
      ':root[data-tf-reduced-transparency="reduce"]',
      ':root[data-tf-reduced-transparency="preserve"]',
      ':root[data-tf-reduced-transparency="reduce"] .dark',
      ':root[data-tf-reduced-transparency="preserve"] .dark',
      ':root[data-tf-reduced-transparency="reduce"][data-theme="dark"]',
      ':root[data-tf-reduced-transparency="preserve"][data-theme="dark"]',
      '.dark:root[data-tf-reduced-transparency="reduce"]',
      '.dark:root[data-tf-reduced-transparency="preserve"]',
      '.dark[data-tf-reduced-transparency="reduce"]',
      '.dark[data-tf-reduced-transparency="preserve"]',
    ]) expect(forced).toContain(selector);
    expect(forced).toContain("--tfss-material-panel-tint: Canvas;");
    expect(forced).toContain("--tfss-material-border-tint: CanvasText;");
    expect(forced).toContain("--tfss-material-panel-alpha: 1;");
    expect(forced).toContain("--tfss-material-border-alpha: 1;");
    expect(forced).toContain("--tfss-material-panel-alpha-authored: 0.25;");
    expect(forced).toContain("--tfss-material-border-alpha-authored: 0.55;");
    expect(forced).toContain("--tfss-material-blur-authored: 5px;");
    expect(forced).toContain("--tfss-material-saturation-authored: 1.4;");
  });

  it("retains explicit zero/identity values and emits fallback only when requested", () => {
    const material = {
      light: {
        panelAlpha: 0,
        borderAlpha: 1,
        blur: "0px",
        saturation: 0,
        reducedTransparency: "preserve" as const,
      },
    };
    const result = generate(material, { solidFallback: "source-tint" });
    const withoutFallback = generate(material);

    expect(result!.sidecar.light).toEqual(material.light);
    expect(result!.sidecar.policy).toEqual({ solidFallback: "source-tint" });
    expect(result!.sidecarJson).toContain('"panelAlpha": 0');
    expect(result!.sidecarJson).toContain('"blur": "0px"');
    expect(result!.css).toContain("--tfss-material-panel-alpha: 0;");
    expect(result!.css).toContain("--tfss-material-border-alpha: 1;");
    expect(result!.css).toContain("--tfss-material-panel-solid: var(--card);");
    expect(withoutFallback!.sidecar.policy).toBeUndefined();
    expect(withoutFallback!.css).not.toContain("--tfss-material-panel-solid");
  });

  it("rejects unsafe, unknown and out-of-range sidecar input", () => {
    const cases: Array<[unknown, string]> = [
      [{ light: { panelAlpha: true } }, "INVALID_VALUE"],
      [{ light: { saturation: 2.1 } }, "INVALID_VALUE"],
      [{ light: { blur: "1rem" } }, "INVALID_VALUE"],
      [{ light: { blur: " 1px" } }, "INVALID_VALUE"],
      [{ light: { blur: "1px " } }, "INVALID_VALUE"],
      [{ light: { blur: "\u00a01px" } }, "INVALID_VALUE"],
      [{ light: { blur: "1px\u00a0" } }, "INVALID_VALUE"],
      [{ light: { blur: "\ufeff1px" } }, "INVALID_VALUE"],
      [{ light: { blur: "1px\ufeff" } }, "INVALID_VALUE"],
      [{ light: { blur: "\u20281px" } }, "INVALID_VALUE"],
      [{ light: { blur: "1px\u2028" } }, "INVALID_VALUE"],
      [{ light: { unknown: 1 } }, "SCHEMA_VALIDATION"],
      [{ light: { reducedTransparency: "ignore" } }, "INVALID_VALUE"],
      [{ light: { panelAlpha: Number.NaN } }, "UNSAFE_DATA"],
    ];
    for (const [material, code] of cases) {
      expect(() => generate(material)).toThrow(
        expect.objectContaining({ code })
      );
    }

    const accessor: Record<string, unknown> = { light: {} };
    Object.defineProperty(accessor.light, "blur", {
      enumerable: true,
      get: () => "4px",
    });
    expect(() => generate(accessor)).toThrow(MaterialSidecarValidationError);

    const poisoned = Object.create({ light: { panelAlpha: 0.5 } });
    expect(() => generate(poisoned)).toThrow(MaterialSidecarValidationError);
  });

  it("rejects fabricated compilation digests and mismatched source assertions", () => {
    const compiled = compilation();
    const fake = {
      ...compiled,
      outputDigest: "0".repeat(64),
    };
    expect(() => generateMaterialSidecar({ compilation: fake, material: { light: { blur: "2px" } } })).toThrow(
      expect.objectContaining({ code: "COMPILATION_BINDING_MISMATCH" })
    );
    expect(() => compileMaterialSidecar({ compilation: fake, material: { light: { blur: "2px" } } })).toThrow(
      expect.objectContaining({ code: "COMPILATION_BINDING_MISMATCH" })
    );

    const sourceBound = compileTheme({
      ...validTheme,
      sourceProfileSha256: "a".repeat(64),
    });
    expect(() => generateMaterialSidecar({
      compilation: sourceBound,
      material: { light: { blur: "2px" } },
      sourceProfileSha256: "b".repeat(64),
    })).toThrow(expect.objectContaining({ code: "SOURCE_PROFILE_BINDING_MISMATCH" }));

    const accepted = generateMaterialSidecar({
      compilation: sourceBound,
      material: { light: { blur: "2px" } },
    });
    expect(accepted!.sidecar.sourceProfileSha256).toBe("a".repeat(64));
  });
});
