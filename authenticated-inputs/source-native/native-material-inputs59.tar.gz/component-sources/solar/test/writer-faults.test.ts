import { afterEach, describe, expect, it, vi } from "vitest";
import { mkdtemp, mkdir, readdir, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
const fault = vi.hoisted(() => ({ mode: "none" }));
vi.mock("node:fs/promises", async importOriginal => {
  const actual = await importOriginal<typeof import("node:fs/promises")>();
  return { ...actual, open: async (...args: Parameters<typeof actual.open>) => {
    const handle = await actual.open(...args);
    if (String(args[0]).endsWith("fail.txt")) {
      const write = handle.writeFile.bind(handle);
      handle.writeFile = async () => {
        await write("partial bytes");
        if (fault.mode === "replacement") {
          const replacement = `${args[0]}.foreign`;
          await actual.writeFile(replacement, "foreign bytes");
          await actual.rename(replacement, String(args[0]));
        }
        throw Object.assign(new Error("injected storage failure"), { code: "EIO" });
      };
    }
    return handle;
  } };
});
import { writePackageFiles, writeCssFile } from "../src/writer.js";
let scratch: string | undefined;
afterEach(async () => { fault.mode = "none"; if (scratch) await rm(scratch, { recursive: true, force: true }); });
describe("filesystem failure boundaries", () => {
  it.each([false, true])("rolls back partial I/O while preserving prior empty directory=%s", async existing => {
    scratch = await mkdtemp(join(tmpdir(), "tfss-fault-")); const target = join(scratch, "package");
    if (existing) await mkdir(target);
    await expect(writePackageFiles(new Map([["ok.txt", "ok"], ["sub/fail.txt", "data"]]), target)).rejects.toMatchObject({ code: "EIO" });
    expect(await readdir(scratch)).toEqual(existing ? ["package"] : []);
    if (existing) expect(await readdir(target)).toEqual([]);
  });
  it("preserves a replaced foreign entry and reports incomplete rollback", async () => {
    scratch = await mkdtemp(join(tmpdir(), "tfss-fault-")); fault.mode = "replacement";
    const target = join(scratch, "package");
    await expect(writePackageFiles(new Map([["fail.txt", "data"]]), target)).rejects.toThrow("cleanup was incomplete");
    expect(await readFile(join(target, "fail.txt"), "utf8")).toBe("foreign bytes");
  });
  it("removes a partially written exclusive CSS destination", async () => {
    scratch = await mkdtemp(join(tmpdir(), "tfss-fault-"));
    await expect(writeCssFile(join(scratch, "fail.txt"), "css")).rejects.toMatchObject({ code: "EIO" });
    expect(await readdir(scratch)).toEqual([]);
  });
  it("allows only one cooperating writer to reserve an empty destination", async () => {
    scratch = await mkdtemp(join(tmpdir(), "tfss-fault-"));
    const results = await Promise.allSettled(["one", "two"].map(content => writePackageFiles(new Map([["value", content]]), scratch!)));
    expect(results.filter(r => r.status === "fulfilled")).toHaveLength(1);
    expect(["one", "two"]).toContain(await readFile(join(scratch, "value"), "utf8"));
    expect(await readdir(scratch)).toEqual(["value"]);
  });
});
