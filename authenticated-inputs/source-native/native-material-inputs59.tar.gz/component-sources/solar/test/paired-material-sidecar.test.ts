import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";
import {
  classifyProfileError,
  isPairedProfileV2Error,
  PairedProfileV2Error,
  StaleProvenanceV2Error,
  bindSourceProfileV2,
  canonicalizeProfileV2,
  compilePairedV2SolarMaterial,
  computeRawSourceSha256,
  fromUnverifiedProfileV2,
  mapProfileToSolarSailWithReportV2,
  validatePairedProfileV2,
  type PairedProfileV2,
} from "../src/paired-v2/index.js";
import { compileTheme } from "../src/index.js";

const SOLAR_SAIL_ROOT = resolve(import.meta.dirname, "..");
const REAL_PROFILE_PATH = resolve(
  SOLAR_SAIL_ROOT,
  "../../themes/shadcn-terminal-nova/terminal-nova.profile.json"
);
const REAL_LOOM_CATALOG_PATH = resolve(
  SOLAR_SAIL_ROOT,
  "../../themes/terminal-nova/v0.3/terminal-nova.theme.json"
);

const PRE_MATERIAL_BASELINE = {
  source: {
    bytes: 2215,
    sha256: "11521e5ead9ba6cd589ecd7193c07d630e63f9fb9c639def67363da5ff648af0",
  },
  solar: {
    specification: {
      bytes: 1836,
      sha256: "93a8cf9039cfe1b262bdab511f0d8b4811eeb50bc54c8975f40016635857d1d0",
    },
    report: {
      bytes: 17048,
      sha256: "5943455b37aa8824ff412d58b3d7ef458bf667a8065ff03af10addc6b2c6e2e6",
    },
    reportDigest: "c908dc01d8e5a1000cc9cee021151c12972a4aa351ffb301f01b0736987194f6",
  },
  loom: {
    catalog: {
      bytes: 9178,
      sha256: "f298a655d25ced6c590a76bcf648874d8d42f792365f3722c210a4bc48bc28fc",
    },
  },
} as const;

function canonicalSha256(value: unknown): { bytes: number; sha256: string } {
  const canonical = canonicalizeProfileV2(value);
  return {
    bytes: Buffer.byteLength(canonical, "utf8"),
    sha256: computeRawSourceSha256(canonical),
  };
}

function loadRealProfile(): PairedProfileV2 {
  return JSON.parse(readFileSync(REAL_PROFILE_PATH, "utf8")) as PairedProfileV2;
}

function realLoomOptions(profile: PairedProfileV2) {
  const loom = profile.targetOverrides!.loom!;
  return {
    catalog: JSON.parse(readFileSync(REAL_LOOM_CATALOG_PATH, "utf8")),
    tokenSetKey: loom.tokenSetKey!,
    primaryFamily: loom.primaryFamily!,
    secondaryFamily: loom.secondaryFamily!,
    defaultAccent: loom.defaultAccent!,
  };
}

describe("paired-v2 Solar material sidecar integration", () => {
  it("keeps the maintained CTTN profile and Loom catalog baseline exact without material", () => {
    const raw = readFileSync(REAL_PROFILE_PATH, "utf8");
    const bound = bindSourceProfileV2(raw);
    const result = compilePairedV2SolarMaterial(bound);
    const base = bound.mapToSolarSail();
    const direct = mapProfileToSolarSailWithReportV2(bound.profile);
    const loom = bound.mapToStellarLoom(realLoomOptions(bound.profile));

    expect(canonicalSha256(bound.profile)).toEqual(PRE_MATERIAL_BASELINE.source);
    expect(canonicalSha256(direct.specification)).toEqual(PRE_MATERIAL_BASELINE.solar.specification);
    expect(canonicalSha256(direct.report)).toEqual(PRE_MATERIAL_BASELINE.solar.report);
    expect(direct.report.digest).toBe(PRE_MATERIAL_BASELINE.solar.reportDigest);
    expect(result.specification).toEqual(base.specification);
    expect(result.compilation).toEqual(compileTheme(base.specification));
    expect(result).not.toHaveProperty("sidecar");
    expect(result).not.toHaveProperty("receipt");
    expect(result.sourceProfileSha256).toBe(bound.provenance.rawSourceSha256);
    expect(result.specification).not.toHaveProperty("material");

    expect(canonicalSha256(loom.catalog)).toEqual(PRE_MATERIAL_BASELINE.loom.catalog);
    expect(loom.catalog).not.toHaveProperty("material");
    expect(loom.report.entries.some((entry) => entry.sourcePath.startsWith("material."))).toBe(false);
    expect(result.report).toEqual(base.report);
  });

  it("emits a separate receipt while preserving unsupported base and Loom reports", () => {
    const bound = bindSourceProfileV2(readFileSync(REAL_PROFILE_PATH, "utf8"));
    const materialBound = bound.transform((draft) => {
      draft.material = {
        light: {
          panelAlpha: 0,
          borderAlpha: 1,
          blur: "0px",
          saturation: 0,
          reducedTransparency: "preserve",
        },
        dark: {
          panelAlpha: 0.86,
          borderAlpha: 0.62,
          blur: "8px",
          saturation: 1.05,
          reducedTransparency: "reduce",
        },
      };
      draft.targetOverrides!.solarSail!.palette!.light!.card = "#123456";
    });
    const result = compilePairedV2SolarMaterial(materialBound, {
      expectedSourceProfileSha256: materialBound.provenance.rawSourceSha256,
    });

    expect(result.sidecar).toBeDefined();
    expect(result.receipt).toBeDefined();
    expect(result.report.target).toBe("solar-sail");
    expect(result.report.entries.filter((entry) => entry.sourcePath.startsWith("material.")).every((entry) => entry.classification === "unsupported")).toBe(true);
    expect(result.report.entries.filter((entry) => entry.sourcePath.startsWith("material.")).every((entry) => entry.targetPath === undefined)).toBe(true);
    expect(result.compilation.specification.palette.light.card).toBe("#123456");
    expect(result.compilation.css).toContain("--card: #123456;");
    expect(result.sidecar!.css).toContain("--tfss-material-panel-tint: var(--card);");
    expect(result.sidecar!.css).not.toContain("#123456");
    expect(result.sidecar!.sidecar.light).toEqual(materialBound.profile.material!.light);
    expect(result.sidecar!.sidecar.dark).toEqual(materialBound.profile.material!.dark);

    const receipt = result.receipt!;
    expect(receipt.target).toBe("solar-material-sidecar");
    expect(receipt.profile.canonicalDigest).toBe(result.canonicalDigest);
    expect(receipt.profile.canonicalSha256).toBe(result.canonicalProfileSha256);
    expect(receipt.profile.sourceVerification).toBe("transformed");
    expect(receipt.theme.inputDigest).toBe(result.compilation.inputDigest);
    expect(receipt.theme.outputDigest).toBe(result.compilation.outputDigest);
    expect(receipt.theme.baseReportDigest).toBe(result.report.digest);
    expect(receipt.sidecar.sidecarOutputDigest).toBe(computeRawSourceSha256(result.sidecar!.sidecarJson));
    expect(receipt.sidecar.cssOutputDigest).toBe(result.sidecar!.cssOutputDigest);
    expect(receipt.sidecar.files.map((file) => file.path)).toEqual([
      "material.json",
      "material.descriptor.json",
      "styles/material.css",
    ]);
    expect(receipt.effects).toHaveLength(10);
    expect(receipt.effects.find((effect) => effect.sourcePath === "material.light.panelAlpha")?.sourceValue).toBe(0);
    expect(receipt.effects.find((effect) => effect.sourcePath === "material.light.blur")?.sourceValue).toBe("0px");
    expect(receipt.effects.find((effect) => effect.sourcePath === "material.dark.reducedTransparency")?.sourceValue).toBe("reduce");
    expect(receipt.effects.every((effect) => effect.target === "solar-material-sidecar")).toBe(true);
    const panelEffect = receipt.effects.find((effect) => effect.sourcePath === "material.light.panelAlpha");
    expect(panelEffect?.cssVariable).toBe("--tfss-material-panel-alpha");
    expect(panelEffect?.authoredCssVariable).toBe("--tfss-material-panel-alpha-authored");
    expect(panelEffect?.effectiveCssVariable).toBe("--tfss-material-panel-alpha");

    const loom = materialBound.mapToStellarLoom(realLoomOptions(materialBound.profile));
    expect(loom.catalog).not.toHaveProperty("material");
    expect(loom.report.entries.filter((entry) => entry.sourcePath.startsWith("material.")).every((entry) => entry.classification === "unsupported")).toBe(true);
  });

  it("computes unverified source identity from the actual canonical profile", () => {
    const profile = loadRealProfile();
    profile.material = { light: { panelAlpha: 0.5, blur: "2px" } };
    const bound = fromUnverifiedProfileV2(profile, { assertedSha256: "0".repeat(64) });
    const canonicalSha256 = computeRawSourceSha256(canonicalizeProfileV2(bound.profile));

    const result = compilePairedV2SolarMaterial(bound, {
      expectedSourceProfileSha256: canonicalSha256,
    });

    expect(result.receipt?.profile.sourceVerification).toBe("unverified-assertion");
    expect(result.receipt?.profile.sourceProfileSha256).toBe(canonicalSha256);
    expect(result.receipt?.profile.sourceProfileSha256).not.toBe("0".repeat(64));
    expect(result.compilation.specification.sourceProfileSha256).toBeUndefined();
    expect(result.sidecar?.sidecar.sourceProfileSha256).toBeUndefined();
    expect(() => compilePairedV2SolarMaterial(bound, {
      expectedSourceProfileSha256: "0".repeat(64),
    })).toThrowError(StaleProvenanceV2Error);
  });

  it("rejects unsafe options and preserves the bound profile", () => {
    const bound = bindSourceProfileV2(readFileSync(REAL_PROFILE_PATH, "utf8"));
    const before = canonicalizeProfileV2(bound.profile);

    expect(() => compilePairedV2SolarMaterial(bound, { unexpected: true } as never)).toThrowError(PairedProfileV2Error);
    const accessorOptions: Record<string, unknown> = {};
    Object.defineProperty(accessorOptions, "solidFallback", {
      enumerable: true,
      get: () => "source-tint",
    });
    expect(() => compilePairedV2SolarMaterial(bound, accessorOptions as never)).toThrowError(PairedProfileV2Error);
    const poisonedOptions = Object.create({ solidFallback: "source-tint" });
    expect(() => compilePairedV2SolarMaterial(bound, poisonedOptions)).toThrowError(PairedProfileV2Error);
    expect(() => compilePairedV2SolarMaterial(bound, { solidFallback: "flatten" } as never)).toThrow();
    expect(canonicalizeProfileV2(bound.profile)).toBe(before);
  });

  it("requires a genuine bound and ignores a replaced genuine mapper", () => {
    const bound = bindSourceProfileV2(readFileSync(REAL_PROFILE_PATH, "utf8"));
    const copied = { ...bound };
    expect(() => compilePairedV2SolarMaterial(copied)).toThrowError(PairedProfileV2Error);

    const materialBound = bound.transform((draft) => {
      draft.material = { light: { panelAlpha: 0.75, blur: "4px" } };
    });
    let mapperCalled = false;
    materialBound.mapToSolarSail = (() => {
      mapperCalled = true;
      throw new Error("caller mapper must not run");
    }) as never;

    const result = compilePairedV2SolarMaterial(materialBound);
    expect(mapperCalled).toBe(false);
    expect(result.sidecar).toBeDefined();
    expect(result.report.sourceVerification).toBe("transformed");
  });

  it("keeps material validation failures in the paired closed error family", () => {
    const bound = bindSourceProfileV2(readFileSync(REAL_PROFILE_PATH, "utf8"));
    let fallbackError: unknown;
    try {
      compilePairedV2SolarMaterial(bound, { solidFallback: "flatten" } as never);
    } catch (error) {
      fallbackError = error;
    }
    expect(fallbackError).toBeInstanceOf(PairedProfileV2Error);
    expect(isPairedProfileV2Error(fallbackError)).toBe(true);
    expect(classifyProfileError(fallbackError)).toMatchObject({
      isProfileError: true,
      code: "V2_SCHEMA_VALIDATION_ERROR",
    });

    const invalidBlur = loadRealProfile();
    invalidBlur.material = { light: { blur: "65px" } };
    let blurError: unknown;
    try {
      fromUnverifiedProfileV2(invalidBlur);
    } catch (error) {
      blurError = error;
    }
    expect(blurError).toBeInstanceOf(PairedProfileV2Error);
    expect(isPairedProfileV2Error(blurError)).toBe(true);
    expect(classifyProfileError(blurError).isProfileError).toBe(true);
  });

  it("keeps the broad source length contract but classifies padded blur as sidecar schema validation", () => {
    const profile = loadRealProfile();
    profile.material = { light: { blur: " 12px " } };

    expect(validatePairedProfileV2(profile).valid).toBe(true);
    const bound = fromUnverifiedProfileV2(profile);
    expect(bound.profile.material?.light?.blur).toBe(" 12px ");

    let failure: unknown;
    try {
      compilePairedV2SolarMaterial(bound);
    } catch (error) {
      failure = error;
    }
    expect(failure).toBeInstanceOf(PairedProfileV2Error);
    expect(classifyProfileError(failure)).toMatchObject({
      isProfileError: true,
      code: "V2_SCHEMA_VALIDATION_ERROR",
    });
    expect(String(failure)).toMatch(/material\.light\.blur/);
  });

  it("cross-binds verified theme, sidecar, and receipt identities", () => {
    const profile = loadRealProfile();
    profile.material = { light: { panelAlpha: 0.8, blur: "6px" } };
    const bound = bindSourceProfileV2(canonicalizeProfileV2(profile));
    const result = compilePairedV2SolarMaterial(bound);
    const sourceSha256 = bound.provenance.rawSourceSha256;

    expect(result.sourceProfileSha256).toBe(sourceSha256);
    expect(result.specification.sourceProfileSha256).toBe(sourceSha256);
    expect(result.sidecar?.sidecar.sourceProfileSha256).toBe(sourceSha256);
    expect(result.sidecar?.descriptor.sourceProfileSha256).toBe(sourceSha256);
    expect(result.receipt?.profile.sourceProfileSha256).toBe(sourceSha256);
    expect(result.receipt?.profile.sourceVerification).toBe("verified");
    expect(result.receipt?.theme.inputDigest).toBe(result.sidecar?.sidecar.theme.inputDigest);
    expect(result.receipt?.theme.outputDigest).toBe(result.sidecar?.sidecar.theme.outputDigest);
  });
});
