import { afterEach, describe, expect, it, vi } from "vitest";
import { mkdtemp, rm, writeFile, symlink } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { runCli, classifyCliFailure } from "../src/cli.js";

const theme = resolve(import.meta.dirname, "../examples/forge-console.theme.json");
const metadata = resolve(import.meta.dirname, "../examples/package-metadata.json");
const owned: string[] = [];
afterEach(async () => { vi.restoreAllMocks(); await Promise.all(owned.splice(0).map(p => rm(p, { recursive: true, force: true }))); });
async function invoke(args: string[]) {
  let stdout = "", stderr = "";
  const out = vi.spyOn(process.stdout, "write").mockImplementation((s: any) => { stdout += s; return true; });
  const err = vi.spyOn(process.stderr, "write").mockImplementation((s: any) => { stderr += s; return true; });
  const exit = await runCli(["node", "tfss", ...args, "--json"]);
  out.mockRestore(); err.mockRestore();
  expect(stderr).toBe("");
  expect(stdout.trim().split("\n")).toHaveLength(1);
  return { exit, result: JSON.parse(stdout) };
}
async function scratch() { const p = await mkdtemp(join(tmpdir(), "tfss-cli-contract-")); owned.push(p); return p; }

describe("structured CLI failure contract", () => {
  it.each([
    ["unknown"], ["validate"], ["validate", theme, "--wat"],
    ["compile", theme, "--out"], ["compile", theme],
    ["validate", theme, "--out", "unused"],
    ["generate", theme, "--out", "unused"],
    ["generate", theme, "--out", "unused", "--package", metadata, "--overwrite"],
    ["generate", theme, "--out", "unused", "--package", metadata, "--language", "bad"],
    ["compile", theme, "--out", "a", "--out", "b"],
  ])("reports argument errors before reading or writing: %j", async (...args) => {
    const { exit, result } = await invoke(args);
    expect(exit).toBe(1); expect(result.code).toBe("ARGUMENT_ERROR");
  });
  it("distinguishes parse, structural validation and unsupported intent", async () => {
    const dir = await scratch(), file = join(dir, "theme.json");
    for (const [raw, code] of [["{", "PARSE_ERROR"], ['{"name":1,"name":2}', "PARSE_ERROR"], ['{"schemaVersion":"tfss.theme-v1"}', "VALIDATION_ERROR"]]) {
      await writeFile(file, raw!); expect((await invoke(["validate", file])).result.code).toBe(code);
    }
    const { readFile } = await import("node:fs/promises");
    const spec = JSON.parse(await readFile(theme, "utf8")); spec.spacing = "1rem";
    await writeFile(file, JSON.stringify(spec));
    expect((await invoke(["validate", file])).result.code).toBe("UNSUPPORTED_INTENT");
  });
  it("preserves warnings by default and makes diagnostic failure opt-in", async () => {
    const dir = await scratch(), file = join(dir, "theme.json");
    const { readFile } = await import("node:fs/promises");
    const spec = JSON.parse(await readFile(theme, "utf8")); spec.palette.light.foreground = spec.palette.light.background;
    await writeFile(file, JSON.stringify(spec));
    expect((await invoke(["validate", file])).exit).toBe(0);
    expect((await invoke(["validate", file, "--fail-on-diagnostics"])).result.code).toBe("DIAGNOSTIC_FAILURE");
  });
  it("reports I/O and filesystem safety separately", async () => {
    const dir = await scratch();
    expect((await invoke(["validate", join(dir, "missing")])).result.code).toBe("IO_ERROR");
    const target = join(dir, "target.css"), link = join(dir, "link.css");
    await writeFile(target, "original"); await symlink(target, link);
    expect((await invoke(["compile", theme, "--out", link, "--overwrite"])).result.code).toBe("FILESYSTEM_SAFETY_ERROR");
    expect(classifyCliFailure(new Error("unexpected"))).toBe("INTERNAL_ERROR");
    expect(classifyCliFailure({ code: "ENOSPC" })).toBe("IO_ERROR");
  });
  it("keeps help and version JSON parseable", async () => {
    expect((await invoke(["--help"])).result.command).toBe("help");
    expect((await invoke(["--version"])).result.command).toBe("version");
  });
});


describe("human CLI terminal sink", () => {
  it("escapes decoded controls in unknown keys and command arguments", async () => {
    const dir = await scratch(), file = join(dir, "hostile.json");
    const hostile = "\u001b]0;spoofed\u0007\u009b31m\r";
    await writeFile(file, JSON.stringify({ [hostile]: true }));
    for (const args of [["validate", file], [hostile]]) {
      let stderr = "";
      const err = vi.spyOn(process.stderr, "write").mockImplementation((s: any) => { stderr += s; return true; });
      expect(await runCli(["node", "tfss", ...args])).toBe(1);
      err.mockRestore();
      expect(stderr).not.toMatch(/[\u0000-\u0009\u000b-\u001f\u007f-\u009f]/);
      expect(stderr).toContain("\\u001b");
      expect(stderr).toContain("spoofed");
    }
    const json = await invoke(["validate", file]);
    expect(json.result.errors.join(" ")).toContain(hostile);
  });
});
