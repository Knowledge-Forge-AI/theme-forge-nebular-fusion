import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { compileTheme, canonicalizeJson, computeSha256 } from "../src/compiler.js";
import { describeGenerationInvocation } from "../src/identity.js";

const theme = JSON.parse(readFileSync(new URL("../examples/forge-console.theme.json", import.meta.url), "utf8"));
const metadata = { name: "@fixture/identity", version: "1.0.0" };
describe("v1 identity domains", () => {
  it("preserves compiler compatibility identities independently of package formatting", () => {
    const compiled = compileTheme(theme);
    const golden = JSON.parse(readFileSync(new URL("./fixtures/v1-identities.json", import.meta.url), "utf8"));
    expect({ inputDigest: compiled.inputDigest, outputDigest: compiled.outputDigest, inventoryDigest: compiled.descriptor.inventoryDigest }).toEqual(golden);
    expect(compiled.inputDigest).toBe(computeSha256(canonicalizeJson(compiled.specification)));
  });
  it("normalizes omitted generator defaults and ignores property insertion order", () => {
    const before = describeGenerationInvocation({ themeSpec: theme, metadata });
    const after = describeGenerationInvocation({ themeSpec: Object.fromEntries(Object.entries(theme).reverse()), metadata: { ...metadata, private: true, license: "AGPL-3.0-or-later", description: `${theme.name} application theme for Tailwind CSS v4 and shadcn/ui` }, language: "javascript" });
    expect(after).toEqual(before);
    expect(before.descriptorInventoryDigest).not.toBe(before.packageInventoryDigest);
    expect(before.outputFiles.some(f => f.path === "provenance.json")).toBe(true);
  });
  it("binds every effective option and provenance-bearing theme input", () => {
    const initial = describeGenerationInvocation({ themeSpec: theme, metadata }).invocationDigest;
    for (const changed of [{ name: "@fixture/changed" }, { version: "1.0.1" }, { description: "changed" }, { author: "author" }, { license: "MIT" }, { private: false }]) {
      expect(describeGenerationInvocation({ themeSpec: theme, metadata: { ...metadata, ...changed } }).invocationDigest).not.toBe(initial);
    }
    expect(describeGenerationInvocation({ themeSpec: theme, metadata, language: "typescript" }).invocationDigest).not.toBe(initial);
    expect(describeGenerationInvocation({ themeSpec: { ...theme, sourceProfileSha256: "a".repeat(64) }, metadata }).invocationDigest).not.toBe(initial);
  });
});


it("preserves ordinary token spaces as explicit v1 identity-bearing spelling", () => {
  const spaced = structuredClone(theme);
  spaced.surfaces.radius = `  ${theme.surfaces.radius}  `;
  const result = compileTheme(spaced);
  expect(result.specification.surfaces.radius).toBe(spaced.surfaces.radius);
  expect(result.inputDigest).not.toBe(compileTheme(theme).inputDigest);
  expect(result.css).toContain(`--radius: ${spaced.surfaces.radius};`);
});
