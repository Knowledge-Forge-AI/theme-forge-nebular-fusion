import { describe, expect, it } from "vitest";
import { readFileSync, existsSync } from "node:fs";
import { resolve } from "node:path";
import { validateThemeSpecification } from "../src/validator.js";
import { compileTheme } from "../src/compiler.js";
import { mapProfileToSolarSail } from "../src/profile.js";
import type { ThemeSpecification } from "../src/types.js";
import type { PairedProfile } from "../src/profile.js";

const fixturesDir = resolve(import.meta.dirname, "fixtures/dogfood");

function loadFixture<T = unknown>(filename: string): T {
  const fullPath = resolve(fixturesDir, filename);
  if (!existsSync(fullPath)) {
    throw new Error(`Required dogfood test fixture missing at ${fullPath}`);
  }
  return JSON.parse(readFileSync(fullPath, "utf8")) as T;
}

describe("Dogfood Fixtures Provenance and Clean-Room Integrity", () => {
  it("maintains recorded revisions, hashes, and licenses in fixture README", () => {
    const readmePath = resolve(fixturesDir, "README.md");
    expect(existsSync(readmePath)).toBe(true);
    const readme = readFileSync(readmePath, "utf8");

    // shadcn-ui_ui provenance
    expect(readme).toContain("3ba91b1cc83e1bbe4ab35a422ff2a694849c5048");
    expect(readme).toContain("cbae6d633c38be59fc036d1e5cf60203ae7619ea6af9b4cdd8d632a211ccffa9");
    expect(readme).toContain("MIT");

    // tweakcn provenance
    expect(readme).toContain("a3b47b37cba97dd637de517aab52c45ec0f83456");
    expect(readme).toContain("50a62c4c47c6d9d679a7f3aab2b1bb85dcca9908ce3e2d5f5c9ff3fabc8aa2ce");
    expect(readme).toContain("Apache-2.0");

    // material-shadcn provenance
    expect(readme).toContain("131586246a9d2305703d9a03a489bb021a278eb6");
    expect(readme).toContain("2744fe3796f177e95bcaaf87a9f0c327b9c5b09af005ac2b1a6952b6d250ce82");

    // flexoki provenance
    expect(readme).toContain("8d723bac4a9ac46adfdf99d42155286977aac72a");
    expect(readme).toContain("15d07c02c17690ef4368fa69e6dfe331bd39e7521e935f74a5477c0d58c1cfc2");

    // Clean-room statement
    expect(readme).toContain("No third-party implementation or source snippet has been copied");
  });

  it("all five clean-room fixture files exist and parse cleanly", () => {
    const files = [
      "chart-sidebar-symmetric.theme.json",
      "alpha-fonts.theme.json",
      "sparse-preset-rejected.theme.json",
      "sidebar-alias-rejected.theme.json",
      "primitive-only-rejected.theme.json",
    ];

    for (const file of files) {
      const data = loadFixture(file);
      expect(data).toBeDefined();
      expect(typeof data).toBe("object");
    }
  });
});

describe("Dogfood Contract 1: Symmetric Optional Chart and Sidebar Roles", () => {
  const theme = loadFixture<ThemeSpecification>("chart-sidebar-symmetric.theme.json");

  it("validates successfully with optional chart and sidebar roles", () => {
    const res = validateThemeSpecification(theme);
    expect(res.valid).toBe(true);
    expect(res.errors).toHaveLength(0);
    expect(res.specification).toBeDefined();
  });

  it("compiles Tailwind v4 @theme inline with chart1-5 and sidebar roles", () => {
    const res = compileTheme(theme);

    // Chart role CSS token mapping in @theme inline
    expect(res.css).toContain("--color-chart-1: var(--chart-1);");
    expect(res.css).toContain("--color-chart-2: var(--chart-2);");
    expect(res.css).toContain("--color-chart-3: var(--chart-3);");
    expect(res.css).toContain("--color-chart-4: var(--chart-4);");
    expect(res.css).toContain("--color-chart-5: var(--chart-5);");

    // Sidebar role CSS token mapping in @theme inline
    expect(res.css).toContain("--color-sidebar: var(--sidebar);");
    expect(res.css).toContain("--color-sidebar-foreground: var(--sidebar-foreground);");
    expect(res.css).toContain("--color-sidebar-primary: var(--sidebar-primary);");
    expect(res.css).toContain("--color-sidebar-primary-foreground: var(--sidebar-primary-foreground);");
    expect(res.css).toContain("--color-sidebar-accent: var(--sidebar-accent);");
    expect(res.css).toContain("--color-sidebar-accent-foreground: var(--sidebar-accent-foreground);");
    expect(res.css).toContain("--color-sidebar-border: var(--sidebar-border);");
    expect(res.css).toContain("--color-sidebar-ring: var(--sidebar-ring);");
  });

  it("emits chart and sidebar CSS variables symmetrically in :root and .dark", () => {
    const res = compileTheme(theme);

    // Light mode values in :root
    expect(res.css).toContain("--chart-1: #e76e50;");
    expect(res.css).toContain("--sidebar: #fafafa;");
    expect(res.css).toContain("--sidebar-primary: #18181b;");

    // Dark mode values in .dark
    expect(res.css).toContain("--chart-1: #2662d9;");
    expect(res.css).toContain("--sidebar: #18181b;");
    expect(res.css).toContain("--sidebar-primary: #18181b;");

    // Structural symmetry check: ensure all optional keys in light exist in dark
    const lightKeys = Object.keys(theme.palette.light).sort();
    const darkKeys = Object.keys(theme.palette.dark).sort();
    expect(lightKeys).toEqual(darkKeys);
  });

  it("strictly rejects asymmetric optional roles between light and dark modes", () => {
    const asymmetricTheme = structuredClone(theme);
    delete (asymmetricTheme.palette.dark as any).sidebar;

    const res = validateThemeSpecification(asymmetricTheme);
    expect(res.valid).toBe(false);
    expect(res.diagnostics.some((d) => d.code === "ASYMMETRIC_COLOR_ROLES")).toBe(true);
  });
});

describe("Dogfood Contract 2: Alpha-Bearing Colors and Extended Typography", () => {
  const theme = loadFixture<ThemeSpecification>("alpha-fonts.theme.json");

  it("validates alpha-bearing colors and diagnoses non-hex contrast pairs as UNEVALUATED_CONTRAST", () => {
    const res = validateThemeSpecification(theme);
    expect(res.valid).toBe(true);
    expect(res.errors).toHaveLength(0);

    // Should emit info diagnostics for non-hex contrast pairs without failing validation
    const unevaluated = res.diagnostics.filter((d) => d.code === "UNEVALUATED_CONTRAST");
    expect(unevaluated.length).toBeGreaterThanOrEqual(1);
    expect(res.diagnostics.every((d) => d.severity !== "error")).toBe(true);
  });

  it("preserves alpha color expressions verbatim in compiled CSS", () => {
    const res = compileTheme(theme);

    // Alpha-bearing expressions must not be altered, stripped, or corrupted
    expect(res.css).toContain("--border: oklch(0 0 0 / 10%);");
    expect(res.css).toContain("--input: oklch(0 0 0 / 15%);");
    expect(res.css).toContain("--ring: rgba(59, 130, 246, 0.5);");
    expect(res.css).toContain("--muted: rgba(240, 242, 245, 0.8);");

    // Dark mode alpha preservation
    expect(res.css).toContain("--border: oklch(1 0 0 / 10%);");
    expect(res.css).toContain("--input: oklch(1 0 0 / 15%);");
    expect(res.css).toContain("--ring: rgba(147, 197, 253, 0.5);");
    expect(res.css).toContain("--muted: rgba(30, 41, 59, 0.8);");
  });

  it("emits extended typography font variables in @theme inline and :root", () => {
    const res = compileTheme(theme);

    expect(res.css).toContain("--font-sans: Geist Sans, system-ui, sans-serif;");
    expect(res.css).toContain("--font-heading: Geist Sans, system-ui, sans-serif;");
    expect(res.css).toContain("--font-mono: Geist Mono, monospace;");

    // @theme inline declarations
    expect(res.css).toContain("--font-sans: var(--font-sans);");
    expect(res.css).toContain("--font-heading: var(--font-heading);");
    expect(res.css).toContain("--font-mono: var(--font-mono);");
  });
});

describe("Dogfood Contract 3: Sparse Preset Rejection", () => {
  const theme = loadFixture<ThemeSpecification>("sparse-preset-rejected.theme.json");

  it("rejects sparse preset omitting mandatory roles at validator boundary", () => {
    const res = validateThemeSpecification(theme);
    expect(res.valid).toBe(false);
    expect(res.errors.length).toBeGreaterThan(0);

    const missingRoleDiagnostics = res.diagnostics.filter(
      (d) => d.code === "MISSING_OR_INVALID_COLOR_ROLE"
    );
    expect(missingRoleDiagnostics.length).toBeGreaterThan(5);

    // Verify specifically that omitted mandatory roles are flagged
    const flaggedPaths = missingRoleDiagnostics.map((d) => d.path);
    expect(flaggedPaths).toContain("palette.light.card");
    expect(flaggedPaths).toContain("palette.light.popover");
    expect(flaggedPaths).toContain("palette.light.secondary");
    expect(flaggedPaths).toContain("palette.light.muted");
    expect(flaggedPaths).toContain("palette.light.accent");
    expect(flaggedPaths).toContain("palette.light.destructive");
    expect(flaggedPaths).toContain("palette.light.border");
    expect(flaggedPaths).toContain("palette.light.input");
    expect(flaggedPaths).toContain("palette.light.ring");
  });

  it("compiler throws on sparse preset instead of silently filling ambient defaults", () => {
    expect(() => compileTheme(theme)).toThrow(/Theme validation failed/);
  });
});

describe("Dogfood Contract 4: Sidebar Alias Rejection and Unsupported Field Isolation", () => {
  const theme = loadFixture<any>("sidebar-alias-rejected.theme.json");

  it("strictly rejects non-canonical sidebar-background alias at validator boundary", () => {
    const res = validateThemeSpecification(theme);
    expect(res.valid).toBe(false);

    const unknownCodes = res.diagnostics.filter((d) => d.code === "UNKNOWN_COLOR_ROLE");
    expect(unknownCodes.length).toBeGreaterThan(0);

    const unknownPaths = unknownCodes.map((d) => d.path);
    expect(unknownPaths).toContain("palette.light.sidebar-background");
    expect(unknownPaths).toContain("palette.dark.sidebar-background");
  });

  it("strictly rejects unsupported tweakcn auxiliary properties", () => {
    const res = validateThemeSpecification(theme);
    expect(res.valid).toBe(false);

    const unknownPaths = res.diagnostics
      .filter((d) => d.code === "UNKNOWN_COLOR_ROLE")
      .map((d) => d.path);

    expect(unknownPaths).toContain("palette.light.shadow-color");
    expect(unknownPaths).toContain("palette.light.shadow-blur");
    expect(unknownPaths).toContain("palette.light.letter-spacing");
    expect(unknownPaths).toContain("palette.light.spacing");
  });

  it("compiler throws on non-canonical sidebar alias without explicit mapping adapter", () => {
    expect(() => compileTheme(theme)).toThrow(/Theme validation failed/);
  });
});

describe("Dogfood Contract 5: Primitive-Only Missing-Role Rejection", () => {
  const theme = loadFixture<ThemeSpecification>("primitive-only-rejected.theme.json");

  it("rejects raw primitive palette ramps without semantic role mapping", () => {
    const res = validateThemeSpecification(theme);
    expect(res.valid).toBe(false);

    const errorCodes = res.diagnostics.map((d) => d.code);
    expect(errorCodes).toContain("MISSING_OR_INVALID_COLOR_ROLE");

    // All 19 mandatory roles must be reported missing
    const missingRoles = res.diagnostics
      .filter((d) => d.code === "MISSING_OR_INVALID_COLOR_ROLE")
      .map((d) => d.path);

    expect(missingRoles).toContain("palette.light.background");
    expect(missingRoles).toContain("palette.light.foreground");
    expect(missingRoles).toContain("palette.light.primary");
    expect(missingRoles).toContain("palette.light.secondary");
  });

  it("compiler throws on primitive-only input without adapter", () => {
    expect(() => compileTheme(theme)).toThrow(/Theme validation failed/);
  });
});

describe("Source Profile Provenance Contract (TFSB71B1 Caller Assertion)", () => {
  it("propagates explicit validated sourceProfileSha256 into compilation result and descriptor", () => {
    const fixture = loadFixture<ThemeSpecification>("chart-sidebar-symmetric.theme.json");
    const testHash = "7c1e5559cf95927514a3bf16f0bbec94a029dbb8eec1317578ec0970a25227bf";

    expect(fixture.sourceProfileSha256).toBe(testHash);

    const result = compileTheme(fixture);

    // Result and descriptor must retain the sourceProfileSha256
    expect(result.sourceProfileSha256).toBe(testHash);
    expect(result.descriptor.sourceProfileSha256).toBe(testHash);

    // Label assertion: explicitly notes this as caller assertion pending source-aware mapper API
    expect(result.descriptor.sourceProfileSha256).toBeDefined();
  });

  it("maps profile with sourceProfileSha256 option into ThemeSpecification", () => {
    const profile: PairedProfile = {
      schemaVersion: "tf-paired-profile-v1",
      name: "dogfood-paired-profile",
      version: "0.1.0",
      description: "Test paired profile with source provenance",
      palette: {
        light: {
          background: "#ffffff",
          foreground: "#09090b",
          card: "#ffffff",
          cardForeground: "#09090b",
          popover: "#ffffff",
          popoverForeground: "#09090b",
          primary: "#18181b",
          primaryForeground: "#fafafa",
          secondary: "#f4f4f5",
          secondaryForeground: "#18181b",
          muted: "#f4f4f5",
          mutedForeground: "#71717a",
          accent: "#f4f4f5",
          accentForeground: "#18181b",
          destructive: "#ef4444",
          destructiveForeground: "#fafafa",
          border: "#e4e4e7",
          input: "#e4e4e7",
          ring: "#18181b",
        },
        dark: {
          background: "#09090b",
          foreground: "#fafafa",
          card: "#09090b",
          cardForeground: "#fafafa",
          popover: "#09090b",
          popoverForeground: "#fafafa",
          primary: "#fafafa",
          primaryForeground: "#18181b",
          secondary: "#27272a",
          secondaryForeground: "#fafafa",
          muted: "#27272a",
          mutedForeground: "#a1a1aa",
          accent: "#27272a",
          accentForeground: "#fafafa",
          destructive: "#7f1d1d",
          destructiveForeground: "#fafafa",
          border: "#27272a",
          input: "#27272a",
          ring: "#d4d4d8",
        },
      },
      surfaces: {
        radius: "0.5rem",
      },
      typography: {
        fontSans: "Inter, sans-serif",
      },
    };

    const callerSha256 = "b4c0ffee0123456789abcdef0123456789abcdef0123456789abcdef01234567";
    const mapped = mapProfileToSolarSail(profile, { sourceProfileSha256: callerSha256 });

    expect(mapped.sourceProfileSha256).toBe(callerSha256);

    const compiled = compileTheme(mapped);
    expect(compiled.sourceProfileSha256).toBe(callerSha256);
    expect(compiled.descriptor.sourceProfileSha256).toBe(callerSha256);
  });
});
