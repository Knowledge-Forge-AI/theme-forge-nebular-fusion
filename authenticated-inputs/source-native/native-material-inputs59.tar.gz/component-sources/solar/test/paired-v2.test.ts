import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { Buffer } from "node:buffer";
import { createHash } from "node:crypto";
import {
  PAIRED_PROFILE_V2_SCHEMA_VERSION,
  MAPPING_REPORT_V2_SCHEMA_VERSION,
  PAIRED_V2_ADAPTER_NAME,
  PAIRED_V2_ADAPTER_VERSION,
  V2_CANONICAL_DOMAIN_TAG,
  validatePairedProfileV2,
  assertValidPairedProfileV2,
  parseProfileV2Json,
  canonicalizeProfileV2,
  computeCanonicalDigestV2,
  computeRawSourceSha256,
  sortKeysUnsignedUtf8,
  compareUtf8Keys,
  hasLoneSurrogates,
  isValidExplicitLength,
  isValidHexColor,
  normalizeHexColor,
  toUnitlessPx,
  mapProfileToSolarSailV2,
  mapProfileToSolarSailWithReportV2,
  mapProfileToStellarLoomV2,
  mapProfileToStellarLoomWithReportV2,
  mapProfileToSyntaxPaletteV2,
  generateMappingReportV2,
  migrateV1ToV2,
  migrateV2ToV1,
  applyRecipe,
  RECIPE_CATALOG,
  bindSourceProfileV2,
  fromUnverifiedProfileV2,
  classifyProfileError,
  isPairedProfileV2Error,
  PairedProfileV2ValidationError,
  PairedProfileV2Error,
  ERROR_CODES,
  StaleProvenanceV2Error,
  MigrationV2Error,
  RecipeError,
  type PairedProfileV2,
  type ColorModeTokensV2,
} from "../src/paired-v2/index.js";

const SOLAR_SAIL_ROOT = resolve(import.meta.dirname, "..");
const FORGE_PROFILE_PATH = resolve(SOLAR_SAIL_ROOT, "examples/forge-console.profile.json");
const FLEXOKI_PROFILE_PATH = resolve(SOLAR_SAIL_ROOT, "examples/flexoki.profile.json");

const loomOptions = () => ({ catalog: JSON.parse(readFileSync(resolve(SOLAR_SAIL_ROOT,"../stellar-loom/examples/loom-flexoki-catalog.json"),"utf8")), tokenSetKey: "flexoki-palette", primaryFamily: "cyan", secondaryFamily: "orange", defaultAccent: "cyan", familyBindings: {"Inter, sans-serif":"system-sans",monospace:"system-mono"} });
function makeValidBaseProfile(): PairedProfileV2 {
  const lightColors: ColorModeTokensV2 = {
    canvas: "#ffffff",
    canvasText: "#111111",
    surface: "#f8f8f8",
    surfaceText: "#111111",
    elevatedSurface: "#ffffff",
    elevatedSurfaceText: "#111111",
    primaryAction: "#0066cc",
    primaryActionText: "#ffffff",
    secondaryAction: "#e5e5e5",
    secondaryActionText: "#111111",
    mutedSurface: "#f0f0f0",
    mutedText: "#666666",
    highlight: "#ff9900",
    highlightText: "#000000",
    danger: "#cc0000",
    dangerText: "#ffffff",
    border: "#cccccc",
    fieldBorder: "#999999",
    focus: "#0066cc",
  };

  const darkColors: ColorModeTokensV2 = {
    canvas: "#111111",
    canvasText: "#ffffff",
    surface: "#1a1a1a",
    surfaceText: "#ffffff",
    elevatedSurface: "#222222",
    elevatedSurfaceText: "#ffffff",
    primaryAction: "#3399ff",
    primaryActionText: "#000000",
    secondaryAction: "#333333",
    secondaryActionText: "#ffffff",
    mutedSurface: "#222222",
    mutedText: "#999999",
    highlight: "#ffaa33",
    highlightText: "#000000",
    danger: "#ff3333",
    dangerText: "#ffffff",
    border: "#444444",
    fieldBorder: "#666666",
    focus: "#3399ff",
  };

  return {
    schemaVersion: PAIRED_PROFILE_V2_SCHEMA_VERSION,
    name: "test-neutral",
    version: "1.0.0",
    description: "Neutral test profile",
    color: {
      light: lightColors,
      dark: darkColors,
    },
    typography: {
      body: { family: "Inter, sans-serif", size: "1rem", lineHeight: 1.5 },
      heading: { family: "Inter, sans-serif", size: "2rem", lineHeight: 1.2 },
      ui: { family: "Inter, sans-serif" },
      code: { family: "monospace" },
    },
    radius: {
      control: "0.375rem",
      surface: "0.5rem",
      overlay: "0.75rem",
    },
    spacing: {
      base: "1rem",
      density: "comfortable",
    },
    elevation: {
      emphasis: "flat",
      borderWidth: "1px",
      borderStyle: "solid",
    },
    focus: {
      color: { light: "#0066cc", dark: "#3399ff" },
      width: "2px",
      offset: "2px",
    },
    code: {
      syntax: {
        light: {
          comment: "#666666",
          string: "#008800",
          number: "#cc6600",
          constant: "#cc6600",
          keyword: "#880088",
          function: "#0066cc",
          type: "#0066cc",
          variable: "#111111",
          punctuation: "#666666",
          tag: "#880088",
          attribute: "#cc6600",
        },
        dark: {
          comment: "#999999",
          string: "#33cc33",
          number: "#ff9933",
          constant: "#ff9933",
          keyword: "#cc33cc",
          function: "#3399ff",
          type: "#3399ff",
          variable: "#ffffff",
          punctuation: "#999999",
          tag: "#cc33cc",
          attribute: "#ff9933",
        },
      },
      frame: "editor",
      copy: "standard",
    },
    reading: {
      measure: "704px",
    },
    navigation: {
      prominence: "balanced",
      density: "comfortable",
    },
    targetOverrides: {
      version: "v2",
      solarSail: {
        surfaces: {
          radius: "0.5rem",
        },
      },
      loom: {
        content: 704,
        radii: 8,
        border: 1,
      },
    },
  };
}

describe("Paired Profile v2 Strict Neutral Schema Validation", () => {
  it("validates a complete neutral nine-group profile successfully", () => {
    const profile = makeValidBaseProfile();
    const result = validatePairedProfileV2(profile);

    expect(result.valid).toBe(true);
    expect(result.errors).toHaveLength(0);
    expect(result.profile).toBeDefined();
    expect(result.profile?.schemaVersion).toBe("tf-paired-profile-v2");
    expect(result.profile?.color.light.canvas).toBe("#ffffff");
  });

  it("permits minimal valid profile with only required color group", () => {
    const minimal: PairedProfileV2 = {
      schemaVersion: PAIRED_PROFILE_V2_SCHEMA_VERSION,
      name: "minimal-profile",
      version: "0.1.0",
      color: makeValidBaseProfile().color,
    };

    const result = validatePairedProfileV2(minimal);
    expect(result.valid).toBe(true);
    expect(result.errors).toHaveLength(0);
    expect(result.profile?.typography).toBeUndefined();
    expect(result.profile?.radius).toBeUndefined();
  });

  describe("Negative Schema Tests", () => {
    it("rejects shadcn/SolarSail family-centric roles at root color", () => {
      const p: any = makeValidBaseProfile();
      p.color.light.background = "#ffffff";
      p.color.light.card = "#f0f0f0";
      p.color.light.chart1 = "#ff0000";

      const res = validatePairedProfileV2(p);
      expect(res.valid).toBe(false);
      expect(res.errors.some((e) => e.includes("background"))).toBe(true);
      expect(res.errors.some((e) => e.includes("chart1"))).toBe(true);
    });

    it("rejects fontSans alias in universal typography", () => {
      const p: any = makeValidBaseProfile();
      p.typography.fontSans = "sans-serif";

      const res = validatePairedProfileV2(p);
      expect(res.valid).toBe(false);
      expect(res.errors.some((e) => e.includes("fontSans is rejected"))).toBe(true);
    });

    it("rejects missing mandatory neutral color role", () => {
      const p: any = makeValidBaseProfile();
      delete p.color.light.canvasText;

      const res = validatePairedProfileV2(p);
      expect(res.valid).toBe(false);
      expect(res.errors.some((e) => e.includes("canvasText' is required"))).toBe(true);
    });

    it("rejects non-hex color formats", () => {
      const p: any = makeValidBaseProfile();
      p.color.light.primaryAction = "rgb(0, 100, 200)";
      p.color.dark.primaryAction = "hsl(200, 100%, 50%)";

      const res = validatePairedProfileV2(p);
      expect(res.valid).toBe(false);
      expect(res.errors.some((e) => e.includes("hex sRGB color"))).toBe(true);
    });

    it("rejects invalid explicit lengths with % or pt units", () => {
      const p: any = makeValidBaseProfile();
      p.radius.control = "10%";
      p.elevation.borderWidth = "2pt";

      const res = validatePairedProfileV2(p);
      expect(res.valid).toBe(false);
      expect(res.errors.some((e) => e.includes("radius.control"))).toBe(true);
      expect(res.errors.some((e) => e.includes("elevation.borderWidth"))).toBe(true);
    });

    it("rejects unknown top-level keys", () => {
      const p: any = makeValidBaseProfile();
      p.unknownKey = "invalid";

      const res = validatePairedProfileV2(p);
      expect(res.valid).toBe(false);
      expect(res.errors.some((e) => e.includes("Unknown top-level field 'unknownKey'"))).toBe(true);
    });

    it("rejects invalid schemaVersion", () => {
      const p: any = makeValidBaseProfile();
      p.schemaVersion = "tf-paired-profile-v3";

      const res = validatePairedProfileV2(p);
      expect(res.valid).toBe(false);
      expect(res.errors.some((e) => e.includes("Invalid schemaVersion"))).toBe(true);
    });

    it("rejects targetOverrides with missing or invalid version", () => {
      const p: any = makeValidBaseProfile();
      p.targetOverrides.version = "v1";

      const res = validatePairedProfileV2(p);
      expect(res.valid).toBe(false);
      expect(res.errors.some((e) => e.includes("targetOverrides.version must be 'v2'"))).toBe(true);
    });

    it("rejects unknown targetOverrides properties", () => {
      const p: any = makeValidBaseProfile();
      p.targetOverrides.unknownPlatform = { setting: true };

      const res = validatePairedProfileV2(p);
      expect(res.valid).toBe(false);
      expect(res.errors.some((e) => e.includes("Unknown targetOverrides field 'unknownPlatform'"))).toBe(true);
    });

    it("rejects asymmetric light and dark roles", () => {
      const p = makeValidBaseProfile();
      p.color.light.hover = "#eeeeee";
      // dark does not have hover

      const res = validatePairedProfileV2(p);
      expect(res.valid).toBe(false);
      expect(res.errors.some((e) => e.includes("defined in color.light but missing in color.dark"))).toBe(true);
    });
  });
});

describe("Canonical Serializer & Unicode / Numeric Safety", () => {
  it("sorts keys by unsigned UTF-8 bytes rather than UTF-16 code units", () => {
    // In unsigned UTF-8:
    // 'a' = 0x61
    // 'z' = 0x7a
    // '\u00e9' (é) = 0xc3 0xa9 (byte 0xc3 > 0x7a)
    // In UTF-16, '\u00e9'.charCodeAt(0) = 0xe9 > 0x7a
    // But compare with '\ufffe' vs multi-byte characters
    const a = "\u00e9"; // 0xc3 0xa9
    const b = "z"; // 0x7a
    expect(compareUtf8Keys(a, b)).toBeGreaterThan(0);
    expect(compareUtf8Keys(b, a)).toBeLessThan(0);

    const unsorted = { z: 1, a: 2, "\u00e9": 3 };
    const sorted = sortKeysUnsignedUtf8(unsorted) as Record<string, number>;
    expect(Object.keys(sorted)).toEqual(["a", "z", "\u00e9"]);
  });

  it("rejects input containing lone surrogates", () => {
    const loneHigh = "test\ud800test";
    expect(hasLoneSurrogates(loneHigh)).toBe(true);

    const loneLow = "test\udc00test";
    expect(hasLoneSurrogates(loneLow)).toBe(true);

    const validPair = "test\ud83d\ude00test"; // 😀
    expect(hasLoneSurrogates(validPair)).toBe(false);

    expect(() => parseProfileV2Json(`{"name": "test\ud800"}`)).toThrow();
  });

  it("rejects negative zero (-0) and non-finite numbers", () => {
    const rawNegativeZero = `{"schemaVersion":"tf-paired-profile-v2","name":"neg-zero","version":"1.0.0","color":{},"targetOverrides":{"version":"v2","loom":{"content": -0}}}`;
    expect(() => parseProfileV2Json(rawNegativeZero)).toThrow();
  });

  it("rejects duplicate JSON keys", () => {
    const duplicateKeyJson = `{"schemaVersion":"tf-paired-profile-v2","name":"dup","name":"dup2"}`;
    expect(() => parseProfileV2Json(duplicateKeyJson)).toThrow();
  });

  it("produces deterministic canonical compact JSON with ending LF", () => {
    const profile = makeValidBaseProfile();
    const json = canonicalizeProfileV2(profile);

    expect(json.endsWith("\n")).toBe(true);
    expect(json.indexOf("\n")).toBe(json.length - 1); // exactly one newline at the very end
    expect(JSON.parse(json)).toEqual(profile);
  });

  it("computes domain-separated canonical digest with tf-paired-profile-v2\\n prefix", () => {
    const profile = makeValidBaseProfile();
    const json = canonicalizeProfileV2(profile);
    const digest = computeCanonicalDigestV2(json);

    expect(digest).toMatch(/^[0-9a-f]{64}$/);
  });
});

describe("Migrations: v1 <-> v2", () => {
  it("upgrades Forge Console v1 profile to neutral v2 with semantic preservation", () => {
    const rawV1 = readFileSync(FORGE_PROFILE_PATH, "utf8");
    const migration = migrateV1ToV2(rawV1);

    expect(migration.isLossless).toBe(true);
    expect(migration.losses).toHaveLength(0);
    expect(migration.toVersion).toBe(PAIRED_PROFILE_V2_SCHEMA_VERSION);

    const v2 = migration.profile;
    // Check color role mapping
    expect(v2.color.light.canvas).toBe("#fff8f0"); // background -> canvas
    expect(v2.color.light.canvasText).toBe("#262a33"); // foreground -> canvasText
    expect(v2.color.light.primaryAction).toBe("#126475"); // primary -> primaryAction
    expect(v2.color.light.focus).toBe("#126475"); // ring -> focus
    expect(v2.color.light.danger).toBe("#dc2626"); // destructive -> danger

    // Check typography
    expect(v2.typography?.body?.family).toContain("system-ui");
    expect(v2.typography?.heading?.family).toContain("system-ui");
    expect(v2.typography?.code?.family).toContain("ui-monospace");

    // Check radius & reading
    expect(v2.radius?.control).toBe("0.5rem");
    expect(v2.reading?.measure).toBe("704px");

    // Verify NO synthetic semantic defaults injected
    expect(v2.spacing).toBeUndefined();
    expect(v2.focus).toBeUndefined();
    expect(v2.navigation).toBeUndefined();
    expect(v2.radius?.surface).toBeUndefined();
    expect(v2.radius?.overlay).toBeUndefined();

    // Verify v2 profile validates strictly
    expect(() => assertValidPairedProfileV2(v2)).not.toThrow();
  });

  it("upgrades Flexoki v1 profile and preserves targetOverrides", () => {
    const rawV1 = readFileSync(FLEXOKI_PROFILE_PATH, "utf8");
    const migration = migrateV1ToV2(rawV1);

    expect(migration.isLossless).toBe(true);
    expect(migration.toVersion).toBe(PAIRED_PROFILE_V2_SCHEMA_VERSION);

    const v2 = migration.profile;
    expect(v2.color.light.primaryAction).toBe("#24837b");
    expect(v2.targetOverrides?.version).toBe("v2");
    expect(v2.targetOverrides?.loom?.defaultAccent).toBe("cyan");
    expect(v2.targetOverrides?.syntax?.syntax?.light?.comment).toBe("#6f6e69");

    expect(() => assertValidPairedProfileV2(v2)).not.toThrow();
  });

  it("lossy downgrade fails closed by default when v2 contains unrepresentable fields", () => {
    const profile = makeValidBaseProfile();
    // makeValidBaseProfile contains spacing, radius.surface, elevation.emphasis, etc.
    expect(() => migrateV2ToV1(canonicalizeProfileV2(profile))).toThrowError(MigrationV2Error);
  });

  it("lossy downgrade succeeds when allowLossy is explicitly enabled", () => {
    const profile = makeValidBaseProfile();
    const migration = migrateV2ToV1(canonicalizeProfileV2(profile), { allowLossy: true });

    expect(migration.isLossless).toBe(false);
    expect(migration.losses.length).toBeGreaterThan(0);
    expect(migration.toVersion).toBe("tf-paired-profile-v1");

    // Ensure losses enumerate specific dropped leaves truthfully
    const lossPaths = migration.losses.map((l) => l.path);
    expect(lossPaths.sort()).toEqual([
      ...["light", "dark"].flatMap(mode => ["comment", "string", "number", "constant", "keyword", "function", "type", "variable", "punctuation", "tag", "attribute"].map(category => `code.syntax.${mode}.${category}`)),
      "code.copy", "code.frame", "elevation.borderStyle", "elevation.emphasis",
      "focus.color.dark", "focus.color.light", "focus.offset", "focus.width",
      "navigation.density", "navigation.prominence", "radius.overlay", "radius.surface",
      "spacing.base", "spacing.density", "targetOverrides.loom.border", "targetOverrides.loom.radii",
      "typography.body.lineHeight", "typography.body.size", "typography.heading.lineHeight",
      "typography.heading.size", "typography.ui.family",
    ].sort());

    // The downgraded v1 profile should have valid v1 properties
    const v1 = migration.profile;
    expect(v1.schemaVersion).toBe("tf-paired-profile-v1");
    expect(v1.palette.light.background).toBe("#ffffff");
    expect(v1.palette.light.primary).toBe("#0066cc");
    expect(v1.surfaces.radius).toBe("0.375rem");
  });
});

describe("Mapping Reports (Truthful 5 Status Accounting)", () => {
  it("partitions every supplied semantic leaf into exactly the 5 allowed statuses for Solar Sail", () => {
    const profile = makeValidBaseProfile();
    const report = generateMappingReportV2(profile, "solar-sail");

    expect(report.schema).toBe(MAPPING_REPORT_V2_SCHEMA_VERSION);
    expect(report.target).toBe("solar-sail");

    const validStatuses = new Set([
      "consumed",
      "normalized",
      "overridden",
      "target-specific",
      "unsupported",
    ]);

    for (const entry of report.entries) {
      expect(validStatuses.has(entry.classification)).toBe(true);
    }

    const { summary } = report;
    const sum =
      summary.consumed +
      summary.normalized +
      summary.overridden +
      summary.targetSpecific +
      summary.unsupported;

    expect(summary.totalSemanticLeaves).toBe(report.entries.length);
    expect(sum).toBe(summary.totalSemanticLeaves);

    // Overridden check: radius.control was overridden by solarSail.surfaces.radius
    const radiusEntry = report.entries.find((e) => e.sourcePath === "radius.control");
    expect(radiusEntry?.classification).toBe("overridden");

    // Target-specific check: loom overrides are retained for Loom
    const loomOverrideEntry = report.entries.find((e) => e.sourcePath === "targetOverrides.loom.content");
    expect(loomOverrideEntry?.classification).toBe("target-specific");

    // Unsupported check: spacing has no native Solar Sail effect
    const spacingEntry = report.entries.find((e) => e.sourcePath === "spacing.density");
    expect(spacingEntry?.classification).toBe("unsupported");
  });

  it("partitions every supplied semantic leaf into exactly the 5 allowed statuses for Stellar Loom", () => {
    const profile = makeValidBaseProfile();
    const report = generateMappingReportV2(profile, "stellar-loom", loomOptions());

    expect(report.schema).toBe(MAPPING_REPORT_V2_SCHEMA_VERSION);
    expect(report.target).toBe("stellar-loom");

    const { summary } = report;
    const sum =
      summary.consumed +
      summary.normalized +
      summary.overridden +
      summary.targetSpecific +
      summary.unsupported;

    expect(summary.totalSemanticLeaves).toBe(report.entries.length);
    expect(sum).toBe(summary.totalSemanticLeaves);

    // Solar override is target-specific (retained for solar-sail)
    const ssOverrideEntry = report.entries.find(
      (e) => e.sourcePath === "targetOverrides.solarSail.surfaces.radius"
    );
    expect(ssOverrideEntry?.classification).toBe("target-specific");
  });

  it("separates generated defaults from source semantic leaves", () => {
    const minimal: PairedProfileV2 = {
      schemaVersion: PAIRED_PROFILE_V2_SCHEMA_VERSION,
      name: "defaults-test",
      version: "1.0.0",
      color: makeValidBaseProfile().color,
    };

    const report = generateMappingReportV2(minimal, "solar-sail");
    // Semantic leaves only include the 38 color tokens (19 light + 19 dark)
    expect(report.summary.totalSemanticLeaves).toBe(38);

    // Defaults are separate: description, surfaces.radius, typography.fontSans
    expect(report.defaults.length).toBeGreaterThan(0);
    expect(report.summary.generatedDefaultsCount).toBe(report.defaults.length);
  });
});

describe("Closeout report and validation regressions", () => {
  it("distinguishes original, transformed and serialized source provenance for both targets", () => {
    const bound = bindSourceProfileV2(JSON.stringify(makeValidBaseProfile()));
    const transformed = bound.transform(draft => { draft.name = "transformed"; });
    for (const [original, changed] of [
      [bound.mapToSolarSail(), transformed.mapToSolarSail()],
      [bound.mapToStellarLoom(loomOptions()), transformed.mapToStellarLoom(loomOptions())],
    ]) {
      expect(original.report.sourceVerification).toBe("source-bytes");
      expect(changed.report.sourceVerification).toBe("transformed");
      expect(changed.report.sourceSha256).toBe(transformed.provenance.rawSourceSha256);
      expect(changed.report.digest).not.toBe(original.report.digest);
    }
    expect(generateMappingReportV2(bound.profile, "solar-sail").sourceVerification).toBe("serialized-profile");
  });

  it("counts only surviving adapter defaults in Loom syntax and chrome", () => {
    const profile = makeValidBaseProfile();
    delete profile.code;
    const report = generateMappingReportV2(profile, "stellar-loom", loomOptions());
    expect(report.defaults.map(e => e.targetPath).sort()).toEqual(["copy", "frame", "tabs.activeIndicator"]);
    profile.color.light.primaryAction = "#12345680";
    const rejected = generateMappingReportV2(profile, "stellar-loom", loomOptions());
    const fallbackPaths = ["syntax.light.string", "syntax.light.keyword", "syntax.light.function", "syntax.light.type", "syntax.light.tag", "chrome.light.tooltipSuccessBackground"];
    expect(rejected.defaults.filter(e => fallbackPaths.includes(e.targetPath))).toHaveLength(6);
    for (const path of fallbackPaths) expect(rejected.defaults.find(e => e.targetPath === path)).toMatchObject({targetValue: "#000000", reason: "Adapter fallback; no supported source projection"});
    profile.targetOverrides!.syntax = {syntax: {light: {string: "#abcdef"}}, chrome: {light: {tooltipSuccessBackground: "#abcdef"}}, frame: "plain"};
    const overridden = generateMappingReportV2(profile, "stellar-loom", loomOptions());
    expect(overridden.defaults.some(e => ["syntax.light.string", "chrome.light.tooltipSuccessBackground", "frame"].includes(e.targetPath))).toBe(false);
    expect(overridden.summary.generatedDefaultsCount).toBe(overridden.defaults.length);
  });

  it("declares target group capability independently of supplied leaves", () => {
    const profile = makeValidBaseProfile();
    delete profile.spacing; delete profile.radius;
    const solar = generateMappingReportV2(profile, "solar-sail");
    const loom = generateMappingReportV2(profile, "stellar-loom", loomOptions());
    expect(solar.groups.find(g => g.group === "radius")?.applicable).toBe(true);
    expect(solar.groups.find(g => g.group === "spacing")?.applicable).toBe(false);
    expect(loom.groups.find(g => g.group === "spacing")?.applicable).toBe(true);
    profile.spacing = {base: "1rem"};
    expect(generateMappingReportV2(profile, "stellar-loom", loomOptions()).groups.find(g => g.group === "spacing")?.applicable).toBe(true);
  });

  it("preserves normalization when an overridden color retains other effects", () => {
    const profile = makeValidBaseProfile();
    profile.color.light.primaryAction = "#ABC";
    const report = generateMappingReportV2(profile, "stellar-loom", loomOptions());
    expect(report.entries.find(e => e.sourcePath === "color.light.primaryAction")).toMatchObject({classification: "normalized"});
  });

  it("preserves authored color identity without freezing caller-owned override objects", () => {
    const profile = makeValidBaseProfile();
    profile.color.light.canvas = "#FFF";
    profile.focus!.color!.light = "#ABC";
    profile.code!.syntax!.light!.comment = "#DEF";
    profile.targetOverrides!.syntax = {syntax: {light: {comment: "#ABC"}}, tabs: {activeIndicator: "top"}};
    const before = canonicalizeProfileV2(profile);
    const result = validatePairedProfileV2(profile);
    expect(result.valid).toBe(true);
    expect(canonicalizeProfileV2(result.profile)).toBe(before);
    expect(Object.isFrozen(result.profile!.targetOverrides!.syntax!.syntax!.light)).toBe(true);
    expect(Object.isFrozen(profile.targetOverrides!.syntax!.syntax!.light)).toBe(false);
    profile.targetOverrides!.syntax!.syntax!.light!.comment = "#123456";
    expect(result.profile!.targetOverrides!.syntax!.syntax!.light!.comment).toBe("#ABC");
  });
});

describe("Finite Versioned Recipes", () => {
  it("applies density recipe with structured deltas", () => {
    const profile = makeValidBaseProfile();
    const result = applyRecipe(canonicalizeProfileV2(profile), {schema:"tf-paired-recipe-v1",type:"density",variant:"compact"});

    expect(result.recipeName).toBe("compact");
    expect(result.recipeType).toBe("density");
    expect(result.profile.spacing?.density).toBe("compact");
    expect(result.profile.navigation).toEqual(profile.navigation);

    const densityDelta = result.deltas.find((d) => d.path === "spacing");
    expect(densityDelta?.before).toEqual(profile.spacing);
    expect(densityDelta?.after).toEqual({base:"6px",density:"compact"});

    // Result validates strictly
    expect(() => assertValidPairedProfileV2(result.profile)).not.toThrow();
  });

  it("applies radius recipe with structured deltas", () => {
    const profile = makeValidBaseProfile();
    const result = applyRecipe(canonicalizeProfileV2(profile), {schema:"tf-paired-recipe-v1",type:"radius",variant:"sharp"});

    expect(result.recipeName).toBe("sharp");
    expect(result.recipeType).toBe("radius");
    expect(result.profile.radius?.control).toBe("0px");
    expect(result.profile.radius?.surface).toBe("0px");

    const controlDelta = result.deltas.find((d) => d.path === "radius");
    expect(controlDelta?.before).toEqual(profile.radius);
    expect(controlDelta?.after).toEqual({control:"0px",surface:"0px",overlay:"0px"});
  });

  it("applies typography recipe with structured deltas", () => {
    const profile = makeValidBaseProfile();
    const result = applyRecipe(canonicalizeProfileV2(profile), {schema:"tf-paired-recipe-v1",type:"typography",variant:"editorial"});

    expect(result.recipeName).toBe("editorial");
    expect(result.recipeType).toBe("typography");
    expect(result.profile.typography?.heading?.family).toContain("Georgia");
    expect(result.profile.typography?.body).toEqual(profile.typography?.body);
  });

  it("rejects unknown recipe", () => {
    const profile = makeValidBaseProfile();
    expect(() => applyRecipe(canonicalizeProfileV2(profile), {schema:"tf-paired-recipe-v1",type:"radius",variant:"non-existent-recipe"})).toThrowError(RecipeError);
  });
});

describe("Bound Profile & Provenance", () => {
  it("preserves canonical identity for pretty-printed bytes and records explicit parent provenance (MEDIUM-5)", () => {
    const profile = makeValidBaseProfile();
    const sources = [
      Buffer.from(JSON.stringify(profile, null, 2) + "\n", "utf8"),
      Buffer.from("\n" + JSON.stringify(profile, null, 4) + "\n\n", "utf8"),
    ];
    const [first, second] = sources.map((source) => bindSourceProfileV2(source));

    for (const bound of [first!, second!]) {
      expect(bound.provenance.verificationStatus).toBe("verified");
      expect(bound.provenance.isTransformed).toBe(false);
      expect(bound.provenance.parentSourceSha256).toBeUndefined();
      expect(bound.provenance.canonicalDigest).toMatch(/^[0-9a-f]{64}$/);
    }
    expect(first!.provenance.canonicalDigest).toBe(second!.provenance.canonicalDigest);
    expect(first!.provenance.rawSourceSha256).not.toBe(second!.provenance.rawSourceSha256);

    const transformed = first!.transform((draft) => ({ ...draft, name: "transformed-v2" }));
    expect(transformed.provenance.verificationStatus).toBe("transformed");
    expect(transformed.provenance.isTransformed).toBe(true);
    expect(transformed.provenance.parentSourceSha256).toBe(first!.provenance.rawSourceSha256);
  });

  it("binds source bytes, computes SHA-256 and canonical digest", () => {
    const profile = makeValidBaseProfile();
    const json = canonicalizeProfileV2(profile);
    const bound = bindSourceProfileV2(json);

    expect(bound.provenance.verificationStatus).toBe("verified");
    expect(bound.provenance.isTransformed).toBe(false);
    expect(bound.provenance.rawSourceSha256).toBe(computeRawSourceSha256(Buffer.from(json, "utf8")));

    const solarRes = bound.mapToSolarSail();
    expect(solarRes.specification.name).toBe("test-neutral");
    expect(solarRes.report.summary.totalSemanticLeaves).toBeGreaterThan(0);

    const loomRes = bound.mapToStellarLoom(loomOptions());
    expect(loomRes.catalog.name).toBe("test-neutral");
    expect(loomRes.syntax.syntax.light.comment).toBeDefined();
  });

  it("throws StaleProvenanceV2Error on expected SHA mismatch", () => {
    const profile = makeValidBaseProfile();
    const json = canonicalizeProfileV2(profile);
    const fakeHash = "0000000000000000000000000000000000000000000000000000000000000000";

    expect(() => bindSourceProfileV2(json, { expectedSha256: fakeHash })).toThrowError(
      StaleProvenanceV2Error
    );
  });

  it("tracks provenance lineage through immutable transform", () => {
    const profile = makeValidBaseProfile();
    const json = canonicalizeProfileV2(profile);
    const bound = bindSourceProfileV2(json);

    const transformed = bound.transform((draft) => {
      draft.name = "transformed-profile";
    });

    expect(transformed.profile.name).toBe("transformed-profile");
    expect(transformed.provenance.isTransformed).toBe(true);
    expect(transformed.provenance.verificationStatus).toBe("transformed");
    expect(transformed.provenance.parentSourceSha256).toBe(bound.provenance.rawSourceSha256);
  });
});

describe("Instance-Independent Error Classifier", () => {
  it("classifies error instances across module boundaries without instanceof", () => {
    const valErr = new PairedProfileV2ValidationError("Test validation error", ["Error 1", "Error 2"]);
    const classification = classifyProfileError(valErr);

    expect(classification.isProfileError).toBe(true);
    expect(classification.name).toBe("PairedProfileV2ValidationError");
    expect(classification.errors).toEqual(["Error 1", "Error 2"]);

    // Duck-typed error object
    const duckErr = {
      isPairedProfileError: true,
      name: "PairedProfileV2ValidationError",
      code: "V2_SCHEMA_VALIDATION_ERROR",
      message: "Duck error",
      errors: ["Simulated error"],
    };

    expect(isPairedProfileV2Error(duckErr)).toBe(true);
    const duckClassification = classifyProfileError(duckErr);
    expect(duckClassification.isProfileError).toBe(true);
    expect(duckClassification.errors).toEqual(["Simulated error"]);
  });

  it("correctly identifies non-profile errors", () => {
    const standardErr = new Error("Generic error");
    const classification = classifyProfileError(standardErr);

    expect(classification.isProfileError).toBe(false);
    expect(classification.message).toBe("Generic error");
  });
});

describe("v2 hostile bytes, losses and actual effects", () => {
  it.each(['{"a":1,"a":2}', '{"a":-0}', '{"a":9007199254740992}', '{"a":"\\ud800"}', '{"__proto__":{}}'])('rejects unsafe JSON %s with public classification', text => {
    let error;try{parseProfileV2Json(text);}catch(e){error=e;}
    expect(error).toBeDefined();expect(classifyProfileError(error).isProfileError).toBe(true);
  });
  it('rejects accessors without executing them and sparse arrays',()=>{
    let calls=0;const data=Object.defineProperty({},'color',{get(){calls++;return {};},enumerable:true});
    expect(()=>canonicalizeProfileV2(data)).toThrow();expect(calls).toBe(0);expect(()=>canonicalizeProfileV2(new Array(2))).toThrow();
  });
  it('orders numeric-looking and non-ASCII keys by UTF-8 bytes',()=>{
    expect(canonicalizeProfileV2({'2':2,'10':10,'é':3,'z':4})).toBe('{"10":10,"2":2,"z":4,"é":3}\n');
  });
  it('does not create semantic leaves from empty containers',()=>{
    const p=makeValidBaseProfile();const before=generateMappingReportV2(p,'solar-sail');p.navigation={};
    const after=generateMappingReportV2(p,'solar-sail');expect(after.entries.some(e=>e.sourcePath==='navigation')).toBe(false);
    expect(after.entries.length).toBe(before.entries.length-2);
  });
  it('validates nested syntax overrides and unknown native roles',()=>{
    for(const change of [{syntax:{light:{execute:'red'}}},{tabs:{execute:true}},{frame:'unknown'}]){
      const p=makeValidBaseProfile();p.targetOverrides={version:'v2',syntax:change as any};expect(validatePairedProfileV2(p).valid).toBe(false);
    }
  });
  it('reports alpha and relative Loom intent unsupported, without guessed conversion',()=>{
    const p=makeValidBaseProfile();p.color.light.canvas='#ffffff80';const r=bindSourceProfileV2(JSON.stringify(p)).mapToStellarLoom(loomOptions());
    expect(r.report.entries.find(e=>e.sourcePath==='color.light.canvas')?.classification).toBe('unsupported');
    expect(r.report.entries.find(e=>e.sourcePath==='radius.surface')?.classification).toBe('unsupported');
  });
  it('projects explicit syntax override and marks fully replaced source intent',()=>{
    const p=makeValidBaseProfile();p.code={frame:'editor',syntax:{light:{keyword:'#123456'}}};p.targetOverrides={version:'v2',syntax:{frame:'plain',syntax:{light:{keyword:'#abcdef'}}} as any};
    const r=bindSourceProfileV2(JSON.stringify(p)).mapToStellarLoom(loomOptions());expect(r.syntax.frame).toBe('plain');expect(r.syntax.syntax.light.keyword).toBe('#abcdef');
    for(const path of ['code.frame','code.syntax.light.keyword'])expect(r.report.entries.find(e=>e.sourcePath===path)?.classification).toBe('overridden');
  });
  it('preserves exact source spelling separately from canonical identity',()=>{
    const p=makeValidBaseProfile(),a=bindSourceProfileV2(JSON.stringify(p)),b=bindSourceProfileV2(JSON.stringify(p,null,2));
    expect(a.provenance.rawSourceSha256).not.toBe(b.provenance.rawSourceSha256);expect(a.provenance.canonicalDigest).toBe(b.provenance.canonicalDigest);
    expect(a.mapToSolarSail().report.digest).not.toBe(b.mapToSolarSail().report.digest);
    expect(()=>bindSourceProfileV2(JSON.stringify(p),{expectedSha256:''})).toThrow();
  });
  it('roundtrips unambiguous v1 and binds actual bytes to both migrations',()=>{
    const source=readFileSync(FLEXOKI_PROFILE_PATH,'utf8'),up=migrateV1ToV2(source),down=migrateV2ToV1(canonicalizeProfileV2(up.profile));
    expect(down.isLossless).toBe(true);expect(down.profile).toEqual(JSON.parse(source));
    expect(()=>migrateV1ToV2(JSON.parse(source) as any)).toThrow();
    expect(()=>migrateV1ToV2(source.replace('tf-paired-profile-v1','tf-paired-profile-v9'))).toThrow();
  });
  it('rejects upgrades whose legacy override would otherwise vanish',()=>{
    const p=JSON.parse(readFileSync(FLEXOKI_PROFILE_PATH,'utf8'));p.targetOverrides.solarSail={future:true};expect(()=>migrateV1ToV2(JSON.stringify(p))).toThrow();
  });
  it.each([['density','compact'],['radius','pill'],['typography','editorial']] as const)('has deterministic %s recipe identity and preserves unrelated intent',(type,variant)=>{
    const source=canonicalizeProfileV2(makeValidBaseProfile()),recipe={schema:'tf-paired-recipe-v1' as const,type,variant};
    const a=applyRecipe(source,recipe),b=applyRecipe(source,recipe);expect(a).toEqual(b);expect(a.profile.targetOverrides).toEqual(makeValidBaseProfile().targetOverrides);
    expect(a.digest).toMatch(/^[a-f0-9]{64}$/);expect(a.resultSha256).toBe(computeRawSourceSha256(a.resultJson));
  });
});

describe("TFNC13 Studio document custody owner contract pins", () => {
  const sha256 = (text: string) => createHash("sha256").update(text, "utf8").digest("hex");

  function expectBindingError(raw: string, code: string): void {
    expect(() => bindSourceProfileV2(raw)).toThrow(PairedProfileV2Error);
    expect(() => bindSourceProfileV2(raw)).toThrow(expect.objectContaining({ code }));
  }

  it.each(["string", "UTF-8 bytes"])("binds exact %s with verified provenance and a frozen profile", (inputKind) => {
    const profile = makeValidBaseProfile();
    profile.description = "Studio custody — café ☀";
    const raw = JSON.stringify(profile, null, 2) + "\n";
    const bound = bindSourceProfileV2(inputKind === "string" ? raw : Buffer.from(raw, "utf8"));

    expect(bound.profile.schemaVersion).toBe("tf-paired-profile-v2");
    expect(bound.profile).toEqual(profile);
    expect(Object.isFrozen(bound.profile)).toBe(true);
    expect(Object.isFrozen(bound.profile.color.light)).toBe(true);
    expect(Object.isFrozen(bound.profile.typography?.body)).toBe(true);
    expect(Object.isFrozen(bound.provenance)).toBe(true);
    expect(bound.provenance.verificationStatus).toBe("verified");
    expect(bound.provenance.rawSourceSha256).toMatch(/^[0-9a-f]{64}$/);
    expect(bound.provenance.rawSourceSha256).toBe(sha256(raw));
    expect(bound.provenance.byteLength).toBe(Buffer.byteLength(raw, "utf8"));
    // The owner exposes a domain-separated canonicalDigest, not normalizedSha256.
    expect(bound.provenance.canonicalDigest).toMatch(/^[0-9a-f]{64}$/);
    expect(bound.provenance.canonicalDigest).toBe(
      sha256("tf-paired-profile-v2\n" + canonicalizeProfileV2(bound.profile))
    );
  });

  it.each([
    ["schema", "tf-paired-profile-v1"],
    ["schemaVersion", "tf-paired-profile-v1"],
    ["schema", "tf-paired-profile-v2"],
  ])("rejects the discriminator %s: %s without alias resolution", (key, value) => {
    const profile: Record<string, unknown> = { ...makeValidBaseProfile() };
    delete profile.schemaVersion;
    profile[key] = value;
    expectBindingError(JSON.stringify(profile), ERROR_CODES.SCHEMA_VALIDATION);
  });

  it("rejects duplicate keys before schema validation", () => {
    const raw = JSON.stringify(makeValidBaseProfile());
    expectBindingError(raw.replace('{', '{"name":"shadow-name",'), ERROR_CODES.CANONICAL_ERROR);
  });

  it.each(["__proto__", "constructor", "prototype"])("rejects the forbidden key %s", (key) => {
    const raw = JSON.stringify(makeValidBaseProfile());
    expectBindingError(raw.replace('{', `{${JSON.stringify(key)}:{},`), ERROR_CODES.CANONICAL_ERROR);
  });

  it.each(["null", "[]", '"profile"', "42", "true"])("rejects the non-object root %s", (raw) => {
    expectBindingError(raw, ERROR_CODES.SCHEMA_VALIDATION);
  });

  it("rejects unknown fields and a missing required color section", () => {
    expectBindingError(JSON.stringify({ ...makeValidBaseProfile(), extraField: 1 }), ERROR_CODES.SCHEMA_VALIDATION);
    const profile: Record<string, unknown> = { ...makeValidBaseProfile() };
    delete profile.color;
    expectBindingError(JSON.stringify(profile), ERROR_CODES.SCHEMA_VALIDATION);
  });

  it("accepts the owner minimal schema without optional typography or adapter-only sections", () => {
    const profile = makeValidBaseProfile();
    const minimal = {
      schemaVersion: profile.schemaVersion,
      name: profile.name,
      version: profile.version,
      color: profile.color,
    };
    expect(bindSourceProfileV2(JSON.stringify(minimal)).profile).toEqual(minimal);
  });

  it("preserves canonical identity across nested key ordering and whitespace changes", () => {
    function reverseKeys(value: unknown): unknown {
      if (Array.isArray(value)) return value.map(reverseKeys);
      if (value === null || typeof value !== "object") return value;
      return Object.fromEntries(Object.entries(value).reverse().map(([key, child]) => [key, reverseKeys(child)]));
    }
    const profile = makeValidBaseProfile();
    const sources = [JSON.stringify(profile), JSON.stringify(profile, null, 2), JSON.stringify(reverseKeys(profile), null, 4) + "\n"];
    const bound = sources.map((raw) => bindSourceProfileV2(raw));

    expect(new Set(bound.map((item) => item.provenance.rawSourceSha256)).size).toBe(sources.length);
    expect(new Set(bound.map((item) => item.provenance.canonicalDigest)).size).toBe(1);
    for (const [index, item] of bound.entries()) {
      expect(item.profile).toEqual(profile);
      expect(item.provenance.rawSourceSha256).toBe(sha256(sources[index]!));
      expect(item.provenance.verificationStatus).toBe("verified");
      expect("normalizedSha256" in (item.provenance as unknown as Record<string, unknown>)).toBe(false);
    }
  });
});
