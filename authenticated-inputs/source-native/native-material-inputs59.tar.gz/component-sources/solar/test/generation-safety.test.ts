import { describe, expect, it, afterEach } from "vitest";
import { readFileSync } from "node:fs";
import { mkdtemp, rm, writeFile, readFile, symlink, mkdir, lstat } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import {
  generateThemePackage,
  writePackageFiles,
  writeCssFile,
  FilesystemSafetyError,
} from "../src/emitter.js";
import {
  validateMemberPath,
  preflightMemberPaths,
} from "../src/writer.js";

const exampleThemePath = resolve(import.meta.dirname, "../examples/forge-console.theme.json");
const examplePkgPath = resolve(import.meta.dirname, "../examples/package-metadata.json");

const validTheme = JSON.parse(readFileSync(exampleThemePath, "utf8"));
const validMetadata = JSON.parse(readFileSync(examplePkgPath, "utf8"));

describe("Solar Sail Generation & Filesystem Safety (TFSB71B1)", () => {
  let tempDir: string | undefined;

  afterEach(async () => {
    if (tempDir) {
      await rm(tempDir, { recursive: true, force: true });
      tempDir = undefined;
    }
  });

  describe("Member path preflight validation", () => {
    it("rejects empty or whitespace-only member paths", () => {
      expect(() => validateMemberPath("")).toThrow(FilesystemSafetyError);
      expect(() => validateMemberPath("   ")).toThrow(FilesystemSafetyError);
    });

    it("rejects NUL bytes in member paths", () => {
      expect(() => validateMemberPath("styles/\0theme.css")).toThrow(FilesystemSafetyError);
      try {
        validateMemberPath("styles/\0theme.css");
      } catch (err: any) {
        expect(err.code).toBe("INVALID_MEMBER_PATH");
      }
    });

    it("rejects absolute paths", () => {
      expect(() => validateMemberPath("/etc/passwd")).toThrow(FilesystemSafetyError);
      expect(() => validateMemberPath("C:/Windows/System32")).toThrow(FilesystemSafetyError);
    });

    it("rejects traversal and unnormalized segments", () => {
      expect(() => validateMemberPath("../escape.txt")).toThrow(FilesystemSafetyError);
      expect(() => validateMemberPath("styles/../../escape.txt")).toThrow(FilesystemSafetyError);
      expect(() => validateMemberPath("styles/./theme.css")).toThrow(FilesystemSafetyError);
      expect(() => validateMemberPath("styles//theme.css")).toThrow(FilesystemSafetyError);
    });

    it("rejects backslashes in member paths", () => {
      expect(() => validateMemberPath("styles\\theme.css")).toThrow(FilesystemSafetyError);
      try {
        validateMemberPath("styles\\theme.css");
      } catch (err: any) {
        expect(err.code).toBe("INVALID_MEMBER_PATH");
      }
    });

    it("rejects case collisions in the file map", () => {
      const files = new Map<string, string>([
        ["styles/theme.css", "body { color: red; }"],
        ["styles/THEME.CSS", "body { color: blue; }"],
      ]);
      expect(() => preflightMemberPaths(files)).toThrow(FilesystemSafetyError);
      try {
        preflightMemberPaths(files);
      } catch (err: any) {
        expect(err.code).toBe("CASE_COLLISION");
      }
    });

    it("rejects normalization collisions (Unicode NFC vs NFD)", () => {
      const nfc = "styles/\u00e9.css"; // é composed (NFC)
      const nfd = "styles/e\u0301.css"; // e + combining acute (NFD)
      expect(nfc).not.toBe(nfd);

      const files = new Map<string, string>([
        [nfc, "/* NFC */"],
        [nfd, "/* NFD */"],
      ]);
      expect(() => preflightMemberPaths(files)).toThrow(FilesystemSafetyError);
      try {
        preflightMemberPaths(files);
      } catch (err: any) {
        expect(err.code).toBe("NORMALIZATION_COLLISION");
      }
    });

    it("rejects prefix conflicts where a path is both a file and parent directory", () => {
      const files = new Map<string, string>([
        ["styles", "this is a file called styles"],
        ["styles/theme.css", "body { color: red; }"],
      ]);
      expect(() => preflightMemberPaths(files)).toThrow(FilesystemSafetyError);
      try {
        preflightMemberPaths(files);
      } catch (err: any) {
        expect(err.code).toBe("PREFIX_CONFLICT");
      }
    });

    it("rejects non-Map or empty files map", () => {
      expect(() => preflightMemberPaths(null as any)).toThrow(FilesystemSafetyError);
      expect(() => preflightMemberPaths(new Map())).toThrow(FilesystemSafetyError);
    });
  });

  describe("Destination and ancestor symlink/component handling", () => {
    it("rejects symlink destination", async () => {
      tempDir = await mkdtemp(join(tmpdir(), "tfss-test-symlink-dest-"));
      const realTarget = join(tempDir, "real-target");
      await mkdir(realTarget);
      const symlinkTarget = join(tempDir, "symlink-target");
      await symlink(realTarget, symlinkTarget);

      const res = generateThemePackage({
        themeSpec: validTheme,
        metadata: validMetadata,
      });

      await expect(writePackageFiles(res.files, symlinkTarget)).rejects.toThrow(
        FilesystemSafetyError
      );
      try {
        await writePackageFiles(res.files, symlinkTarget);
      } catch (err: any) {
        expect(err.code).toBe("SYMLINK_REJECTED");
      }
    });

    it("rejects symlink in ancestor component", async () => {
      tempDir = await mkdtemp(join(tmpdir(), "tfss-test-symlink-anc-"));
      const realDir = join(tempDir, "real-dir");
      await mkdir(realDir);
      const linkDir = join(tempDir, "link-dir");
      await symlink(realDir, linkDir);

      const nestedOut = join(linkDir, "nested-pkg");
      const res = generateThemePackage({
        themeSpec: validTheme,
        metadata: validMetadata,
      });

      await expect(writePackageFiles(res.files, nestedOut)).rejects.toThrow(
        FilesystemSafetyError
      );
      try {
        await writePackageFiles(res.files, nestedOut);
      } catch (err: any) {
        expect(err.code).toBe("SYMLINK_REJECTED");
      }
    });

    it("rejects non-directory ancestor component (ENOTDIR safety)", async () => {
      tempDir = await mkdtemp(join(tmpdir(), "tfss-test-enotdir-"));
      const regularFile = join(tempDir, "file-blocking-dir");
      await writeFile(regularFile, "not a directory");

      const invalidTarget = join(regularFile, "sub-pkg");
      const res = generateThemePackage({
        themeSpec: validTheme,
        metadata: validMetadata,
      });

      await expect(writePackageFiles(res.files, invalidTarget)).rejects.toThrow(
        FilesystemSafetyError
      );
      try {
        await writePackageFiles(res.files, invalidTarget);
      } catch (err: any) {
        expect(err.code).toBe("NOT_A_DIRECTORY");
      }
    });
  });

  describe("Preservation of absent and empty destinations & no foreign deletion", () => {
    it("refuses nonempty destination even with overwrite:true, preserving existing bytes", async () => {
      tempDir = await mkdtemp(join(tmpdir(), "tfss-test-nonempty-"));
      const existingFile = join(tempDir, "critical-data.txt");
      const existingBytes = "irreplaceable user data 12345";
      await writeFile(existingFile, existingBytes);

      const res = generateThemePackage({
        themeSpec: validTheme,
        metadata: validMetadata,
      });

      await expect(
        writePackageFiles(res.files, tempDir, { overwrite: true })
      ).rejects.toThrow(FilesystemSafetyError);

      try {
        await writePackageFiles(res.files, tempDir, { overwrite: true });
      } catch (err: any) {
        expect(err.code).toBe("DIRECTORY_NOT_EMPTY");
      }

      // Existing bytes MUST be preserved completely untouched
      const readBack = await readFile(existingFile, "utf8");
      expect(readBack).toBe(existingBytes);
    });

    it("preserves pre-existing empty destination directory on partial failure", async () => {
      tempDir = await mkdtemp(join(tmpdir(), "tfss-test-empty-dest-"));
      const emptyDest = join(tempDir, "empty-target");
      await mkdir(emptyDest);

      // Verify it exists and is empty
      const stBefore = await lstat(emptyDest);
      expect(stBefore.isDirectory()).toBe(true);

      // Construct a file map with a deliberate fault (e.g. prefix conflict caught before or during staging)
      const faultyFiles = new Map<string, string>([
        ["valid-file.txt", "content"],
        ["styles/bad\0name", "invalid"],
      ]);

      await expect(writePackageFiles(faultyFiles, emptyDest)).rejects.toThrow(
        FilesystemSafetyError
      );

      // The pre-existing empty destination MUST still exist and remain empty!
      const stAfter = await lstat(emptyDest);
      expect(stAfter.isDirectory()).toBe(true);
      const entries = await readFile(join(tempDir, "empty-target")).catch(() => null);
      expect(entries).toBeNull(); // It is a directory, not a file
    });

    it("successfully writes package files to an existing empty destination directory", async () => {
      tempDir = await mkdtemp(join(tmpdir(), "tfss-test-empty-success-"));
      const emptyDest = join(tempDir, "target");
      await mkdir(emptyDest);

      const res = generateThemePackage({
        themeSpec: validTheme,
        metadata: validMetadata,
        language: "typescript",
      });

      const written = await writePackageFiles(res.files, emptyDest);
      expect(written.length).toBeGreaterThan(5);
      expect(await readFile(join(emptyDest, "package.json"), "utf8")).toContain(
        validMetadata.name
      );
    });
  });

  describe("Safe CSS single-file writer helper (writeCssFile)", () => {
    it("writes CSS to an absent file creating ancestor directories safely", async () => {
      tempDir = await mkdtemp(join(tmpdir(), "tfss-test-css-writer-"));
      const outCss = join(tempDir, "nested", "deeper", "theme.css");
      const cssContent = "@theme inline { --primary: #000; }";

      const writtenPath = await writeCssFile(outCss, cssContent);
      expect(writtenPath).toBe(resolve(outCss));

      const readBack = await readFile(outCss, "utf8");
      expect(readBack).toBe(cssContent);
    });

    it("refuses overwriting existing file without overwrite flag, preserving existing bytes", async () => {
      tempDir = await mkdtemp(join(tmpdir(), "tfss-test-css-noclobber-"));
      const outCss = join(tempDir, "theme.css");
      const originalBytes = "/* Original CSS - do not touch */";
      await writeFile(outCss, originalBytes);

      const newCss = "/* New CSS */";
      await expect(writeCssFile(outCss, newCss, { overwrite: false })).rejects.toThrow(
        FilesystemSafetyError
      );
      try {
        await writeCssFile(outCss, newCss);
      } catch (err: any) {
        expect(err.code).toBe("DESTINATION_CONFLICT");
      }

      // Existing bytes MUST be preserved
      const readBack = await readFile(outCss, "utf8");
      expect(readBack).toBe(originalBytes);
    });

    it("allows intentional overwrite when overwrite:true is specified", async () => {
      tempDir = await mkdtemp(join(tmpdir(), "tfss-test-css-overwrite-"));
      const outCss = join(tempDir, "theme.css");
      await writeFile(outCss, "/* old content */");

      const newContent = "@theme inline { --color-accent: #f00; }";
      await writeCssFile(outCss, newContent, { overwrite: true });

      const readBack = await readFile(outCss, "utf8");
      expect(readBack).toBe(newContent);
    });

    it("rejects writing when destination is a directory", async () => {
      tempDir = await mkdtemp(join(tmpdir(), "tfss-test-css-dir-"));
      const targetDir = join(tempDir, "theme-dir.css");
      await mkdir(targetDir);

      await expect(
        writeCssFile(targetDir, "/* css */", { overwrite: true })
      ).rejects.toThrow(FilesystemSafetyError);
      try {
        await writeCssFile(targetDir, "/* css */", { overwrite: true });
      } catch (err: any) {
        expect(err.code).toBe("IS_A_DIRECTORY");
      }
    });

    it("rejects writing when destination is a symlink", async () => {
      tempDir = await mkdtemp(join(tmpdir(), "tfss-test-css-symlink-"));
      const realFile = join(tempDir, "real.css");
      await writeFile(realFile, "/* real */");
      const linkFile = join(tempDir, "link.css");
      await symlink(realFile, linkFile);

      await expect(
        writeCssFile(linkFile, "/* new */", { overwrite: true })
      ).rejects.toThrow(FilesystemSafetyError);
      try {
        await writeCssFile(linkFile, "/* new */", { overwrite: true });
      } catch (err: any) {
        expect(err.code).toBe("SYMLINK_REJECTED");
      }
    });
  });

  describe("Generated sinks & TS provenance defect fix", () => {
    it("constrains and encodes README metadata against injection", () => {
      const metadataWithInjection = {
        name: "@knowledge-forge-ai/safe-pkg-name",
        version: "1.0.0",
        description: "Evil description with <script>evil()</script> and `backticks`",
      };

      const res = generateThemePackage({
        themeSpec: validTheme,
        metadata: metadataWithInjection,
      });

      const readme = res.files.get("README.md") as string;
      // HTML tags must be encoded as entities in README sink
      expect(readme).not.toContain("<script>");
      expect(readme).toContain("&lt;script&gt;evil&#40;&#41;&lt;/script&gt;");
    });

    it("sanitizes CSS @import specifier in README", () => {
      const res = generateThemePackage({
        themeSpec: validTheme,
        metadata: {
          name: "@scope/custom-theme-pkg",
          version: "1.0.0",
          description: "A valid description",
        },
      });

      const readme = res.files.get("README.md") as string;
      expect(readme).toContain('@import "@scope/custom-theme-pkg/styles/theme.css";');
    });

    it("safely escapes line separators in TypeScript inlined spec while preserving JSON equivalence", () => {
      const themeWithLineSep = {
        ...validTheme,
        description: "Line\u2028separator and paragraph\u2029separator",
      };

      const res = generateThemePackage({
        themeSpec: themeWithLineSep,
        metadata: validMetadata,
        language: "typescript",
      });

      const indexTs = res.files.get("src/index.ts") as string;
      // In TS source, \u2028 and \u2029 must be escaped as \u2028 and \u2029
      expect(indexTs).not.toContain("\u2028");
      expect(indexTs).not.toContain("\u2029");
      expect(indexTs).toContain("\\u2028");
      expect(indexTs).toContain("\\u2029");

      // But when parsed as JSON, it reproduces the exact characters
      const inlinedMatch = indexTs.match(/export const themeSpec: ThemeSpecification = ([\s\S]*?);\nexport const themeCss/);
      expect(inlinedMatch).not.toBeNull();
      const parsed = JSON.parse(inlinedMatch![1]);
      expect(parsed.description).toBe(themeWithLineSep.description);
    });

    it("preserves v1 output identities for standard themes", () => {
      const res = generateThemePackage({
        themeSpec: validTheme,
        metadata: validMetadata,
        language: "javascript",
      });

      // Verification that standard files have expected deterministic hashes
      const themeJson = res.files.get("theme.json") as string;
      const themeDesc = res.files.get("theme.descriptor.json") as string;
      const stylesCss = res.files.get("styles/theme.css") as string;

      expect(themeJson).toBe(res.themeCanonicalJson);
      expect(stylesCss).toBe(res.cssContent);
      expect(res.provenance.files.length).toBe(res.files.size - 1); // provenance.json is excluded from inventory
    });
  });
});


describe("README text boundaries", () => {
  it.each(["# Heading", "---", "+ item", "- item", "1. item", "1) item", "| cell |", "    indented", "\\# escaped"])("keeps description as paragraph text: %s", description => {
    const result = generateThemePackage({ themeSpec: validTheme, metadata: { ...validMetadata, description } });
    const paragraph = (result.files.get("README.md") as string).split("\n\n")[1]!;
    expect(paragraph).not.toMatch(/^(?:#{1,6} |[-+*] |[-_*]{3,}|[0-9]+[.)] | {4}|\\|\|)/);
    expect(paragraph).toContain("&#");
    expect(JSON.parse(result.files.get("package.json") as string).description).toBe(description);
  });
  it.each(["\u0000", "\u0007", "\u001b", "\u007f", "\u0085"])("rejects controls in description and author: %j", control => {
    for (const field of ["description", "author"]) {
      expect(() => generateThemePackage({ themeSpec: validTheme, metadata: { ...validMetadata, [field]: `before${control}after` } })).toThrow();
    }
  });
});
