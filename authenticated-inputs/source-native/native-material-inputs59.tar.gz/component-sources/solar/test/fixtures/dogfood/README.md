# Solar Sail Dogfood Fixtures: Provenance & Behavioral Contracts

This directory contains clean-room, independently authored test fixtures created for TFSB71B1 dogfood qualification of Theme Forge Solar Sail.

These fixtures model the architectural findings and divergence points identified during TFSB71A dogfood reconnaissance (`docs/evaluations/tfsb71a-dogfood-reconnaissance.md`).

## Clean-Room Declaration & License Provenance

**No third-party implementation or source snippet has been copied into these fixtures.**
All fixtures are independently authored minimal synthetic specifications designed to exercise Solar Sail schema validation, compilation, and consumer runtime contracts under controlled conditions.

The inspected external repositories were consulted solely as reference specifications to identify naming conventions, optional role structures, alpha-bearing color usages, and architectural incompatibilities.

| Reference Repository | Inspected Git Revision | Inspected Path | Content SHA-256 | Declared License | Architectural Finding Observed |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `shadcn/shadcn-ui_ui` | `3ba91b1cc83e1bbe4ab35a422ff2a694849c5048` | `apps/v4/app/globals.css` | `cbae6d633c38be59fc036d1e5cf60203ae7619ea6af9b4cdd8d632a211ccffa9` | MIT (shadcn) | Inline Tailwind `@theme inline`, multiplicative radius progression, canonical sidebar roles (`--sidebar`, `--sidebar-primary`, etc.), chart roles (`--chart-1` to `--chart-5`), alpha-bearing syntax (`oklch(1 0 0 / 10%)`). |
| `shadcn/tweakcn` | `a3b47b37cba97dd637de517aab52c45ec0f83456` | `types/theme.ts`<br>`config/theme.ts`<br>`utils/theme-style-generator.ts`<br>`utils/shadows.ts`<br>`utils/color-converter.ts`<br>`utils/theme-preset-helper.ts` | `50a62c4c47c6d9d679a7f3aab2b1bb85dcca9908ce3e2d5f5c9ff3fabc8aa2ce`<br>`cca693548553545cd6384e1d02b30138510ed6eeb94da313e20c5f328f630da1`<br>`7302d23305186c4323aca4c9bf94d3b975bbe8c8a544beb7adfe3b1406daa458`<br>`5738b74092e15c9209e28507ab3800e738cb51c28679da516cb1e3f966868def`<br>`091403a97a9093ea3c0e7085d9268d7e5694d24d073773bda841af27efa362a6`<br>`ea4c391300fadf7f308d05870dcd9a14b4af92e9d643c32320058e4196b6c510` | Apache-2.0 | Shadow parameters/scales, spacing, tracking, sans/serif/mono fonts. Sparse presets rely on `mergePresetWithDefaults`; sparse proposals omitting mandatory roles cannot pass strict compiler validation without ambient state. |
| `shadcn/material-shadcn` | `131586246a9d2305703d9a03a489bb021a278eb6` | `packages/core/src/mapping.ts`<br>`packages/core/src/generate.ts`<br>`packages/core/src/apply.ts` | `2744fe3796f177e95bcaaf87a9f0c327b9c5b09af005ac2b1a6952b6d250ce82`<br>`f12c85d287afc5670a216ea2124071f4ec129dba33b6aad66f2431c135119878`<br>`6397fec302c575dd9548fc4e4f6147b4bcc1f524391742feffe033c3e8623591` | MIT (Sazzad) | Divergent naming: uses `sidebar-background` instead of canonical `sidebar`. Non-canonical aliases require explicit mapping or rejection rather than silent fallback. |
| `shadcn/flexoki` | `8d723bac4a9ac46adfdf99d42155286977aac72a` | `css/flexoki.css`<br>`tailwind/replacement.css` | `15d07c02c17690ef4368fa69e6dfe331bd39e7521e935f74a5477c0d58c1cfc2`<br>`393a246626c6b6140c1e1013ec5de0c5222d11b2fe8847c906e0b70f1328a2e0` | MIT (Steph Ango) | Raw palette ramps (`flexoki-black`, `flexoki-paper`, `flexoki-red-500`...) without semantic roles. Primitive-only palettes fail validation without an explicit semantic mapping adapter. |

## Fixture Inventory & Behavioral Contracts

### 1. `chart-sidebar-symmetric.theme.json` (Positive Contract)
- **Purpose**: Exercises symmetric optional chart (`chart1`..`chart5`) and sidebar (`sidebar`..`sidebarRing`) roles alongside all 19 mandatory roles in both `light` and `dark` modes.
- **Source Profile Provenance**: Contains explicit validated `sourceProfileSha256` property (`7c1e5559cf95927514a3bf16f0bbec94a029dbb8eec1317578ec0970a25227bf`), labeled as caller assertion pending source-aware mapper API.
- **Expected Outcome**:
  - `validateThemeSpecification` passes with `valid: true`.
  - `compileTheme` produces `@theme inline` block with `--color-chart-1` through `--color-chart-5` and `--color-sidebar*`.
  - Emits `--chart-1`..`--chart-5` and `--sidebar*` variables in both `:root` and `.dark`.

### 2. `alpha-fonts.theme.json` (Positive Contract)
- **Purpose**: Exercises alpha-bearing color strings (`oklch(0 0 0 / 10%)`, `rgba(240, 242, 245, 0.8)`) and extended font families (`fontSans`, `fontHeading`, `fontMono`).
- **Expected Outcome**:
  - `validateThemeSpecification` passes with `valid: true`.
  - Produces `UNEVALUATED_CONTRAST` info diagnostics for non-hex contrast pairs rather than false-positive errors.
  - `compileTheme` preserves alpha expressions and outputs `--font-heading` and `--font-mono` in `:root` and `@theme inline`.

### 3. `sparse-preset-rejected.theme.json` (Negative Contract)
- **Purpose**: Models a sparse preset (such as tweakcn's preset proposals) that defines only a subset of roles (`primary`, `background`) and omits mandatory roles (`card`, `popover`, `muted`, `accent`, etc.).
- **Expected Outcome**:
  - `validateThemeSpecification` fails with `valid: false`.
  - Emits multiple `MISSING_OR_INVALID_COLOR_ROLE` errors for omitted roles.
  - Proves that partial proposals cannot be accepted without explicit default merging.

### 4. `sidebar-alias-rejected.theme.json` (Negative Contract / Divergence Contract)
- **Purpose**: Models non-canonical naming conventions such as `material-shadcn`'s `sidebarBackground` / `sidebar-background` instead of canonical `sidebar`, alongside unsupported properties (`shadow-blur`, `letter-spacing`, `spacing`).
- **Expected Outcome**:
  - Does not resolve canonical `sidebar` role.
  - Unsupported properties are rejected or not converted into canonical CSS variables.
  - Conflicting alias inputs are rejected rather than silently resolved to the last property.

### 5. `primitive-only-rejected.theme.json` (Negative Contract)
- **Purpose**: Models raw primitive color ramp inputs (such as raw Flexoki ramps) that contain color values under ramp keys (`flexoki-paper`, `flexoki-red-500`) but no semantic application roles.
- **Expected Outcome**:
  - `validateThemeSpecification` fails with `valid: false`.
  - Emits `MISSING_OR_INVALID_COLOR_ROLE` errors for all 19 mandatory semantic roles.
  - Proves that primitive ramps cannot bypass the semantic mapping contract.
