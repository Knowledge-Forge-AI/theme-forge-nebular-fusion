# Design Director v1 protocol foundation

Status: TFSB71A terminal candidate. This additive private protocol is governed by
[ADR 0029](../../docs/decisions/0029-design-director-protocol-foundation.md).
It has no package export, UI integration, filesystem capability or apply adapter.

`src/design-director/schema.ts` is the maintained structural source. Five generated
JSON Schemas describe brief, candidate, rendered-evidence linkage, agent review,
and human decision/revision request records. `v1-validate.ts` adds local normative
rules; `v1-lineage.ts` adds complete graph rules. JSON Schema validation alone is
not lineage verification. The generator, examples, inventory and negative corpus
are maintained in `tools/design-director/generate.mjs` and this directory.

## Roles and data ownership

| Record kind | Authority label | Responsibility |
| --- | --- | --- |
| `brief` | `advisory` | Human/agent-authored semantic summary, constraints, acceptance criteria, prohibited changes, targets and base-profile reference |
| `candidate` | `advisory` | Claimed agent/tool and recipe identities, structured deltas, lineage and explicit proposed/compiled state |
| `evidence` | `observation` | Compilation/profile/package bindings, consumer fixture, renderer, mode/viewport and artifact observations |
| `review` | `agent-interpretation` | Interpretation and recommendations citing exact candidate/evidence/observation identities |
| `decision` | `human-decision` | Claimed human choice, exact reviewed set, selected candidate, parent decision and structured revision request |

All identities are claims. Digest validity proves integrity, not authorship,
compiler execution, human presence, artifact availability or design merit. A human
decision record is not itself an authenticated adoption capability. The eventual
application must obtain human confirmation at its normal adoption boundary.
An agent recommendation cannot veto a structurally valid human choice.

Text is descriptive and is never executed, compiled, adopted or applied by parsing.
Unknown fields and authority roles fail closed. There are no commands, arbitrary
filesystem paths, provider credentials or executable configuration fields. The
`reference` in a profile is a bounded logical ID, not a path or URL.

## Profile references and structured deltas

A profile reference names `schema`, logical `reference`, `digestForm` and `sha256`.
The sole digest form is `raw-source-sha256`: SHA-256 of exact source bytes, encoded
as `sha256:` plus 64 lowercase hex digits. Whitespace changes those bytes. This is
not Solar Sail's locale-sorted descriptor identity or a semantic-equivalence hash.
No existing engine digest is redefined.

Future `tf-paired-profile-vN` references are permitted opaquely. Proposed candidates
may carry a null delta and null result profile. A non-null delta, compiled record,
evidence interpretation or human revision request requires the supported v1
reference. No cross-version migration is implicit. A supported reference still
does not prove the referenced bytes satisfy a maintained paired-profile validator:
that shared authority and the apply adapter remain TFSB71B prerequisites.

The closed delta adapter `tf-paired-profile-v1-delta-v1` is a **proposal vocabulary**,
not an execution engine. Its semantic section permits named light/dark core palette
roles, `surfaces.radius`, `surfaces.borderWidth` and sans/heading/mono font fields.
Values retain the source profile's string representation. The target section
permits Solar Sail radius/border fields, and Loom content width (integer pixels)
and accent/family identifiers. Exact paths and value types are in `schema.ts`.
Broader overrides, syntax fields and future semantics fail closed until a separately
versioned contract owns them. Loom navigation/catalog structure is not universal.

Semantic paths and target/path pairs are sorted unique sets. Assigning the same
field in both sections for any target is rejected as ambiguous; there is no hidden
precedence. Target overrides must belong to the brief's target set. The protocol
does not certify that applying a delta produced a result profile. Compilers still
validate their input at the runtime boundary; raw proposal strings must not be
concatenated into output without the engine's validation.

## Candidate lineage and digest direction

A root candidate's full base-profile reference equals its brief's reference.
Every candidate binds the brief digest, producer and recipe identity. Proposed
candidates have no compilation or evidence claims. Compiled candidates require a
result v1 profile, non-null delta, and exactly the brief's compilation targets.
Each compilation binds the expected engine package/version/source identity, result
profile source hash, engine-native output digest, generated package ID/version,
inventory digest and provenance-byte hash. Engine digest domains remain native;
the `sha256:` prefix is a representation wrapper, not rehashing.

Compilation records do not encode every compiler or packaging option (for example,
Loom accent/language selection and generated-package metadata). Equal profile and
delta claims therefore do not establish equal complete compilation inputs across
siblings. Graph verification does not enforce cross-sibling output equality.
A future execution adapter must bind a complete normalized invocation before it
can certify reproducibility or detect contradictory equal-input output claims.

Evidence binds the result profile and full compilations, not a candidate digest.
A candidate may therefore reference evidence without a digest cycle. Attaching
compilation/evidence creates a new candidate with the previous candidate digest;
without a revision decision, base/result profile, delta and producer identities
must stay equal. A design revision instead cites a human `revise` decision and
its selected parent candidate, uses that parent's result (or base) profile, and
matches the exact requested delta. `examples/revision.json` is such a new candidate,
not a separate mutable revision authority.

Reviews must name exact candidate/evidence sets. Each reviewed candidate must have
cited evidence and at least one interpretation; each interpretation resolves to
an observation on that candidate's evidence. Decisions reproduce the review's
candidate set and review digest. `adopt`/`revise` require one selected member;
`reject`/`defer` require null selection. Only `revise` carries a revision request.
Adoption requires compiled, nonsynthetic evidence. Pass/fail/unevaluated observations
remain visible to the human; interpretation does not change them.

All supplied records are structurally revalidated and rehashed during graph
verification. Missing/wrong-kind references, duplicate digest/record identities,
foreign briefs, profile/compiler/package mismatches, excessive traversal and
cycles fail closed. Verification does not fetch anything or mutate supplied data.

## Rendered Evidence Bundle linkage

The `evidence` record is the v1 bundle-linkage contract. It binds exact fixture and
renderer identities, environment (`browser`, `native`, or `synthetic`), target,
light/dark mode, viewport, observation status and bounded artifact hashes/sizes.
Each target must have an observation. Artifact role and digest types reuse the
maintained Studio evidence vocabulary. An optional `visualEvidence` reference
names an existing `tfsb.studio-visual-evidence` digest; it does not duplicate the
embedded PNG or native renderer schema. Consumers resolving that external packet
must call its maintained `validateVisualEvidenceResult` and compare its digest,
configuration and artifact identities before using it as evidence. The Director
graph checks record linkage; it does not resolve that external visual packet.

Real rendering claims require retained artifact bytes, renderer execution evidence
and readback. Native claims require native evidence. All canonical examples use
synthetic observations and cannot support adoption. The integration test binds
real paired compiler/package outputs and explicitly claims neither browser/native
rendering nor package installation. No vector lane is activated.

## Canonical bytes, bounds and errors

Canonical wire is compact JSON with object keys ordered by unsigned UTF-8 bytes
and exactly one final LF. Arrays retain order; identity sets must already be
sorted/unique. The encoder reuses the existing Studio canonical JSON primitive,
adding Director bounds. Numeric-looking keys are not reordered by a stringify
round trip. All strings/keys are valid Unicode NFC; lone surrogates, NUL, C0 controls
(except LF), DEL, unsafe integers, fractions and negative zero are rejected.
Unknown fields, forbidden prototype keys, symbols, non-plain objects, accessors,
hidden fields, sparse arrays and cyclic objects are rejected without evaluating
getters. Ordinary descriptive prose remains allowed.

Wire input rejects malformed UTF-8, BOM, duplicate JSON keys, noncanonical spelling
and digest drift. Limits: 1 MiB canonical/wire bytes, conservative aggregate byte
budget, nesting depth 24, generic collection size 128, string UTF-8 length 4096,
graph records 128 and lineage depth 24. Schema-specific text/array/integer limits
are tighter where appropriate. For example: eight reviewed candidates, sixteen
review evidence links, two compilation targets, thirty-two observations and eight
artifacts per observation. The conservative aggregate budget can reject a value
below the wire ceiling; neither limit promises maximum-capacity acceptance.

Every record has one `digest`. Exclude only that field and hash:

```text
tfsb.design-director.<kind>-v1\n + canonical projection bytes (including LF)
```

The five kinds have distinct domains. Version/discriminants, author claims, all
links, constraints, observations and interpretations are identity-bearing.
Validation errors fail the operation; no normalization, field dropping, default
infill or automatic recovery occurs. Validated records are owned, deeply frozen
copies. Draft digest computation is not validation; serialize validates before
emitting bytes.

## Maintenance and qualification

In a disposable build, run `node tools/design-director/generate.mjs <owned-output>`
and compare/retain only its schema/example/corpus artifacts. The inventory binds
each generated file by exact SHA-256 and size. Tests compare schemas against their
maintained source, validate every negative case and round-trip golden bytes.

The bounded portable lane is `node tools/design-director/qualify.mjs`; its optional
`--baseline-typecheck` classifies pre-existing broad type errors without changing
test-runner policy. Run it through the maintained disposable container argument
builder, which freshly builds the root and both engines first. It regenerates all
schemas, examples, the negative corpus and inventory into owned temporary storage
and compares every byte with maintained artifacts. It typechecks Director source
and the three protocol suites; the source-importing integration suite is exercised
at runtime, while engines build under their own compiler projects. It also checks
test inventory, old design-evidence regressions and real paired compilation.
Dispatcher finalization remains separate from this provider-local verification.

## TFSB71B2 additive linkage

The separate [candidate-set contract](CANDIDATE-SET.md) represents paired v1/v2
profile identities and complete target invocation/output/report bindings. The
five existing v1 record schemas and historical bytes retain their current
meaning and supported interpretation rules. This new advisory boundary does not
extend existing human-decision records into v2 adoption authority. Studio
transport and human adoption remain explicit TFSB71C prerequisites.

B2 explicitly allows `tf-paired-profile-v2` in observation/evidence profile
references. Existing record shapes and historical canonical bytes are unchanged;
v1 candidates and delta execution remain v1-only. Candidate-set graph verification
checks cited evidence against the same brief and full profile reference, compiler
package/version/source identity, output digest and package provenance. Complete
invocation/report identities remain in the separately versioned candidate records;
legacy evidence alone cannot certify them. Unknown future evidence versions reject.
