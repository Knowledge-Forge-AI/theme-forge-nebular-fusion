# TFSB71B2 Candidate Set & Normalized Invocation Identity Protocol

Status: Normative Pure Contract (`tf-paired-candidate-set-v1`).  
Authority: Strictly Advisory (`authority: "advisory"`).  
Parent Task Reference: TFSB71B2.

---

## 1. Overview and Scope

This specification defines the pure candidate-set and normalized invocation identity protocol for paired compiler orchestration across **Theme Forge Solar Sail** (`solar-sail`) and **Theme Forge Stellar Loom** (`stellar-loom`).

### Core Invariants

1. **Pure Contract Boundary**:
   - Implemented in `src/design-director/candidate-set.ts`.
   - Pure protocol types and validation only; **no compiler imports** into the root library.
   - Zero modifications to existing v1 Director fixture bytes, schemas, or verification rules.
   - Director linkage occurs via the separate candidate-set schema `tf-paired-candidate-set-v1`, avoiding optional-field retrofits onto v1 records.

2. **Advisory Authority Only**:
   - The candidate set is strictly advisory (`authority: "advisory"`).
   - Candidate records represent proposed, compiled, or failed design alternatives.
   - Candidate records **never** convey runtime execution, deployment, or adoption authority.
   - V1 human decisions remain unchanged. All v2 adoption authority is explicitly gated to human decisions in **C Studio**.

3. **Separation of Inputs and Output Receipts**:
   - Complete normalized input records (`tf-paired-invocation-input-v1`) are distinct from invocation output receipts (`tf-paired-invocation-receipt-v1`).
   - Inputs bind strict closed fields representing actual JSON configuration, prohibiting arbitrary executable code or unrepresented defaults.
   - The record validator checks shape and identity, not derivation: it does not
     recompute `application.finalConfig` from `base`, `defaults`, `overrides` and
     `selection`. A self-consistent digest can still bind an inaccurate producer
     claim. Execution qualification must replay the named adapter/compiler with
     these inputs and compare final configuration, output members and provenance
     before any reproducibility or adoption claim.
   - Output receipts bind native compiler digests as opaque domains, package identity, generated member inventories, provenance bytes, and per-target mapping report digests.
   - Every invocation output receipt binds the exact `invocationInputDigest` of its triggering input record.
   - Evidence references are strictly acyclic (no digest cycles).

4. **Generation vs. Execution Separation**:
   - `FontDeclarationClaim` digests are pure generation inputs representing normative font claims.
   - Loaded font resource bytes and runtime font licenses (`FontExecutionResourceClaim`) are execution claims, which are not promised or required by package generation (`generateThemePackage`).
   - Declared-only font execution status (`status: "declared-only"`) allows valid code generation without asserting loaded execution bytes.

5. **Portable Canonical JSON & Bounded Safe Data**:
   - Extends canonicalization to safe finite floating-point numbers and fractions (for line-heights, typography scales, surface radii), while disallowing `NaN`, `Infinity`, `-0`, and unsafe integers.
   - Rejects sparse arrays (arrays with holes/missing indices), extended array properties (non-index properties on Array instances), and exotic array prototypes (`Object.getPrototypeOf(arr) !== Array.prototype`).
   - Bounded collections support up to 20,000 items and a 1 MiB wire byte budget (`CANDIDATE_SET_DATA_LIMITS`) to accommodate valid Loom component catalog objects and token sets without arbitrary failure.
   - Object keys are sorted strictly by UTF-8 byte order (`Buffer.compare`), guaranteeing identical digest computation across all execution runtimes and system locales.
   - Validation functions return owned, deep-frozen copies to guarantee input immutability.

---

## 2. Schema Boundary: `tf-paired-candidate-set-v1`

A candidate set envelope aggregates between 1 and 8 ordered candidate alternatives referencing a validated Design Brief.

### Schema Fields

| Field | Type | Description |
| --- | --- | --- |
| `schema` | `"tf-paired-candidate-set-v1"` | Explicit schema discriminant |
| `kind` | `"candidate-set"` | Record kind identifier |
| `authority` | `"advisory"` | Authority constraint (strictly advisory) |
| `id` | `string` | Lowercase kebab/dot identifier (`^[a-z][a-z0-9]*(?:[.-][a-z0-9]+)*$`) |
| `digest` | `Digest` | Domain-prefixed SHA-256 self-digest (`sha256:<64-hex>`) |
| `brief` | `BriefReference` | Reference to validated Design Brief (`reference` and `digest`) |
| `baseProfile` | `ProfileIdentityRef` | Base profile identity (schema, reference, raw SHA-256, canonical SHA-256) |
| `candidates` | `CandidateItem[]` | Array of 1 to 8 candidate items, strictly sorted in UTF-8 byte order |

### Candidate Ordering and Lineage Rules

1. **Ordering**:
   - The `candidates` collection must contain between 1 and 8 items (`minCandidates: 1`, `maxCandidates: 8`).
   - Candidate IDs must be unique and strictly sorted in UTF-8 byte order (`utf8Compare(candidates[i-1].id, candidates[i].id) < 0`).
2. **Lineage**:
   - A root candidate has `parentCandidateId: null` and `parentCandidateDigest: null`. Its `baseProfile` must match `set.baseProfile`.
   - A child candidate has `parentCandidateId: string` and a non-null `parentCandidateDigest: Digest`. The referenced parent candidate must exist in the candidate set.
   - Parent digest comparison verifies the actual computed parent digest even if `parent.digest` was omitted.
   - Parent lineage must be strictly acyclic (direct self-cycles `A -> A` and indirect cycles `A -> B -> A` fail closed).
   - Foreign brief parentage is prohibited: `parent.briefDigest === child.briefDigest === set.brief.digest`.
   - Child base profile must match the parent's `resultProfile` (if compiled) or `baseProfile`.
3. **States**:
   - `"proposed"`: Proposed design alternative. Must NOT claim output receipts (`outputReceipts.length === 0`), evidence (`evidenceDigest: null`), or error (`error: null`). Allows future profile schema versions (e.g. `tf-paired-profile-v3`) as opaque proposals.
   - `"failed"`: Candidate whose compilation or evaluation failed. Must NOT claim output receipts (`outputReceipts.length === 0`) or evidence (`evidenceDigest: null`). Requires explicit `error` (`code` and `message`).
   - `"compiled"`: Successfully compiled paired candidate. Requires non-null `resultProfile`, strictly supported v1/v2 profile schema, exactly 2 `invocationInputs` (sorted: `solar-sail` then `stellar-loom`), and exactly 2 matching `outputReceipts`. Cannot claim `error` (`error: null`). Each receipt binds the exact `invocationInputDigest` of its triggering input, matching profile identity, generator package identity, and consistent source hashes.
4. **Delta References**:
   - Delta references are strictly advisory; candidate sets carry **no apply authority**.
   - `DeltaRefV1` (`tf-paired-profile-v1-delta-v1`): validated against the maintained v1 structural validator (`validateDelta`) with strictly restricted semantic paths and target override schemas; arbitrary unvalidated paths fail closed.
   - `DeltaRefV2` (`tf-paired-profile-v2-delta-v1`): supports structured recipe references `{ adapter, sourceSha256 }` or finite v2 deltas with sorted unique paths.

---

## 3. Normalized Invocation Identity

### Input Record: `tf-paired-invocation-input-v1`

Every invocation input fully binds all effective options. Top-level and nested fields are closed; unknown fields are rejected.

```json
{
  "schema": "tf-paired-invocation-input-v1",
  "target": "solar-sail",
  "compiler": {
    "package": "@knowledge-forge-ai/theme-forge-solar-sail",
    "name": "theme-forge-solar-sail",
    "version": "0.1.0",
    "sourceInventoryHash": "sha256:..."
  },
  "runtime": {
    "name": "node",
    "version": "22.20.1",
    "icu": "76.1",
    "platform": "linux",
    "arch": "x64"
  },
  "profile": {
    "schema": "tf-paired-profile-v1",
    "reference": "flexoki-source",
    "rawSha256": "sha256:...",
    "canonicalSha256": "sha256:..."
  },
  "adapter": {
    "name": "@knowledge-forge-ai/theme-forge-solar-sail/adapter-v1",
    "version": "0.1.0"
  },
  "application": {
    "base": { ... },
    "defaults": { ... },
    "overrides": { ... },
    "selection": { ... },
    "finalConfig": {
      "sourceProfileSha256": "<64 lowercase hexadecimal digits>",
      ...
    }
  },
  "generator": {
    "packageName": "@example/theme",
    "packageVersion": "1.0.0",
    "description": "Theme package",
    "author": "Theme Author <author@example.com>",
    "license": "AGPL-3.0-or-later",
    "private": true,
    "language": "javascript",
    "template": null
  },
  "solarOptions": null,
  "loomOptions": null,
  "digest": "sha256:..."
}
```

#### Field Specifications:

1. **Runtime Identity (`runtime`)**:
   - Closed required keys: `name`, `version`, `icu`, `platform`, `arch`.
   - Never defaulted to hardcoded arbitrary values (such as `22.23.2`). Builders require explicit complete runtime and adapter identities.
2. **Generator Package Metadata (`generator`)**:
   - Closed required keys: `packageName`, `packageVersion`, `description`, `author`, `license`, `private`, `language`, `template`.
   - Explicit `null` for absent fields.
   - For `solar-sail`: `language` is `"javascript"` or `"typescript"`, `template` is `null`.
   - For `stellar-loom`: `language` is `"javascript"` or `"typescript"`, `template` is `"page-title-frame"` or `null`.
3. **Solar Compile Options (`solarOptions`)**:
   - Solar Sail compiler compiles purely from `ThemeSpecification` (`compileTheme(input)`). It has no mode or customVariant compile options; `solarOptions` must be explicitly `null`.
   - The actual `sourceProfileSha256` is bound directly via the final theme in `application.finalConfig.sourceProfileSha256`, matching `profile.rawSha256` after adding the `sha256:` prefix.
4. **Stellar Loom Compile Options (`loomOptions`)**:
   - Closed required keys: `catalog`, `tokenSet`, `family`, `accent`, `strictContrast`, `sourceProfileSha256`, `syntax`, `readingLayout`, `bookChrome`, `fontDeclarations`, `fontExecutionResources`.
   - `catalog`: `{ identity: string, digest: Digest }`.
   - `tokenSet`: string.
   - `family`: `{ primary: string, secondary: string }`.
   - `accent`: string.
   - `strictContrast`: boolean.
   - `sourceProfileSha256`: Digest matching `profile.rawSha256` after adding the `sha256:` prefix.
   - `syntax`: `{ inputs: Record<string, unknown> | null, projection: Record<string, unknown> | null }`.
   - `readingLayout`: boolean.
   - `bookChrome`: Resolved boolean configuration `{ enabled: boolean, chapterNavigation: boolean, chapterProgress: boolean, keyboardShortcuts: boolean }`.
   - `fontDeclarations`: Array of `FontDeclarationClaim` (generation claims, sorted unique by `id`).
   - `fontExecutionResources`: Array of `FontExecutionResourceClaim` (execution claims, sorted unique by `id`, matching declaration IDs and sha256).

### Output Receipt: `tf-paired-invocation-receipt-v1`

Output receipts record compilation outcomes as opaque native domains, bound to the triggering invocation input:

```json
{
  "schema": "tf-paired-invocation-receipt-v1",
  "target": "solar-sail",
  "invocationInputDigest": "sha256:...",
  "package": {
    "id": "@example/theme",
    "version": "1.0.0"
  },
  "nativeDigests": {
    "inputDigest": "sha256:...",
    "outputDigest": "sha256:...",
    "descriptorDigest": "sha256:..."
  },
  "generatedInventory": {
    "inventoryDigest": "sha256:...",
    "provenanceSha256": "sha256:...",
    "memberFiles": [
      { "path": "index.js", "size": 512, "sha256": "sha256:..." },
      { "path": "theme.css", "size": 2048, "sha256": "sha256:..." }
    ]
  },
  "mappingReportDigest": "sha256:...",
  "evidenceDigest": null,
  "digest": "sha256:..."
}
```

---

## 4. Exported TypeScript API Result Shape (for Parent Integration)

The module `src/design-director/candidate-set.ts` exports the following programmatic API:

### Protocol Constants & Limits
- `CANDIDATE_SET_SCHEMA`: `"tf-paired-candidate-set-v1"`
- `CANDIDATE_SET_KIND`: `"candidate-set"`
- `CANDIDATE_SET_AUTHORITY`: `"advisory"`
- `INVOCATION_INPUT_SCHEMA`: `"tf-paired-invocation-input-v1"`
- `INVOCATION_RECEIPT_SCHEMA`: `"tf-paired-invocation-receipt-v1"`
- `CANDIDATE_ITEM_SCHEMA`: `"tf-paired-candidate-item-v1"`
- `CANDIDATE_SET_LIMITS`: `{ minCandidates: 1, maxCandidates: 8, minOutputs: 1, maxOutputs: 2, minInputs: 1, maxInputs: 2 }`
- `CANDIDATE_SET_DATA_LIMITS`: `{ maxCollection: 20000, maxBytes: 1048576, maxTextBytes: 65536, maxDepth: 32 }`

### Serialization & Parsing
```ts
function canonicalCandidateSetJson(value: unknown): string;
function serializeCandidateSetPacket(value: CandidateSetRecord): string;
function parseCandidateSetPacket(bytes: string | Uint8Array): CandidateSetRecord;
```

### Digest Computation
```ts
function computeCandidateSetDigest(record: CandidateSetRecord | Omit<CandidateSetRecord, "digest">): Digest;
function computeCandidateItemDigest(candidate: CandidateItem | Omit<CandidateItem, "digest">): Digest;
function computeInvocationInputDigest(record: NormalizedInvocationInput | Omit<NormalizedInvocationInput, "digest">): Digest;
function computeInvocationReceiptDigest(record: InvocationOutputReceipt | Omit<InvocationOutputReceipt, "digest">): Digest;
function computeFontDeclarationDigest(decl: Omit<FontDeclarationClaim, "declarationDigest"> | FontDeclarationClaim): Digest;
```

### Validation & Verification
```ts
function validateCandidateSetPacket(value: unknown): CandidateSetRecord;
function validateNormalizedInvocationInput(value: unknown): NormalizedInvocationInput;
function validateInvocationOutputReceipt(value: unknown): InvocationOutputReceipt;
function validateCandidateItem(item: unknown, briefDigest: Digest, baseProfile: ProfileIdentityRef): CandidateItem;
function validateDeltaRef(delta: unknown): DeltaRef;
function verifyCandidateSetWithBrief(candidateSet: CandidateSetRecord, brief: Brief | BriefReference | unknown): CandidateSetRecord;
function verifyCandidateGraph(candidateSet: CandidateSetRecord, directorRecords?: readonly DirectorRecord[]): CandidateSetRecord;
```

### Normalization Builders
```ts
function normalizeSolarInvocationInput(options: SolarInvocationOptions): NormalizedInvocationInput;
function normalizeLoomInvocationInput(options: LoomInvocationOptions): NormalizedInvocationInput;
function createInvocationOutputReceipt(options: ...): InvocationOutputReceipt;
function createCandidateSet(options: ...): CandidateSetRecord;
```

---

## 5. Exact Studio / C Prerequisites

Integration with Studio (Rust Tauri application) requires satisfying four exact prerequisites before candidate-set ingestion:

### 1. `#[serde(deny_unknown_fields)]`
All Rust DTO structs deserializing candidate sets, invocation records, or receipts must apply:
```rust
#[derive(Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct CandidateSetRecordDto {
    pub schema: String,
    pub kind: String,
    pub authority: String,
    pub id: String,
    pub digest: String,
    pub brief: BriefReferenceDto,
    pub base_profile: ProfileIdentityRefDto,
    pub candidates: Vec<CandidateItemDto>,
}
```
**Rationale**: Prevents accidental forward compatibility leakage, field smuggling, or silent loss of unknown options.

### 2. Schema Aliasing and Discriminant Dispatch
Rust deserialization must dispatch on explicit schema tags:
```rust
#[derive(Debug, Serialize, Deserialize)]
#[serde(tag = "schema")]
pub enum PairedDirectorPacket {
    #[serde(rename = "tf-paired-candidate-set-v1")]
    CandidateSet(CandidateSetRecordDto),
    #[serde(rename = "tf-paired-invocation-input-v1")]
    InvocationInput(NormalizedInvocationInputDto),
    #[serde(rename = "tf-paired-invocation-receipt-v1")]
    InvocationReceipt(InvocationOutputReceiptDto),
}
```
**Rationale**: Preserves v1 director packets (`tfsb.design-director-v1`) without schema confusion.

### 3. Duplicate-Key Ingress Checking
Before passing JSON wire bytes to Serde, Studio must execute byte-level duplicate key detection:
- External JSON parsers that silently overwrite earlier duplicate keys destroy audit evidence and enable parser differential exploits.
- Studio's ingress pipe must reject wire payloads containing duplicate object keys with an explicit `DUPLICATE_KEY_INGRESS` diagnostic error prior to DTO instantiation.

### 4. Gated v2 Adoption Authority
Candidate set records carry `authority: "advisory"`. Under no circumstances may candidate generation or test compilation trigger automated theme adoption. Adoption of Paired Profile v2 themes remains explicitly gated to human `decision` records created within C Studio.

### Evidence boundary added in B2

Director v1 observation records explicitly accept v2 profile references without new
fields or historical digest changes. The candidate graph checks brief and complete
profile reference, compiler package/version/source inventory, output digest and
package provenance against each cited receipt. This is linkage validation, not
artifact authentication. Invoke native v1 graph verification separately when
validating historical review/decision authority. No v2 adoption rule is introduced.
