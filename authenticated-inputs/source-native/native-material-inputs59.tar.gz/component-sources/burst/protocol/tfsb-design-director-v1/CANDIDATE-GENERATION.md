# Recipe-derived paired candidates

This development tool derives advisory candidate sets from a human-directed
brief and the finite paired-profile v2 recipe catalog. It adds no adoption
authority and does not change the Director v1 record schemas.

`tf-paired-candidate-plan-v1` is a closed plan with an id, brief reference and
digest, original v1 base identity, and 1–7 recipe specifications. Specifications
carry a sorted unique id, `{type, variant}`, and a nullable `parentId`. Null means
the explicit migration root; another id means that recipe result is the input.
Unknown recipes, variants, fields, parents and cycles fail closed. Seven recipes
plus the migration root fit the existing eight-candidate limit.

`tf-paired-candidate-generation-v1` binds the plan, original and migrated byte
hashes, adapter/version, lossless conversion report digest, result profile bytes,
and compiled candidate set. The `migration-base` candidate compiles the migrated
v2 bytes against both targets and retains the original v1 base reference. Every
recipe candidate is its child or a descendant. A recipe reference id is
`tf-paired-{type}-{variant}`, version is the recipe implementation version, and
`sourceSha256` names the parent's result bytes. Deltas flatten changed groups into
sorted primitive leaves; hashes include the `sha256:` prefix.

The injected engine port binds the same profile bytes to Solar Sail and Stellar
Loom, normalizes the complete invocation, and reads every package member back
against native provenance. Solar's native source binding is in its descriptor;
Loom's generator binds it in provenance. Compiler source inventories, runtime,
mapping reports and complete generated-member inventories participate in receipts.
For built CLI and consumer runs, `compiler.sourceInventoryHash` binds a canonical
`tf-candidate-compiler-execution-inventory-v1` inventory containing engine source,
emitted engine files, Director source and emitted Director files. Source tests
bind the engine source inventory. Rebuilding remains required; the built record
identifies the emitted bytes actually loaded even if the build was stale, and
replay against different emitted files changes the invocation identity.
Replay repeats conversion, recipes and compilation using the supplied actual
runtime and engines; any recorded-byte difference fails, including runtime drift.

The CLI exports generated packages under development-only `@theme-forge-dogfood`
identities. It refuses nonempty destinations and existing symlink ancestors.
It makes no network calls. Build the root and both engines first:

```sh
npm run build
npm run build --prefix packages/solar-sail
npm run build --prefix packages/stellar-loom
node tools/design-director/generate-candidates.mjs \
  --plan tools/design-director/fixtures/forge-console-candidates.plan.json \
  --out /absolute/empty/task-output
```

The Forge Console fixture produces a migration baseline, compact density, sharp
radius, technical typography, and compact density derived from technical
typography. It uses exact system-font bindings. Relative radius stays unsupported
where no explicit pixel conversion exists. Compact density leaves Solar's visual
configuration unchanged, while Loom spacing changes from 4 to 4.5 pixels. Radius
and heading-family recipes have target-specific classifications: Solar consumes
control radius and heading family; Loom normalizes surface radius and heading
family and leaves control radius unsupported. These mapped effects do not imply
that either target consumes every radius or typography leaf.

The Linux consumer qualifier installs generated packages into disposable copies
of the application fixture and Terminal Nova demo. Only the temporary demo import
is substituted with the candidate package name. It measures both modes at
1280×800 and 390×844, checks mapping-informed effects, colors, errors and overflow,
and retains bounded evidence under 2 MiB. Package substitutions must match exactly
once before building. Parents render before descendants; recipe comparisons use
the actual parent. Loom details padding must equal half its compiled spacing
token, and Solar's unsupported density must preserve button padding and layout
gap. Browser observations attach to a
distinct `-rendered` successor set; receipt and parent digests are recalculated
through the entire lineage. An unexecuted browser scenario creates no evidence
record or adoption claim.

Inside the maintained disposable Linux lane, after the three builds above and
lock-pinned dependency preparation:

```sh
CI=true EVIDENCE_OUT=/evidence node tools/design-director/qualify-candidate-generation.mjs
```

Targeted portable tests:

```sh
npx --no-install vitest run test/design-director-candidate-generation.test.ts test/rs9-intent.test.ts
```

Director v1 reviews and decisions still cite v1 candidates. Linking agent critique
and human decisions to these v2 set members requires a separately reviewed
protocol extension. Nebular ingestion remains deferred to the Studio v2 gates.
