# Paired Design Profile v2

Status: TFSB71B2 checkpoint contract; stability depends on dispatcher acceptance
and the linked [qualification record](../../docs/evaluations/tfsb71b2-paired-profile-candidate-set.md).
The implementation lives in `packages/solar-sail/src/paired-v2`, within the existing
Solar Sail distribution. This location does not grant Solar Sail vocabulary
ownership over the universal profile. Neither compiler imports the other.

## Semantic ownership

`tf-paired-profile-v2` is a closed declarative data schema. Universal fields express
design intent, never target CSS variables, routes, component implementations or
executable source. Metadata is distinct from source semantic leaves.

| Group | Portable intent | Deliberate target distinction |
| --- | --- | --- |
| Color | Canvas/text, surface/text, elevated surface/text, actions/text, muted/highlight/danger, borders, focus, optional interactions | Native component/chart/sidebar roles remain Solar overrides; Loom requires opaque sRGB for its current core and syntax adapters. |
| Typography | Body, heading, UI, code family and optional size/line height | Font family strings do not establish installed font equivalence. Loom needs explicit bindings to its font IDs. |
| Radius | Control, surface, overlay | A target with one native radius cannot preserve three independent radii. Report unrepresented distinctions. |
| Spacing | Base spacing and density | Solar v1 has no spacing application; report unsupported. |
| Elevation | Flat/raised emphasis and border width/style | No invented shadow renderer or arbitrary CSS shadow language. |
| Focus | Mode color, width, offset | Solar consumes color; Loom has geometry fields. |
| Code | Semantic syntax colors and finite frame/copy presentation | Code projection participates in Loom reporting; Solar has no corresponding application surface. |
| Reading | Content measure | Loom can apply supported measures; Solar reports unsupported. |
| Navigation | Prominence and density intent | Navigation trees, chapter controls and catalog entries remain target-specific. Unsupported visual distinctions stay visible. |

Optional groups may be absent or empty. Empty containers are not source leaves.
The validator does not invent semantic intent to fill optional groups. A target
adapter may use documented defaults, recorded separately from consumed inputs.

Hexadecimal sRGB normalization changes spelling only: case and short notation.
Alpha remains alpha. There is no HSL/OKLCH conversion, compositing, clipping or
universal gamut guarantee. A valid v1 CSS color outside that portable subset needs
an explicit migration failure, not a fabricated equivalent.

Lengths carry units. Pixels can project into Loom's unitless pixel fields; rem/em
are never converted by assuming a root font size. Supported relative lengths can
remain valid portable intent while a target reports them unsupported.

## Overrides, capability and identities

Precedence is explicit base/default input, portable projection, then validated
target-only override. Report both overridden source intent and applied override.
Another target's override is retained, not applied. Unknown target fields fail
closed. Native compiler validation remains mandatory after mapping.

Reports use the finite statuses `consumed`, `normalized`, `overridden`,
`target-specific`, and `unsupported`. Source counts partition actual supplied
semantic leaves once. Metadata, defaults and generated values are separate;
syntax projection does not count a shared color twice merely because it has
several effects. `groups[].applicable` declares whether the adapter implements any
part of that group independently of supplied intent, units or leaf status. It is
false for Solar spacing/code/reading/navigation and Loom navigation. A true value
does not promise that every leaf or value is supported.

`defaults` lists only adapter-generated values surviving in the final projection.
Palette-derived syntax/chrome colors are source effects, not defaults. Rejected
alpha colors leave explicit fallback entries unless a later supported override
replaces them; frame/copy/tab defaults follow the same rule.

New identity domains use unsigned UTF-8 ordering and compact canonical JSON with
one final LF. Authored arrays retain order; declared sets have explicit ordering.
Exact source-byte SHA-256, canonical profile identity, adapter result, mapping
application, complete generation invocation and output receipts are distinct.
Never reconstruct a supposedly verified original source identity from an object.

Runtime adapters identify their implementation by name/version. Qualification
receipts bind the actual source inventory. Existing v1 compiler digests remain
opaque legacy identities and keep their historical ordering. Equal v2 profile
identities alone do not certify equal compiler invocations or browser pixels.

## Version adapters and recipes

V1 remains maintained in the Solar Sail and Loom READMEs and Director v1 protocol.
Do not rewrite historical v1 fixtures or reinterpret their digests. Upgrade only
unambiguous semantics; retain understood target-specific values explicitly.
Downgrade is lossless by default. Explicit lossy conversion must list every
dropped, collapsed or changed leaf and bind original bytes, adapter version,
result bytes and conversion report. Future schema versions fail closed.

The finite recipe surface covers density, radius and typography. Each recipe
binds a versioned structured transformation, base identity, delta and result.
It cannot execute code or authorize adoption. Target effects still pass through
the capability reports. Contrast generation is deferred until a separate color
and accessibility policy is justified.

## Studio and Director boundary

The [candidate-set linkage](../tfsb-design-director-v1/CANDIDATE-SET.md) adds a
separate versioned identity contract. Historical Director records remain frozen.
Parsing, mapping, recipes and compilation leave candidates advisory.

Studio was not qualified for v2 ingestion or adoption in B2. In the TFNC13 source
slice ([evaluation](../../docs/evaluations/tfnc13-studio-v2-document2.md)), Studio
routes raw profile bytes through duplicate- and prototype-key-aware `parseThemeJson`
and owner validators (`bindSourceProfile` for `tf-paired-profile-v1`, including
explicit `"schema"` alias normalization, and `bindSourceProfileV2` for
`tf-paired-profile-v2`) before closed Rust `#[serde(deny_unknown_fields)]` and
TypeScript DTOs decode the payload. Solar Sail owner binding always binds the exact
bytes passed to it (`verificationStatus: "verified"`, `isTransformed: false`, and no
`parentSourceSha256`), which the Studio adapter reports in `ownerBinding`
(`inputOrigin: "source-bytes" | "resolved-legacy-alias"`), while `parentSourceSha256`
and `verificationStatus: "transformed"` (`isTransformed: true`) on
`AppThemeOpenedDocument` record Studio session custody lineage when an opened editable
v1 document is saved in `edited` mode. Native session custody binds opaque document
handles, separates `rawSourceSha256` from v1 `normalizedSha256` and v2
`canonicalDigest`, preserves owner-valid v1 extension fields and verified v2 documents
in read-only custody with byte-exact `original` save preservation, and requires a
verified `source-bytes` v1 `ownerBinding` before writing `edited` or `new-document`
saves (failing closed on runner/protocol errors and falling back to `unavailable` only
when the sidecar artifact is unavailable) without silent v2-to-v1 downgrade or full v2
visual editor/Director UI integration. See the B2 and TFNC13 evaluations for exact
qualification and open F2 (`HIGH-4`) boundaries.

This repository protocol directory does not ship in the existing npm allowlist.
The generated library declarations and package README describe the public API;
no package metadata or runtime dependency is added to distribute these docs.

## Public entrypoints and application

The Solar Sail root adds these values: `PAIRED_PROFILE_V2_SCHEMA_VERSION`,
`MAPPING_REPORT_V2_SCHEMA_VERSION`, `PAIRED_V2_ADAPTER_NAME`,
`PAIRED_V2_ADAPTER_VERSION`, `validatePairedProfileV2`, `bindSourceProfileV2`,
`canonicalizeProfileV2`, `migrateV1ToV2`, `migrateV2ToV1`, `applyRecipe`,
`classifyProfileError`, and `ERROR_CODES`. Public types are `PairedProfileV2`,
`BoundPairedProfileV2`, `MappingReportV2`, `StellarLoomMappingOptionsV2`,
`MigrationResult`, `MigrationLoss`, and `RecipeResult`. Internal error constructors
are not root exports. Existing CLI codes and v1 entrypoints are unchanged.

```ts
const bound = bindSourceProfileV2(sourceBytes);
const solar = bound.mapToSolarSail();
const loom = bound.mapToStellarLoom({
  catalog, tokenSetKey: 'flexoki-palette',
  primaryFamily: 'cyan', secondaryFamily: 'orange', defaultAccent: 'cyan',
  familyBindings: { 'system-ui': 'system-sans' },
});
// Validate/generate with each target's existing public library.
// loom.syntax accompanies loom.catalog; its effects are included in loom.report.
```

All four Loom selections are explicit; selected families must use the selected
token set. The entire base catalog and bindings are application inputs. The mapper
projects native tokens through family references, not assumptions about token key
spelling. Bound mapping reports identify actual source bytes with `sourceVerification:
"source-bytes"`. A bound `transform()` reports `transformed` and hashes the
transform's canonical serialization, never claiming original authored bytes.
Internal reports made from objects explicitly say `serialized-profile`. All three
states participate in report identity.

Solar consumes body/heading/code font families, control radius, border width and
focus color. UI family, font metrics, surface/overlay radius, spacing, border style,
elevation emphasis, code, reading and navigation remain unsupported there.
Loom consumes supplied font roles through explicit font bindings, pixel metrics,
surface radius, pixel border/focus/measure/spacing, border style and code intent.
Control/overlay radii, elevation emphasis, hover/active distinctions and navigation
prominence/density currently remain unsupported. Its neutral palette and syntax
projections consume only the roles named by report destinations. Hex alpha remains
unsupported even when its value spells fully opaque alpha; no alpha removal policy
is inferred. Other input groups are not declared consumed merely because a related
native field exists.

Loom density multiplies explicit or base-catalog spacing by 0.75, 1 or 1.25.
A supplied spacing base remains a consumed input to that calculation. For recipes,
`{schema:'tf-paired-recipe-v1',type,variant}` is the complete parameter object.
Density variants set base/density to `6px/compact`, `8px/comfortable`, or
`10px/spacious`. Radius variants `sharp`, `compact`, `default`, `relaxed`, `pill`
set all three radii to 0, 4, 8, 12, or 24 pixels respectively. Typography variants
replace the heading role only: editorial (Georgia/32px/1.25), modern
(system-ui/28px/1.25), technical (monospace/24px/1.4), system
(system-ui/24px/1.4). Recipe implementation identity is `tf-paired-recipes/1.0.0`.
Target overrides remain intact and may explicitly override a recipe's effect.

Validation returns a detached, frozen profile preserving authored hex spelling
and never freezes caller-owned objects. Canonical JSON preserves that spelling;
native projection performs the
reported spelling normalization. Canonical profile hashing uses
`tf-paired-profile-v2\n` before canonical bytes. Mapping reports use
`tf-paired-mapping-report-v2\n` and exclude their own digest field. Report compiler
labels identify semantic policies; the candidate receipt additionally binds actual
package version, source inventory and qualified runtime. A report is not proof of
native compilation. V1 reports cannot establish these properties retrospectively;
rerun from original profile bytes and complete adapter inputs. Legacy `degraded`
entries have no lossless five-status conversion.

Both migration APIs require original bytes. Valid v1 relative radii upgrade without
inventing a root size; non-hex colors and unexplained retained overrides reject.
Downgrade compares source leaves against the re-upgraded result, lists changes and
dropped leaves, and lists required v1 defaults absent from source. Empty containers
carry no semantics. Lossy conversion requires `{allowLossy:true}`; it never certifies
identical rendering. Read `losses` before any later adoption.

Within portable intent, `focus.color` refines `color.*.focus`; its report identifies
the replaced color effect. Code syntax intent refines palette-derived syntax.
Target-only overrides run after those refinements. A source leaf whose some effects
remain applied is counted once as normalized if any surviving effect normalizes
its value, otherwise consumed; its reason records partial override.
A fully replaced leaf is overridden. This avoids counting one color's core, chrome
and syntax effects as three authored leaves.
