# Paired Profile v2 materials

Status: source-semantic support only. This document records the first additive
materials slice; it does not qualify a Solar Sail, Stellar Loom, CTTN, Nebular,
personal-site, browser, accessibility, or published product emitter.

## Source contract

`PairedProfileV2.material` is optional. When present, it may contain independent
`light` and `dark` entries:

```json
{
  "material": {
    "light": {
      "panelAlpha": 0.9,
      "borderAlpha": 0.7,
      "blur": "12px",
      "saturation": 1.1,
      "reducedTransparency": "preserve"
    },
    "dark": {
      "panelAlpha": 0.86,
      "borderAlpha": 0.62,
      "blur": "8px",
      "saturation": 1.05,
      "reducedTransparency": "reduce"
    }
  }
}
```

Each mode entry is closed and all fields are optional:

- `panelAlpha` and `borderAlpha` are finite numbers in `[0, 1]`.
- `blur` is a non-negative explicit pixel length no greater than `64px`.
  Unitless `0` is accepted as the existing explicit-length identity; `rem` and
  `em` are not accepted because this field has a bounded pixel contract.
- `saturation` is a finite number in `[0, 2]`.
- `reducedTransparency` is either `"preserve"` or `"reduce"`.

There is intentionally no `fallback` or solid-fallback field in this slice:
there is no native emitter contract to consume one yet. `reducedTransparency`
is a source preference only until a target emitter and UI/accessibility review
define its behavior.

Panel and border tint remain owned by the existing
`color.{light,dark}.surface` and `color.{light,dark}.border` roles. Border width
and style remain owned by `elevation.borderWidth` and `elevation.borderStyle`.
This contract does not add a second material tint, border width, or border style
owner, and it never fades an entire scene subtree.

## Compatibility and mapping behavior

The paired-v2 validator remains strict and closed, including the nested material
objects. Unsafe data, accessors/prototype-poisoned objects, booleans in numeric
fields, non-finite numbers, out-of-range values, unknown modes, and unknown
nested fields are rejected.

When `material` is omitted, the profile has exactly the existing behavior:

- canonical profile bytes and canonical digest are unchanged;
- Solar Sail and Stellar Loom target output bytes are unchanged;
- mapping-report entries, groups, defaults, summary, and report digest are
  unchanged; and
- no material defaults are fabricated or added to the target output.

The mapping implementation adds the `material` group to report accounting only
when the profile authors the group. This conditional inclusion is required to
preserve the existing report identity for every pre-material profile.

When a material mode/leaf is authored, it is included in both Solar Sail and
Stellar Loom mapping reports as `unsupported` with an explicit target-loss
reason. The current targets have no native surface material destination:

- Solar Sail has no standalone panel alpha, border alpha, blur, saturation, or
  reduced-transparency field in its v1 output.
- Stellar Loom v2 has no such `SurfacesV2` fields, and its colors require opaque
  six-digit hex. Alpha is never flattened, faked, or silently discarded.

The existing `effect()` ownership table, explicit target-override precedence,
and generated-default filtering are unchanged. No target-specific material
override is admitted until a target has a native field. If a future target
override is added, it must be closed, applied through `effect()` after the
common material effect, and reported as `overridden` with the existing
`Explicit target override wins` reason.

Existing pre-material binaries may reject a profile carrying the new closed
`material` key. Profiles without the key remain compatible and byte-identical;
forward interchange with an older strict validator requires a separately
versioned schema/adapter decision.

## Deferred qualification

The full materials request remains open. Deferred work includes:

- Solar Sail and Stellar Loom native output fields and emitters;
- CTTN composition output changes;
- Nebular controls and app-theme DTO/bridge/UI changes;
- personal-site panel/border rendering and nested-paint behavior;
- solid fallback semantics;
- reduced-transparency preference behavior;
- forced-colors, focus, scrollbar, light/dark, and browser proof; and
- native/runtime, accessibility, installation, publication, and site
  qualification.

