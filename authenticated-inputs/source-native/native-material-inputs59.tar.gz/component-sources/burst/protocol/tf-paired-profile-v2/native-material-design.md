# Native Solar material sidecar design

Status: bounded design plus source-local paired-v2 integration contract. The
implementation is limited to new Solar material modules, a compound paired-v2
adapter, and focused tests; it does not qualify a browser or native target,
change `tfss.theme-v1`, change the paired-v2 source contract, or authorize a
release. The existing source-semantic contract in
[`materials.md`](./materials.md) remains the maintained starting point.

## Decision boundary

The maintained Solar Sail target is a closed `tfss.theme-v1` compiler. Its
`ThemeSpecification`, validator, generated package, and existing digests must
not be silently widened to carry material fields. The selected design is a
separate, optional `tfss.material-v1` sidecar emitted beside an unchanged
`tfss.theme-v1` result.

The sidecar is created only when at least one material leaf is authored. A
profile with no authored material leaves receives no material files, no
material adapter identity, and no material compiler/version metadata. Its
theme specification, CSS, descriptor, package file map, provenance and
digests remain byte-identical to the current generator.

This preserves the existing ownership split:

- paired-v2 `color.{light,dark}.surface` and `.border` own panel and border
  tint;
- `elevation.borderWidth` and `elevation.borderStyle` own border geometry;
- material owns only paint alpha, blur, saturation and the explicit
  reduced-transparency preference; and
- no material operation applies `opacity` to a panel subtree, its descendants,
  foreground, focus ring or selection.

The sidecar is Solar-specific output. It does not make Stellar Loom capable of
material fields, and the existing paired-v2 mapping report must not mark Loom
material leaves as consumed merely because Solar can emit a sidecar.

## Proposed `tfss.material-v1` result

The sidecar contains the authored material values and a binding to the exact
companion Solar theme. It does not copy panel or border color strings. The
consumer resolves those colors from the companion `tfss.theme-v1` CSS variables:
`--card` for panel paint and `--border` for border paint, in the matching mode.

```ts
type MaterialModeV1 = {
  panelAlpha?: number;             // finite [0, 1]
  borderAlpha?: number;            // finite [0, 1]
  blur?: string;                   // explicit non-negative px, <= 64px
  saturation?: number;             // finite [0, 2]
  reducedTransparency?: "preserve" | "reduce";
};

type MaterialSidecarV1 = {
  schemaVersion: "tfss.material-v1";
  theme: {
    schemaVersion: "tfss.theme-v1";
    name: string;
    version: string;
    inputDigest: string;
    outputDigest: string;
  };
  light?: MaterialModeV1;
  dark?: MaterialModeV1;
  policy?: {
    // Target policy, never inferred from an omitted source field.
    solidFallback?: "source-tint";
  };
  sourceProfileSha256?: string;
  adapter: {
    name: "@knowledge-forge-ai/theme-forge-solar-sail/material";
    version: string;
  };
};
```

### Source validator versus sidecar subset

The paired-v2 source validator remains the broad source contract. Its existing
explicit-length rule accepts `0`, `px`, `rem`, and `em` forms and retains its
surrounding-whitespace behavior. The Solar sidecar deliberately selects a
strict exact-ASCII subset: `0` or a non-negative ASCII decimal `px` value no
greater than `64px`, with no surrounding whitespace. This is an output-boundary
choice, not a silent tightening or trimming of the paired-v2 source schema.

Therefore a source-valid value such as `" 12px "` can bind and remain valid for
ordinary paired-v2 mapping, but sidecar emission fails closed at
`material.<mode>.blur` with classified `SCHEMA_VALIDATION`; it is neither
trimmed, converted, nor partially emitted. The CTTN material overlay must
abort before merging any candidate files when this exact sidecar subset check
fails.

`policy.solidFallback` is deliberately separate from portable paired-v2
intent. The current paired-v2 contract has no solid-fallback source field, so
the current source mapper must not invent one. A later explicitly authorized
target policy may set `"source-tint"`; otherwise `policy` and fallback output
are absent. A per-mode fallback or a different fallback color is a future
schema decision, not an implicit default in v1.

The sidecar's `adapter` identity is required only in an authored sidecar. It
is not added to the existing theme descriptor or package provenance for a
profile that has no material output. The direct `generateMaterialSidecar(...)`
emitter accepts only the source identity already present on the companion
`tfss.theme-v1` compilation; it never invents a profile hash. The paired-v2
compound adapter reaches that emitter only from a genuine bound snapshot. A
verified bound source uses its raw source SHA-256 in the companion theme,
sidecar, and receipt. A transformed bound uses the transformed canonical
identity and records `sourceVerification: "transformed"`. An unverified bound
uses the recomputed canonical identity only for the paired receipt and expected
identity checks, records `sourceVerification: "unverified-assertion"`, and
leaves the base theme (and therefore the sidecar) without a source hash.

The sidecar should have its own descriptor rather than extending the closed
theme descriptor:

```ts
type MaterialDescriptorV1 = {
  schema: "tfss.material-descriptor-v1";
  schemaVersion: 1;
  materialSchemaVersion: "tfss.material-v1";
  themeInputDigest: string;
  themeOutputDigest: string;
  materialInputDigest: string;
  cssOutputDigest: string;
  adapter: {
    name: "@knowledge-forge-ai/theme-forge-solar-sail/material";
    version: string;
  };
  sourceProfileSha256?: string;
};
```

Canonical sidecar members are therefore:

```text
material.json
material.descriptor.json
styles/material.css
```

They are added to a generated package only when the sidecar exists. The
existing `theme.json`, `styles/theme.css`, `theme.descriptor.json`, and
`provenance.json` semantics remain unchanged; authored sidecar files are added
to the normal inventory and digest when present. No unconditional `material`
export, file-list member, adapter name or version is introduced.

## Solar-owned API and file ownership

The smallest implementation boundary is new Solar-owned code, without adding
fields to `ThemeSpecification` or changing the v1 validator:

| Owner | Proposed responsibility |
| --- | --- |
| `packages/solar-sail/src/material-types.ts` | Closed sidecar, mode, policy and descriptor types. |
| `packages/solar-sail/src/material-validator.ts` | Safe-data, exact-key, range, explicit-px and source-policy validation. It reuses the paired-v2 field bounds but does not accept arbitrary target CSS. |
| `packages/solar-sail/src/material-compiler.ts` | Canonical sidecar JSON, mode-scoped CSS variables, descriptor and digests. |
| `packages/solar-sail/src/material-emitter.ts` | `generateMaterialSidecar(...)` returning `undefined` for no authored leaves or a deterministic sidecar result/file map. |
| `packages/solar-sail/src/index.ts` | Additive exports for the new sidecar API only; existing entrypoints retain their identities. |
| `packages/solar-sail/src/paired-v2/solar-material.ts` | Map an existing bound profile through the unchanged Solar adapter, recompile the exact specification, emit the optional sidecar, and create a separate versioned material receipt. |
| `themes/shadcn-terminal-nova/tools/compose-material.mjs` | Maintain the opt-in CTTN overlay: bind the source, verify actual base CSS/descriptor/report digests against the paired receipt before merging, add only conditional sidecar members, and preserve the base producer identity. |

The proposed emitter input is conceptually:

```ts
generateMaterialSidecar({
  compilation,                     // exact Solar compilation result
  material: profile.material,      // already validated paired-v2 source
  sourceProfileSha256,             // only the companion theme identity
  solidFallback: "source-tint",   // explicit target policy, otherwise absent
});
```

The bounded paired-v2 compound entrypoint is:

```ts
compilePairedV2SolarMaterial(boundProfile, {
  expectedSourceProfileSha256,     // checked against the bound/recomputed identity
  solidFallback: "source-tint",   // explicit policy only
});
```

It uses the identity-bearing snapshot recorded by the bound factory rather
than trusting caller-supplied `profile`, `provenance`, mapper functions, or
reports. It recomputes the unchanged base Solar mapping/report with the same
source-verification rules as the bound mapper, recompiles the resulting
specification through `compileTheme`, and only then calls
`generateMaterialSidecar`. Its result keeps the base
`specification`, compiled theme, and `solar-sail` mapping report separate from
an optional `solar-material-sidecar` result and
`tf-paired-solar-material-receipt-v1`. The receipt records the independently
recomputed canonical profile digest/SHA-256, source verification status, base
theme input/output/report digests, sidecar JSON/descriptor/CSS digests, file
digests, and every authored material leaf (including explicit zero and
`reducedTransparency` values). No-material profiles return no sidecar or
receipt.

The emitter must re-check safe data and exact ownership at its boundary. It
must not accept a whole `ThemeSpecification` with an unrecognized `material`
property, and it must not mutate or widen the existing theme specification.
The normal `tfss` v1 CLI has no paired-v2 material input; adding a CLI option is
not part of this first boundary.

## CSS output semantics

`styles/material.css` is a variable sidecar, not a component stylesheet. It
must not guess panel selectors, fade a subtree or replace a consumer's border
width/style. For each authored leaf it emits only the corresponding variable
in the existing Solar light or dark scope:

```css
:root {
  --tfss-material-panel-tint: var(--card);
  --tfss-material-panel-alpha-authored: 0.9;
  --tfss-material-panel-alpha: 0.9;
  --tfss-material-border-tint: var(--border);
  --tfss-material-border-alpha-authored: 0.7;
  --tfss-material-border-alpha: 0.7;
  --tfss-material-blur-authored: 12px;
  --tfss-material-blur: 12px;
  --tfss-material-saturation-authored: 1.1;
  --tfss-material-saturation: 1.1;
}

.dark,
:root[data-theme="dark"] {
  /* Only authored dark-mode leaves appear here. */
}
```

The exact generated CSS is canonical and deterministic; the example only
illustrates ownership. The `*-authored` variables retain the authored values;
the unqualified variables are effective values and may be neutralized by the
reduced-transparency rules below. Alpha is a unitless value and remains
separate from the source tint. A consumer may compose it for panel paint with
a supported `color-mix()` expression and use the border variable for border
paint. The sidecar never rewrites `--card` or `--border`, never strips alpha
already in a source color, and never uses element opacity.

The paired receipt preserves this distinction: each alpha, blur, or saturation
effect keeps `cssVariable` as the effective-variable compatibility alias and
also records `authoredCssVariable` and `effectiveCssVariable`. The
`reducedTransparency` preference has no direct CSS variable and therefore does
not receive a fabricated variable name.

`blur` and `saturation` are independent. An authored `"0px"` emits a literal
`--tfss-material-blur: 0px`; an authored `1` emits a literal saturation value.
Neither identity is elided from the sidecar or its source/material digest. If a
field is absent, no authored value is emitted for that field; an `initial`
reset may still appear because each mode scope clears the union of variables
authored by either mode. Any neutral value used while composing CSS belongs to
the consumer expression, not to a fabricated sidecar default.

When `policy.solidFallback` is explicitly `"source-tint"`, the sidecar may also
emit `--tfss-material-panel-solid: var(--card)` and
`--tfss-material-border-solid: var(--border)`. These are opt-in fallback
inputs for a consumer's ordered solid declaration; the emitter still does not
apply selectors to arbitrary panels. Without the policy, no fallback variables
are emitted and no fallback claim is made.

Border width and style remain outside this CSS. A consumer may continue to use
its existing `border-width`/`border-style` ownership while taking only the
material border paint variable. This prevents an alpha feature from becoming a
second geometry owner.

## Reduced-transparency semantics

`reducedTransparency` is per mode and selects the default baseline, not a
permission to ignore accessibility signals. A mode with `"reduce"` starts from
neutral effective values even with no OS or manual signal. A mode with
`"preserve"` or no field starts from authored effective values. The root-level
manual control is consumer-owned and uses:

```html
<html data-tf-reduced-transparency="reduce">
```

The value `preserve` is also accepted as an explicit manual override. The
precedence below is part of the proposed sidecar contract:

| Mode field | No signal | OS `prefers-reduced-transparency: reduce` | Manual `data-tf-reduced-transparency="reduce"` | `forced-colors: active` |
| --- | --- | --- | --- | --- |
| omitted | Keep authored variables unchanged | Neutralize all authored material in that mode | Neutralize all authored material in that mode | Use system-color rules if material variables exist; effects are neutralized. |
| `preserve` | Keep authored values | Neutralize all authored material in that mode | Neutralize all authored material in that mode | Forced colors wins; use system colors and neutral effects. |
| `reduce` | Neutralize authored alpha/blur/saturation | Neutralize all authored material in that mode | Neutralize all authored material in that mode | Forced colors wins; use system colors and neutral effects. |

Neutralization changes only authored material variables: authored panel or
border alpha becomes `1`, authored blur becomes `0px`, and authored saturation
becomes `1`. It does not create a missing variable. The sidecar first resets
the union of every material variable authored by either mode to `initial` in
each light/dark scope, then writes that mode's authored values. `initial` is
the guaranteed-invalid custom-property value, so a consumer fallback can take
effect; it is a cascade boundary, not a fabricated source value. The same
reset is used by neutralization and forced-colors rules, preventing a light
value from leaking into a dark mode that omits that field. If the explicit
solid-fallback policy is present, the consumer may use the corresponding
source tint while reduced; otherwise the consumer's existing non-material paint
remains its fallback.

OS reduction and manual `reduce` neutralize all authored material in all modes,
including modes whose source field is `preserve` or omitted. Manual `preserve`
may explicitly restore authored normal effects, including for a source mode
whose baseline is `reduce`; its rules are ordered after OS/manual reduction.
Forced colors always wins. It must set authored material paint to system colors
(`Canvas`/`CanvasText` as appropriate), neutralize blur and saturation, and
leave the browser's forced-color adjustment behavior intact. The sidecar must
not set `forced-color-adjust: none` or use opacity to simulate accessibility
behavior.

These rules are a contract to qualify later; they are not a claim that every
current browser supports the media feature, `color-mix()`, or backdrop filters.
The later browser/accessibility gate must test fallback ordering and all three
signals in light and dark modes.

## Identity, reports and compatibility

The existing paired-v2 mapper continues to report material leaves as
`unsupported`; the compound adapter does not rewrite that report as native
consumption. The separate material receipt is not a replacement for the base
report. The bounded integration produces a distinct material result/receipt
bound to:

- the exact companion theme input and output digests;
- the canonical material input digest;
- the effective source identity carried by the companion theme when present;
- the recomputed canonical profile identity plus explicit verification status;
- the sidecar adapter name/version; and
- every emitted sidecar member and digest.

The receipt never upgrades an unverified caller assertion to `verified`. For a
genuine verified bound, the raw source identity is shared by the base theme,
sidecar, and receipt. A transformed profile carries its distinct transformed
canonical identity and `transformed` status. For an unverified profile, the
base theme and sidecar intentionally omit `sourceProfileSha256`, while the
receipt records the recomputed canonical identity with
`unverified-assertion` status.

The existing report's `effect()` precedence remains authoritative for tint and
target overrides. Because the sidecar resolves `--card`/`--border` from the
final companion theme, an explicit Solar palette override wins the tint without
creating a second material tint field. No Solar target override for material is
admitted by this design.

Profiles without authored material leaves must retain the current output and
report identity. Profiles with authored material may gain sidecar files and a
sidecar-specific identity, but the base theme output remains the ordinary
`tfss.theme-v1` output. Existing pre-material binaries can continue consuming
the base theme files; they must not be described as consuming the sidecar.

## Downstream boundaries

### CTTN composer

The maintained `themes/shadcn-terminal-nova/tools/compose-material.mjs` overlay
regenerates from the bound paired-v2 source and calls the compound Solar
adapter. `compose-lib.mjs` remains the ordinary base producer and is not edited
by this slice:

1. map and compile the ordinary Solar theme as today;
2. if actual material leaves are authored, call
   `compilePairedV2SolarMaterial` and retain its separate material receipt;
3. verify the actual base `styles/theme.css`,
   `theme.descriptor.json` input/output digests, and Solar mapping-report digest
   against the paired compilation/receipt before any merge;
4. merge the three optional sidecar files and receipt into the package,
   recompute its inventory/provenance, and retain a separate provenance
   `overlay` identity without changing the base `producer`; and
5. add a sidecar-specific mapping/result receipt without changing the Loom
   report's unsupported material entries.

No consumer-local CSS patch is a substitute for this regeneration. With no
material leaves, CTTN must produce the current candidate file map and digests
byte-for-byte. The root material JSON files are explicit conditional package
members; existing `styles` and `reports` directory entries cover the CSS and
receipt, and no material export is added to `package.json.exports`. The base
composition inventory's `composition.json`/`provenance.json` exclusions remain
an independently tracked boundary rather than a reason to edit
`compose-lib.mjs`.

### Nebular controls

Nebular's TypeScript DTOs, Rust closed DTOs, bridge validation and controls are
separate owners. They should not add material fields until the sidecar schema
and reduction policy are accepted. A later control slice must preserve each
light/dark leaf, explicit zero values, unknown-field rejection and the existing
document-custody behavior. It must show when a sidecar is unavailable rather
than claiming that Loom or Solar v1 consumed material.

### Personal-site consumption

The personal-site consumer owns panel selectors and nested painting. It may use
the sidecar variables for panel backgrounds and border paint, but must inspect
`background-clip`, nested fills, pseudo-elements, gradients and background
layers. `background-clip: padding-box` or another explicit paint boundary may
be needed so a translucent border does not accidentally paint over a child
fill. Foreground, focus, selection and scrollbar styling remain separate.
The sidecar must never be applied through a generic root opacity rule.

## Alternative: direct closed-schema extension

The credible alternative is a new `tfss.theme-v2` specification containing a
closed `surfaces.material` object, with a versioned v1-to-v2 adapter and native
compiler output. It would make one specification carry both theme and material
and avoid a package merge step. It would also require a new target schema,
generated declarations, validators, compiler, descriptor, CLI dispatch,
paired mapping, CTTN, Studio custody and migration fixtures to move together.
Adding the fields to `tfss.theme-v1` without a version change is not a viable
alternative: the current v1 contract rejects unknown fields, and silently
widening it would invalidate the closed-schema and old-binary guarantees.

The sidecar is selected for this bounded design because it keeps the existing
theme schema and compiler identity intact, makes the optional file boundary
observable, permits rollback by omitting the sidecar, and lets consumers adopt
material deliberately. The direct extension can be reconsidered if a future
owner requires atomic theme/material schema migration across all targets.

## Acceptance focus for integration and qualification

Integration and qualification authorization remain separate from this design.
The focused Solar proof should include:

- exact no-material theme/package/provenance bytes and digests against the
  pre-sidecar baseline;
- deterministic canonical `tfss.material-v1` JSON and descriptor binding to
  the companion theme digests;
- compound paired-v2 mapping with the unchanged `solar-sail`/Loom unsupported
  reports and a separate material receipt;
- light/dark authored fields, explicit `0px` blur and identity alpha retained;
- source-owned tint resolution after explicit Solar color overrides;
- rejection of unsafe data, unknown nested keys, booleans, non-finite values,
  invalid lengths and out-of-range alpha/saturation;
- absence of sidecar files and adapter/version names when no leaf is authored;
- solid fallback only when explicitly requested;
- OS/manual/forced-colors reduction precedence, with forced colors winning;
- no `opacity` subtree rule, no border width/style emission and no tint copy;
- old `tfss.theme-v1` validation remaining closed; and
- later CTTN, Nebular, personal-site and browser/accessibility checks as
  separate acceptance boundaries.

No dependency, package-version, publication, release, house-style or
soft-light-branch decision is part of this design. The Solar sidecar and CTTN
overlay boundaries are now source-local implementation slices; native browser,
Nebular, personal-site, release and publication qualification remain future
owner decisions.
