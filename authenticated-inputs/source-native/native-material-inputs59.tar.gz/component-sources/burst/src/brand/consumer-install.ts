import { lstat } from "node:fs/promises";

import { DiagnosticError, fail } from "../diagnostics.js";
import { computeRawSha256 } from "../digests.js";
import { identity, readExactBuffer, sameFileIdentity } from "../filesystem.js";
import { executeManagedOutputTransaction, type ManagedOutput } from "../managed-output-transaction.js";
import { executeCanonicalTransaction } from "../transaction.js";
import { verifyLoadedProjectSnapshot } from "../project.js";
import { serializeConsumerBrandLock } from "./consumer-lock.js";
import { revalidateConsumerSources } from "./consumer-source.js";
import {
  disposeConsumerPlan,
  getConsumerPlanInternals,
  type ConsumerAdoptionPlan,
  type ConsumerInstallPlan,
  type ConsumerPlanInternals,
  type ConsumerPlanSummary,
  type ConsumerSyncPlan,
} from "./consumer-plan.js";

export interface ConsumerTransactionHooks {
  readonly beforeStage?: (index: number) => void | Promise<void>;
  readonly afterStage?: (index: number) => void | Promise<void>;
  readonly beforeJournal?: () => void | Promise<void>;
  readonly afterJournal?: () => void | Promise<void>;
  readonly beforeOutputPromotion?: (index: number) => void | Promise<void>;
  readonly beforeLockPromotion?: () => void | Promise<void>;
  readonly beforeRollback?: (index: number) => void | Promise<void>;
  readonly beforeCleanup?: (index: number) => void | Promise<void>;
}
export interface ConsumerInstallResult {
  readonly operation: "install" | "sync" | "adopt";
  readonly packages: readonly string[];
  readonly profiles: readonly string[];
  readonly destinations: readonly string[];
  readonly omittedOptional: readonly string[];
  readonly lockDigest: string;
  readonly writtenOutputs: number;
}

function sha(bytes: Uint8Array): string { return `sha256:${computeRawSha256(bytes)}`; }
async function verifyOne(internals: ConsumerPlanInternals, index: number): Promise<void> {
  const output = internals.outputs[index]!;
  const current = await lstat(output.absoluteDestination).catch(() => undefined);
  if (output.snapshot.kind === "absent") {
    if (current !== undefined) fail({ operation: "install", domain: "transaction" }, "CONSUMER_DESTINATION_CHANGED", `Destination '${output.destination}' appeared after planning.`, output.destination);
    return;
  }
  if (current === undefined || current.isSymbolicLink() || !current.isFile() || output.snapshot.identity === undefined || !sameFileIdentity(identity(current), output.snapshot.identity) || output.handle === undefined) fail({ operation: "install", domain: "transaction" }, "CONSUMER_DESTINATION_CHANGED", `Destination '${output.destination}' changed after planning.`, output.destination);
  const opened = await output.handle.stat();
  if (!sameFileIdentity(identity(opened), output.snapshot.identity)) fail({ operation: "install", domain: "transaction" }, "CONSUMER_DESTINATION_CHANGED", `Opened destination '${output.destination}' changed.`, output.destination);
  const bytes = await readExactBuffer(output.handle, opened.size, 0, { operation: "install", domain: "transaction" }, 8 * 1_048_576);
  if (sha(bytes) !== output.snapshot.digest) fail({ operation: "install", domain: "transaction" }, "CONSUMER_DESTINATION_CHANGED", `Destination '${output.destination}' bytes changed.`, output.destination);
}
function result(plan: ConsumerPlanSummary, writtenOutputs: number): ConsumerInstallResult { return Object.freeze({ operation: plan.operation, packages: plan.packages, profiles: plan.profiles, destinations: Object.freeze(plan.outputs.map((entry) => entry.destination)), omittedOptional: plan.omittedOptional, lockDigest: plan.lockDigest, writtenOutputs }); }

async function executeAdoption(plan: ConsumerPlanSummary, internals: ConsumerPlanInternals, hooks: ConsumerTransactionHooks): Promise<ConsumerInstallResult> {
  if (internals.adoptionProjectBytes === undefined) throw new Error("Adoption plan lacks private canonical bytes.");
  const nextFiles = new Map(internals.project.canonicalFiles);
  nextFiles.set(".tfsb/project.toml", internals.adoptionProjectBytes);
  nextFiles.set(".tfsb/brand.lock.json", Buffer.from(serializeConsumerBrandLock(internals.nextLock), "utf8"));
  await executeCanonicalTransaction({
    root: internals.project.root,
    expectedSnapshot: internals.project.snapshot,
    nextFiles,
    operation: "install",
    verifyExternalState: async () => {
      await revalidateConsumerSources(internals.sources);
      for (let index = 0; index < internals.outputs.length; index++) await verifyOne(internals, index);
    },
    hooks: {
      beforeStageCreate: () => hooks.beforeStage?.(0),
      afterStageWrite: () => hooks.afterStage?.(0),
      beforePromotion: () => hooks.beforeLockPromotion?.(),
    },
  });
  return result(plan, 0);
}

async function executeOutputs(plan: ConsumerPlanSummary, internals: ConsumerPlanInternals, hooks: ConsumerTransactionHooks): Promise<ConsumerInstallResult> {
  const lockDestination = `${internals.project.root}/.tfsb/brand.lock.json`;
  const lockBytes = Buffer.from(serializeConsumerBrandLock(internals.nextLock), "utf8");
  const outputs: ManagedOutput[] = internals.outputs.map((output) => ({
    destination: output.destination,
    absoluteDestination: output.absoluteDestination,
    bytes: output.bytes,
    snapshot: output.snapshot,
    parentAuthority: output.parentAuthority,
    maxBytes: 8 * 1_048_576,
    ...(output.handle === undefined ? {} : { handle: output.handle }),
  }));
  const oldLockSnapshot = internals.project.snapshot.files.get(".tfsb/brand.lock.json");
  const lock: ManagedOutput = {
    destination: ".tfsb/brand.lock.json",
    absoluteDestination: lockDestination,
    bytes: lockBytes,
    snapshot: oldLockSnapshot === undefined
      ? { kind: "absent" }
      : { kind: "file", identity: oldLockSnapshot, digest: oldLockSnapshot.digest },
    parentAuthority: internals.lockParentAuthority,
    // Retain the historical 8 MiB transaction bound; the brand-lock parser
    // still applies its own earlier closed schema bound before planning.
    maxBytes: 8 * 1_048_576,
  };
  const transaction = await executeManagedOutputTransaction({
    root: internals.project.root,
    namespace: "consumer",
    outputs,
    lock,
    semanticLockUnchanged: internals.oldLock?.lockDigest === internals.nextLock.lockDigest,
    verifySource: () => revalidateConsumerSources(internals.sources),
    verifyProject: (ignoredCanonicalFiles) => verifyLoadedProjectSnapshot(internals.project, "install", ignoredCanonicalFiles),
    hooks,
  });
  return result(plan, transaction.writtenOutputs);
}

async function execute(plan: ConsumerPlanSummary, hooks: ConsumerTransactionHooks = {}): Promise<ConsumerInstallResult> {
  const internals = getConsumerPlanInternals(plan);
  if (internals === undefined || internals.disposed || internals.executed || !Object.isFrozen(plan)) fail({ operation: "install", domain: "transaction" }, "CONSUMER_INVALID_PLAN", "Consumer apply requires an authentic unused plan.");
  internals.executed = true;
  try { return internals.operation === "adopt" ? await executeAdoption(plan, internals, hooks) : await executeOutputs(plan, internals, hooks); }
  finally { await disposeConsumerPlan(plan); }
}

export async function executeConsumerInstallPlan(plan: ConsumerInstallPlan, hooks?: ConsumerTransactionHooks): Promise<ConsumerInstallResult> { return execute(plan, hooks); }
export async function executeConsumerSyncPlan(plan: ConsumerSyncPlan, hooks?: ConsumerTransactionHooks): Promise<ConsumerInstallResult> { return execute(plan, hooks); }
export async function executeConsumerAdoptionPlan(plan: ConsumerAdoptionPlan, hooks?: ConsumerTransactionHooks): Promise<ConsumerInstallResult> { return execute(plan, hooks); }
