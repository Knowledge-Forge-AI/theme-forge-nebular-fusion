"""Compose the locked Darwin runtime from explicit, inventoried source inputs.

No network, package execution, lifecycle, addon loading or build is performed.
Paths are invocation inputs, never part of the portable recipe or receipt.
"""
import argparse
import base64
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import stat
import tarfile

def sha(data):
    return hashlib.sha256(data).hexdigest()

def regular(path):
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_size > 16 * 1024 * 1024:
        raise ValueError('INPUT_SHAPE')
    data = path.read_bytes()
    after = path.lstat()
    stable = ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns', 'st_mode', 'st_nlink')
    if len(data) != info.st_size or any(getattr(after, key) != getattr(info, key) for key in stable):
        raise ValueError('INPUT_CHANGED')
    return data, 0o755 if info.st_mode & 0o111 else 0o644

def main():
    parser = argparse.ArgumentParser()
    for name in ('compiled', 'source', 'quarantine', 'out'):
        parser.add_argument('--' + name, type=Path, required=True)
    args = parser.parse_args()
    args.out.mkdir(mode=0o700)
    root = args.out / 'component'
    root.mkdir(mode=0o755)
    rows, support = [], []

    def put(rel, data, mode, origin):
        parts = PurePosixPath(rel)
        if parts.is_absolute() or '..' in parts.parts or any(p.lower() in {'db', 'raw', '.serena'} for p in parts.parts):
            raise ValueError('MEMBER_PATH')
        dest = root / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        with dest.open('xb') as stream:
            stream.write(data)
        dest.chmod(mode)
        rows.append({'path': rel, 'bytes': len(data), 'sha256': sha(data),
                     'mode': '100755' if mode & 0o111 else '100644', 'origin': origin})

    for file in sorted(args.compiled.rglob('*')):
        if file.is_symlink():
            raise ValueError('COMPILED_LINK')
        if file.is_dir():
            continue
        data, mode = regular(file)
        put(file.relative_to(args.compiled).as_posix(), data, mode, 'compiled-burst')
    if len(rows) != 303:
        raise ValueError('COMPILED_COUNT')

    lock_bytes, _ = regular(args.source / 'package-lock.json')
    raster_lock_bytes, _ = regular(args.source / 'packages/tfsb-raster-resvg/package-lock.json')
    lock, raster_lock = json.loads(lock_bytes), json.loads(raster_lock_bytes)
    locks = {'package-lock.json': sha(lock_bytes),
             'packages/tfsb-raster-resvg/package-lock.json': sha(raster_lock_bytes)}
    notice, _ = regular(args.source / 'packages/tfsb-raster-resvg/THIRD_PARTY_NOTICES.md')
    wasm_sha = '22bf6e9f9a100d972da0411a69c5ba504367fc1fa87b3b64e3f35e53926d2d70'
    for expected in (b'@resvg/resvg-wasm@2.6.2', b'9ca058462ac529120c8cc84ddcd6fef644cc5406', wasm_sha.encode(), b'https://github.com/thx/resvg-js/tree/v2.6.2'):
        if expected not in notice:
            raise ValueError('RESVG_NOTICE_IDENTITY')

    packages = []
    for name, version, authority in (
        ('@xmldom/xmldom', '0.9.12', lock), ('fflate', '0.8.3', lock),
        ('smol-toml', '1.8.0', lock), ('@resvg/resvg-wasm', '2.6.2', raster_lock)):
        rec = authority['packages']['node_modules/' + name]
        if rec['version'] != version or not rec['resolved'].startswith('https://registry.npmjs.org/') or '?' in rec['resolved']:
            raise ValueError('LOCKED_PACKAGE')
        archive_name = name.replace('@', 'at-').replace('/', '__') + '-' + version + '.tgz'
        archive, _ = regular(args.quarantine / archive_name)
        if len(archive) > 8 * 1024 * 1024 or rec['integrity'] != 'sha512-' + base64.b64encode(hashlib.sha512(archive).digest()).decode():
            raise ValueError('LOCK_INTEGRITY')
        parsed, seen, total = [], set(), 0
        with tarfile.open(fileobj=io.BytesIO(archive), mode='r:gz') as tar:
            members = tar.getmembers()
            if len(members) > 2048:
                raise ValueError('ARCHIVE_COUNT')
            for member in members:
                path = PurePosixPath(member.name)
                if path.is_absolute() or '..' in path.parts or not path.parts or path.parts[0] != 'package':
                    raise ValueError('ARCHIVE_PATH')
                if member.isdir():
                    continue
                if not member.isfile() or member.issym() or member.islnk() or not 0 <= member.size <= 8 * 1024 * 1024:
                    raise ValueError('ARCHIVE_TYPE')
                rel = PurePosixPath(*path.parts[1:]).as_posix()
                if not rel or rel in seen:
                    raise ValueError('ARCHIVE_DUPLICATE')
                seen.add(rel)
                body = tar.extractfile(member).read(8 * 1024 * 1024 + 1)
                total += len(body)
                if len(body) != member.size or total > 32 * 1024 * 1024:
                    raise ValueError('ARCHIVE_BYTES')
                parsed.append((rel, body, 0o755 if member.mode & 0o111 else 0o644))
        pkg = json.loads(next(body for rel, body, mode in parsed if rel == 'package.json'))
        if (pkg['name'], pkg['version'], pkg['license']) != (name, version, rec['license']):
            raise ValueError('PACKAGE_IDENTITY')
        licenses = [{'path': rel, 'bytes': len(body), 'sha256': sha(body)} for rel, body, mode in parsed
                    if 'license' in PurePosixPath(rel).name.lower() or 'notice' in PurePosixPath(rel).name.lower()]
        if not licenses and name == '@resvg/resvg-wasm':
            mpl, _ = regular(args.source / 'packages/tfsb-raster-resvg/MPL-2.0.txt')
            if b'Mozilla Public License' not in mpl or b'Version 2.0' not in mpl:
                raise ValueError('RESVG_LICENSE')
            licenses = [{'path': 'packages/tfsb-raster-resvg/MPL-2.0.txt', 'bytes': len(mpl), 'sha256': sha(mpl),
                         'noticeSha256': sha(notice), 'source': 'exact maintained external MPL/source/WASM notice verified'}]
        if not licenses:
            raise ValueError('PACKAGE_LICENSE')
        prefix = 'packages/tfsb-raster-resvg/node_modules/' if name == '@resvg/resvg-wasm' else 'node_modules/'
        for rel, body, mode in parsed:
            put(prefix + name + '/' + rel, body, mode, 'locked-registry-archive')
        packages.append({'name': name, 'version': version, 'license': pkg['license'], 'archiveBytes': len(archive),
                         'archiveSha256': sha(archive), 'integrity': rec['integrity'], 'members': len(parsed),
                         'unpackedBytes': total, 'licenses': licenses, 'registrySignatureOrAttestation': 'not verified or claimed'})

    raster_files = ['package.json', 'package-lock.json', 'index.js', 'index.d.ts', 'LICENSE', 'NOTICE',
                    'COMMERCIAL-LICENSE.md', 'MPL-2.0.txt', 'THIRD_PARTY_NOTICES.md']
    protocol_files = ['README.md', 'envelope.schema.json', 'inventory.json', 'inventory-1.1.json', 'inventory-1.2.json',
                      'requests.schema.json', 'requests-1.1.schema.json', 'requests-1.2.schema.json', 'results.schema.json',
                      'results-1.1.schema.json', 'results-1.2.schema.json']
    native_files = ['manifest.json', 'native-addon-posix-openat-v1.node']
    for prefix, names in [('packages/tfsb-raster-resvg/', raster_files), ('protocol/tfsb-studio-v1/', protocol_files),
                          ('native/directory-snapshot/prebuilds/darwin-arm64/', native_files)]:
        for name in names:
            rel = prefix + name
            data, mode = regular(args.source / rel)
            if rel in locks and sha(data) != locks[rel]:
                raise ValueError('LOCK_CHANGED')
            put(rel, data, mode, 'source-bound-support')
            support.append({'path': rel, 'sha256': sha(data), 'bytes': len(data)})
    manifest = json.loads((root / 'native/directory-snapshot/prebuilds/darwin-arm64/manifest.json').read_bytes())
    addon = root / 'native/directory-snapshot/prebuilds/darwin-arm64/native-addon-posix-openat-v1.node'
    if sha(addon.read_bytes()) != manifest['artifactSha256'] or addon.stat().st_size != manifest['artifactBytes']:
        raise ValueError('NATIVE_IDENTITY')
    wasm_rel = 'packages/tfsb-raster-resvg/node_modules/@resvg/resvg-wasm/index_bg.wasm'
    if sha((root / wasm_rel).read_bytes()) != wasm_sha:
        raise ValueError('WASM_IDENTITY')

    # Every member, including compiled/native/WASM bytes. The single upstream
    # Linux-build prefix is allowed only in the exact locked, unmodified WASM.
    upstream_hits = []
    for row in rows:
        data, _ = regular(root / row['path'])
        if sha(data) != row['sha256']:
            raise ValueError('OUTPUT_CHANGED')
        if any(pattern in data for pattern in (b'/Users/', b'/private/var/folders/', b'/var/folders/', b'/Volumes/', b'/private/tmp/')):
            raise ValueError('PRIVATE_LOCATOR')
        if b'/home/' in data:
            if row['path'] != wasm_rel or row['sha256'] != wasm_sha:
                raise ValueError('UNCLASSIFIED_HOME_LOCATOR')
            upstream_hits.append({'path': row['path'], 'sha256': row['sha256'], 'classification': 'locked-upstream-WASM-build-prefix'})
    receipt = {'schema': 'nebular.burst-runtime-composition41.v1', 'status': 'private-input-composition-only',
               'target': 'aarch64-apple-darwin', 'compiledFilesPreserved': 303, 'files': sorted(rows, key=lambda row: row['path']),
               'sourceLocks': locks, 'sourceBoundSupport': support, 'runtimePackages': packages,
               'nativeAddon': {key: manifest[key] for key in ('artifactSha256', 'artifactBytes', 'nodeApiVersion', 'qualificationSourceCommit', 'nativeSourceSha256')},
               'recipeSha256': sha(Path(__file__).read_bytes()),
               'locatorScan': {'files': len(rows), 'privateHits': 0, 'upstreamClassifications': upstream_hits},
               'newDependencyVersion': False, 'executedPackageCode': False, 'nativeBuild': False, 'hosted': False, 'publication': False}
    (args.out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'files': len(rows), 'bytes': sum(row['bytes'] for row in rows), 'sourceBoundSupport': len(support), 'privateLocatorHits': 0, 'nativeBuild': False}))

if __name__ == '__main__':
    main()
