#!/usr/bin/env node

import { lstat, mkdir, readFile, writeFile } from "node:fs/promises";
import { basename, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const VERSION = "1.3";
const PNG_BASE64 = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVQIHWP4z8DwHwAFgAI/ScLttAAAAABJRU5ErkJggg==";
const PNG_DIGEST = "sha256:d8aeb7b31114535bbf9035568464d5eb3dadfabaa70525a487d2c04571203426";
const HANDLE = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";
const ZERO_DIGEST = `sha256:${"0".repeat(64)}`;
const RECORD_DIGEST = `sha256:${"b".repeat(64)}`;
const RECIPE_DIGEST = `sha256:${"c".repeat(64)}`;

function usageError() {
  throw new Error("usage: generate-protocol-1.3.mjs --source-protocol-root PATH --output-protocol-root PATH");
}

function parseArgs(argv) {
  if (argv.length !== 4 || argv[0] !== "--source-protocol-root" || argv[2] !== "--output-protocol-root"
      || argv[1].startsWith("-") || argv[3].startsWith("-")) usageError();
  return { source: resolve(argv[1]), output: resolve(argv[3]) };
}

async function readRegularJson(root, relativePath) {
  const path = resolve(root, relativePath);
  const info = await lstat(path);
  if (!info.isFile() || info.isSymbolicLink()) throw new Error(`protocol source is not a regular file: ${basename(path)}`);
  const bytes = await readFile(path);
  try {
    return JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
  } catch {
    throw new Error(`protocol source JSON is invalid: ${basename(path)}`);
  }
}

function writeJson(value) {
  return `${JSON.stringify(value, null, 2)}\n`;
}

async function writeRegularJson(root, relativePath, value) {
  const path = resolve(root, relativePath);
  await mkdir(resolve(path, ".."), { recursive: true, mode: 0o755 });
  await writeFile(path, writeJson(value), { mode: 0o644, flag: "w" });
}

function addIllustrationRequests(input) {
  const output = structuredClone(input);
  output.$id = "https://knowledge-forge.ai/protocol/tfsb-studio-v1/requests-1.3.schema.json";
  output.title = "TFSB Studio protocol 1.3 requests and client notifications";
  output.$defs.illustrationHandle = {
    type: "string",
    minLength: 43,
    maxLength: 43,
    pattern: "^[A-Za-z0-9_-]{43}$",
  };
  output.anyOf.push({
    $ref: "#/$defs/request",
    properties: {
      method: { const: "illustration.open" },
      params: {
        type: "object",
        additionalProperties: false,
        required: ["sessionNonce", "directory", "purpose"],
        properties: {
          sessionNonce: { $ref: "#/$defs/nonce" },
          directory: { $ref: "#/$defs/absolutePath" },
          purpose: { const: "illustration-carrier" },
        },
      },
    },
  });
  output.anyOf.push({
    $ref: "#/$defs/request",
    properties: {
      method: { const: "illustration.preview.get" },
      params: {
        type: "object",
        additionalProperties: false,
        required: ["sessionNonce", "derivativeHandle"],
        properties: {
          sessionNonce: { $ref: "#/$defs/nonce" },
          derivativeHandle: { $ref: "#/$defs/illustrationHandle" },
        },
      },
    },
  });
  return output;
}

function publicTokenSchema() {
  return {
    oneOf: [
      { type: "null" },
      {
        type: "string",
        minLength: 1,
        maxLength: 128,
        pattern: "^[A-Za-z0-9][A-Za-z0-9._:-]*$",
        allOf: [{ not: { pattern: "^(?:(?:[sS][kK]|[pP][kK]|[rR][kK]|[tT][oO][kK][eE][nN]|[sS][eE][cC][rR][eE][tT]|[bB][eE][aA][rR][eE][rR])(?:[-_]|$)|[aA][pP][iI][-_][kK][eE][yY](?:[-_]|$))" } }, {
          not: { pattern: "(?:^|[^A-Za-z0-9])(?:sk-(?:proj-)?[A-Za-z0-9_-]{16,}|gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|AIza[A-Za-z0-9_-]{30,})" },
        }, {
          not: { pattern: "(?:^|[^A-Za-z0-9])eyJ[A-Za-z0-9_-]+\\.[A-Za-z0-9_-]+\\.[A-Za-z0-9_-]+" },
        }],
      },
    ],
  };
}

function illustrationCapabilitySchema() {
  return {
    type: "object",
    additionalProperties: false,
    required: ["schemaVersion", "methods", "limits", "state"],
    properties: {
      schemaVersion: { const: 1 },
      methods: {
        type: "object", additionalProperties: false, required: ["open", "previewGet"],
        properties: { open: { const: true }, previewGet: { const: true } },
      },
      limits: {
        type: "object", additionalProperties: false,
        required: ["maxPreviewBytes", "maxDimension", "maxPixels", "maxDerivativeHandles"],
        properties: {
          maxPreviewBytes: { const: 4194304 }, maxDimension: { const: 1024 },
          maxPixels: { const: 1048576 }, maxDerivativeHandles: { const: 4 },
        },
      },
      state: { const: "read-only" },
    },
  };
}

function illustrationSnapshotSchema() {
  const digest = { $ref: "#/$defs/digest" };
  const dimensions = {
    type: "object", additionalProperties: false, required: ["width", "height"],
    properties: {
      width: { type: "integer", minimum: 1, maximum: 16384 },
      height: { type: "integer", minimum: 1, maximum: 16384 },
    },
  };
  const source = {
    type: "object", additionalProperties: false,
    required: ["sha256", "mime", "byteLength", "dimensions", "alpha"],
    properties: {
      sha256: digest, mime: { enum: ["image/png", "image/webp"] },
      byteLength: { type: "integer", minimum: 1, maximum: 33554432 },
      dimensions,
      alpha: { enum: ["opaque", "straight", "premultiplied", "unknown"] },
    },
  };
  const derivative = {
    type: "object", additionalProperties: false,
    required: ["derivativeHandle", "id", "recipeDigest", "sha256", "byteLength", "mime", "width", "height", "alpha", "verification"],
    properties: {
      derivativeHandle: { type: "string", minLength: 43, maxLength: 43, pattern: "^[A-Za-z0-9_-]{43}$" },
      id: { type: "string", minLength: 1, maxLength: 128, pattern: "^[a-z][a-z0-9]*(?:[-._][a-z0-9]+)*$" },
      recipeDigest: digest, sha256: digest,
      byteLength: { type: "integer", minimum: 1, maximum: 33554432 },
      mime: { enum: ["image/png", "image/webp"] },
      width: { type: "integer", minimum: 1, maximum: 16384 },
      height: { type: "integer", minimum: 1, maximum: 16384 },
      alpha: { enum: ["opaque", "has-alpha", "unknown"] },
      verification: { enum: ["png-pixels-decoded", "webp-header-only"] },
    },
  };
  return {
    type: "object", additionalProperties: false,
    required: ["schema", "version", "illustrationHandle", "manifestDigest", "recordDigest", "illustrationId", "revision", "operation", "provider", "model", "source", "lineage", "derivatives", "capabilities", "state"],
    properties: {
      schema: { const: "tfsb.illustration-service-snapshot" }, version: { const: 1 },
      illustrationHandle: { type: "string", minLength: 43, maxLength: 43, pattern: "^[A-Za-z0-9_-]{43}$" },
      manifestDigest: digest, recordDigest: digest,
      illustrationId: { type: "string", minLength: 1, maxLength: 128, pattern: "^[a-z][a-z0-9]*(?:[-._][a-z0-9]+)*$" },
      revision: { type: "integer", minimum: 1, maximum: 1000000 },
      operation: { enum: ["import", "generate", "edit"] },
      provider: publicTokenSchema(), model: publicTokenSchema(), source,
      lineage: { type: "object", additionalProperties: false, required: ["parentDigest"], properties: { parentDigest: { oneOf: [digest, { type: "null" }] } } },
      derivatives: { type: "array", minItems: 1, maxItems: 4, uniqueItems: true, items: derivative },
      capabilities: {
        type: "object", additionalProperties: false, required: ["snapshot", "preview", "authoring", "export", "install"],
        properties: { snapshot: { const: true }, preview: { const: true }, authoring: { const: false }, export: { const: false }, install: { const: false } },
      },
      state: { const: "ready" },
    },
  };
}

function illustrationPreviewSchema() {
  return {
    type: "object", additionalProperties: false,
    required: ["schema", "version", "derivativeHandle", "mime", "bytesBase64", "byteLength", "sha256", "width", "height", "alpha", "verification"],
    properties: {
      schema: { const: "tfsb.illustration-service-preview" }, version: { const: 1 },
      derivativeHandle: { type: "string", minLength: 43, maxLength: 43, pattern: "^[A-Za-z0-9_-]{43}$" },
      mime: { enum: ["image/png", "image/webp"] },
      bytesBase64: { type: "string", minLength: 4, maxLength: 5592408, pattern: "^[A-Za-z0-9+/]*={0,2}$", contentEncoding: "base64" },
      byteLength: { type: "integer", minimum: 1, maximum: 4194304 }, sha256: { $ref: "#/$defs/digest" },
      width: { type: "integer", minimum: 1, maximum: 1024 }, height: { type: "integer", minimum: 1, maximum: 1024 },
      alpha: { enum: ["opaque", "has-alpha", "unknown"] },
      verification: { enum: ["png-pixels-decoded", "webp-header-only"] },
    },
  };
}

function addIllustrationResults(input) {
  const output = structuredClone(input);
  output.$id = "https://knowledge-forge.ai/protocol/tfsb-studio-v1/results-1.3.schema.json";
  output.title = "TFSB Studio protocol 1.3 result and server-notification shapes";
  output.$defs.illustrationCapability = illustrationCapabilitySchema();
  output.$defs.illustrationSnapshot = illustrationSnapshotSchema();
  output.$defs.illustrationPreview = illustrationPreviewSchema();
  output.$defs.initializeResult.properties.selectedVersion = { const: "1.3" };
  output.$defs.initializeResult.properties.capabilities.required = ["methods", "limits", "brand", "illustration"];
  output.$defs.initializeResult.properties.capabilities.properties.illustration = { $ref: "#/$defs/illustrationCapability" };
  output.$defs.success.properties.result.oneOf.push({ $ref: "#/$defs/illustrationSnapshot" }, { $ref: "#/$defs/illustrationPreview" });
  return output;
}

function illustrationSnapshotExample() {
  return {
    schema: "tfsb.illustration-service-snapshot", version: 1, illustrationHandle: HANDLE,
    manifestDigest: RECORD_DIGEST, recordDigest: ZERO_DIGEST, illustrationId: "rei-main", revision: 1,
    operation: "import", provider: null, model: null,
    source: { sha256: PNG_DIGEST, mime: "image/png", byteLength: 70, dimensions: { width: 1, height: 1 }, alpha: "straight" },
    lineage: { parentDigest: null },
    derivatives: [{ derivativeHandle: HANDLE, id: "main", recipeDigest: RECIPE_DIGEST, sha256: PNG_DIGEST, byteLength: 70, mime: "image/png", width: 1, height: 1, alpha: "has-alpha", verification: "png-pixels-decoded" }],
    capabilities: { snapshot: true, preview: true, authoring: false, export: false, install: false }, state: "ready",
  };
}

function addIllustrationExamples(requests, results) {
  const nextRequests = structuredClone(requests);
  const initialize = nextRequests.find((request) => request.method === "initialize");
  if (!initialize) throw new Error("1.2 request examples do not contain initialize");
  initialize.id = "init-1.3";
  initialize.params.maxVersion = "1.3";
  nextRequests.push(
    { jsonrpc: "2.0", id: "illustration-open", method: "illustration.open", params: { sessionNonce: "REDACTED_EXAMPLE_NONCE", directory: "/trusted/illustrations", purpose: "illustration-carrier" } },
    { jsonrpc: "2.0", id: "illustration-preview", method: "illustration.preview.get", params: { sessionNonce: "REDACTED_EXAMPLE_NONCE", derivativeHandle: HANDLE } },
  );
  const nextResults = structuredClone(results);
  const initializeResult = nextResults.initialize;
  if (!initializeResult) throw new Error("1.2 result examples do not contain initialize");
  delete nextResults["init-1.2"];
  initializeResult.id = "init-1.3";
  initializeResult.result.selectedVersion = "1.3";
  initializeResult.result.capabilities.illustration = {
    schemaVersion: 1,
    methods: { open: true, previewGet: true },
    limits: { maxPreviewBytes: 4194304, maxDimension: 1024, maxPixels: 1048576, maxDerivativeHandles: 4 },
    state: "read-only",
  };
  nextResults["illustration.open"] = illustrationSnapshotExample();
  nextResults["illustration.preview.get"] = {
    schema: "tfsb.illustration-service-preview", version: 1, derivativeHandle: HANDLE, mime: "image/png",
    bytesBase64: PNG_BASE64, byteLength: 70, sha256: PNG_DIGEST, width: 1, height: 1, alpha: "has-alpha", verification: "png-pixels-decoded",
  };
  return { requests: nextRequests, results: nextResults };
}

export async function generateProtocol13({ sourceProtocolRoot, outputProtocolRoot }) {
  if (typeof sourceProtocolRoot !== "string" || typeof outputProtocolRoot !== "string") usageError();
  const source = resolve(sourceProtocolRoot);
  const output = resolve(outputProtocolRoot);
  const inventory = await readRegularJson(source, "inventory-1.2.json");
  const requests = await readRegularJson(source, "requests-1.2.schema.json");
  const results = await readRegularJson(source, "results-1.2.schema.json");
  const examplesRequests = await readRegularJson(source, "examples/1.2/requests.json");
  const examplesResults = await readRegularJson(source, "examples/1.2/results.json");
  if (inventory.version !== "1.2" || requests.title !== "TFSB Studio protocol 1.2 requests and client notifications"
      || results.title !== "TFSB Studio protocol 1.2 result and server-notification shapes") {
    throw new Error("protocol 1.2 source identity is unexpected");
  }
  const nextInventory = structuredClone(inventory);
  nextInventory.version = VERSION;
  const initializedIndex = nextInventory.advertisedMethods.indexOf("initialized");
  nextInventory.advertisedMethods.splice(initializedIndex < 0 ? nextInventory.advertisedMethods.length : initializedIndex, 0, "illustration.open", "illustration.preview.get");
  const examples = addIllustrationExamples(examplesRequests, examplesResults);
  await writeRegularJson(output, "inventory-1.3.json", nextInventory);
  await writeRegularJson(output, "requests-1.3.schema.json", addIllustrationRequests(requests));
  await writeRegularJson(output, "results-1.3.schema.json", addIllustrationResults(results));
  await writeRegularJson(output, "examples/1.3/requests.json", examples.requests);
  await writeRegularJson(output, "examples/1.3/results.json", examples.results);
  return { version: VERSION, files: ["inventory-1.3.json", "requests-1.3.schema.json", "results-1.3.schema.json", "examples/1.3/requests.json", "examples/1.3/results.json"] };
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const { source, output } = parseArgs(process.argv.slice(2));
  await generateProtocol13({ sourceProtocolRoot: source, outputProtocolRoot: output });
}
