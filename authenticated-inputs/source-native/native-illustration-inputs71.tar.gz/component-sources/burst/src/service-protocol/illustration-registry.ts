import { randomBytes } from "node:crypto";

import { computeSha256, type Sha256Digest } from "../digests.js";
import {
  disposeIllustrationSource,
  getIllustrationPayload,
  revalidateIllustrationSource,
  verifyIllustrationSource,
  type VerifiedIllustrationSource,
} from "../illustration/carrier-source.js";
import type { IllustrationCarrierAlpha, IllustrationCarrierDerivativeV1 } from "../illustration/carrier-v1.js";
import {
  inspectRasterDerivativePayload,
  type RasterDerivativeAlpha,
  type RasterDerivativePayloadInspectionV1,
} from "../illustration/derivative.js";

export const ILLUSTRATION_SNAPSHOT_SCHEMA = "tfsb.illustration-service-snapshot" as const;
export const ILLUSTRATION_PREVIEW_SCHEMA = "tfsb.illustration-service-preview" as const;
export const ILLUSTRATION_SERVICE_VERSION = 1 as const;
export const MAX_ILLUSTRATION_DERIVATIVE_HANDLES = 4 as const;
export const MAX_ILLUSTRATION_PREVIEW_BYTES = 4 * 1_048_576;
export const MAX_ILLUSTRATION_PREVIEW_DIMENSION = 1_024 as const;
export const MAX_ILLUSTRATION_PREVIEW_PIXELS = 1_048_576 as const;

export type IllustrationRegistryErrorCode =
  | "SESSION_CLOSED"
  | "SOURCE_INVALID"
  | "SOURCE_CHANGED"
  | "HANDLE_INVALID"
  | "HANDLE_STALE"
  | "DERIVATIVE_LIMIT"
  | "PREVIEW_LIMIT"
  | "PREVIEW_INVALID";

const ERROR_MESSAGES: Readonly<Record<IllustrationRegistryErrorCode, string>> = Object.freeze({
  SESSION_CLOSED: "The illustration session is closed.",
  SOURCE_INVALID: "The illustration carrier is invalid.",
  SOURCE_CHANGED: "The illustration carrier changed.",
  HANDLE_INVALID: "The illustration handle is invalid.",
  HANDLE_STALE: "The illustration handle is stale.",
  DERIVATIVE_LIMIT: "The illustration carrier exceeds the derivative limit.",
  PREVIEW_LIMIT: "The illustration preview exceeds the supported bound.",
  PREVIEW_INVALID: "The illustration preview is invalid.",
});

export class IllustrationRegistryError extends Error {
  readonly code: IllustrationRegistryErrorCode;

  constructor(code: IllustrationRegistryErrorCode) {
    super(ERROR_MESSAGES[code]);
    this.name = "IllustrationRegistryError";
    this.code = code;
  }
}

export interface IllustrationSnapshotSource {
  readonly sha256: Sha256Digest;
  readonly mime: "image/png" | "image/webp";
  readonly byteLength: number;
  readonly dimensions: Readonly<{ width: number; height: number }>;
  readonly alpha: "opaque" | "straight" | "premultiplied" | "unknown";
}

export interface IllustrationSnapshotDerivative {
  readonly derivativeHandle: string;
  readonly id: string;
  readonly recipeDigest: Sha256Digest;
  readonly sha256: Sha256Digest;
  readonly byteLength: number;
  readonly mime: "image/png" | "image/webp";
  readonly width: number;
  readonly height: number;
  readonly alpha: IllustrationCarrierAlpha;
  readonly verification: RasterDerivativePayloadInspectionV1["verification"];
}

export interface IllustrationSnapshot {
  readonly schema: typeof ILLUSTRATION_SNAPSHOT_SCHEMA;
  readonly version: typeof ILLUSTRATION_SERVICE_VERSION;
  readonly illustrationHandle: string;
  readonly manifestDigest: Sha256Digest;
  readonly recordDigest: Sha256Digest;
  readonly illustrationId: string;
  readonly revision: number;
  readonly operation: "import" | "generate" | "edit";
  readonly provider: string | null;
  readonly model: string | null;
  readonly source: IllustrationSnapshotSource;
  readonly lineage: Readonly<{ parentDigest: Sha256Digest | null }>;
  readonly derivatives: readonly IllustrationSnapshotDerivative[];
  readonly capabilities: Readonly<{
    snapshot: true;
    preview: true;
    authoring: false;
    export: false;
    install: false;
  }>;
  readonly state: "ready";
}

export interface IllustrationPreview {
  readonly schema: typeof ILLUSTRATION_PREVIEW_SCHEMA;
  readonly version: typeof ILLUSTRATION_SERVICE_VERSION;
  readonly derivativeHandle: string;
  readonly mime: "image/png" | "image/webp";
  readonly bytesBase64: string;
  readonly byteLength: number;
  readonly sha256: Sha256Digest;
  readonly width: number;
  readonly height: number;
  readonly alpha: RasterDerivativeAlpha;
  readonly verification: RasterDerivativePayloadInspectionV1["verification"];
}

interface DerivativeHandleEntry {
  readonly handle: string;
  readonly item: IllustrationCarrierDerivativeV1;
}

interface CurrentCarrier {
  readonly generation: number;
  readonly source: VerifiedIllustrationSource;
  readonly snapshot: IllustrationSnapshot;
  readonly derivatives: ReadonlyMap<string, DerivativeHandleEntry>;
}

/** @internal Connected race tests only; real carrier verification still runs. */
interface IllustrationRegistryTestHooks {
  readonly afterVerify?: (directoryInput: string) => Promise<void>;
  readonly afterRevalidate?: () => Promise<void>;
  readonly beforeDispose?: () => Promise<void>;
}

interface IllustrationRegistryOptions {
  readonly testHooks?: IllustrationRegistryTestHooks;
}

const HANDLE = /^[A-Za-z0-9_-]{43}$/u;

function fail(code: IllustrationRegistryErrorCode): never {
  throw new IllustrationRegistryError(code);
}

function freezeSnapshot(snapshot: IllustrationSnapshot): IllustrationSnapshot {
  for (const derivative of snapshot.derivatives) Object.freeze(derivative);
  Object.freeze(snapshot.source.dimensions);
  Object.freeze(snapshot.source);
  Object.freeze(snapshot.lineage);
  Object.freeze(snapshot.capabilities);
  Object.freeze(snapshot.derivatives);
  return Object.freeze(snapshot);
}

function freezePreview(preview: IllustrationPreview): IllustrationPreview {
  return Object.freeze(preview);
}

function newHandle(): string {
  const handle = randomBytes(32).toString("base64url");
  if (!HANDLE.test(handle)) fail("HANDLE_INVALID");
  return handle;
}

function isPreviewBounded(item: IllustrationCarrierDerivativeV1): boolean {
  return item.byteLength <= MAX_ILLUSTRATION_PREVIEW_BYTES
    && item.width <= MAX_ILLUSTRATION_PREVIEW_DIMENSION
    && item.height <= MAX_ILLUSTRATION_PREVIEW_DIMENSION
    && item.width * item.height <= MAX_ILLUSTRATION_PREVIEW_PIXELS;
}

function matchesInspection(item: IllustrationCarrierDerivativeV1, bytes: Uint8Array, inspection: RasterDerivativePayloadInspectionV1): boolean {
  return bytes.byteLength === item.byteLength
    && computeSha256(bytes) === item.sha256
    && inspection.width === item.width
    && inspection.height === item.height
    && inspection.alpha === item.alpha;
}

/**
 * Session-owned read-only illustration carrier registry. The only path-taking
 * operation is the native-host boundary `openFromNativeHost`; preview accepts
 * only an opaque derivative handle and never a path or carrier object.
 */
export class IllustrationRegistry {
  #current: CurrentCarrier | undefined;
  #closed = false;
  #generation = 0;
  #disposals = new WeakMap<VerifiedIllustrationSource, Promise<void>>();
  readonly #testHooks: IllustrationRegistryTestHooks | undefined;

  constructor(options: IllustrationRegistryOptions = {}) {
    this.#testHooks = options.testHooks;
  }

  async openFromNativeHost(directoryInput: string): Promise<IllustrationSnapshot> {
    if (this.#closed) fail("SESSION_CLOSED");
    if (typeof directoryInput !== "string" || directoryInput.length === 0) fail("SOURCE_INVALID");
    const generation = ++this.#generation;

    let source: VerifiedIllustrationSource | undefined;
    try {
      source = await verifyIllustrationSource(directoryInput);
      if (source.manifest.derivatives.length > MAX_ILLUSTRATION_DERIVATIVE_HANDLES) fail("DERIVATIVE_LIMIT");
      await this.#testHooks?.afterVerify?.(directoryInput);

      const illustrationHandle = newHandle();
      const entries: DerivativeHandleEntry[] = [];
      const derivatives: IllustrationSnapshotDerivative[] = [];
      for (const item of source.manifest.derivatives) {
        const bytes = getIllustrationPayload(source, item.id);
        const inspection = inspectRasterDerivativePayload(bytes, item.mime);
        if (!matchesInspection(item, bytes, inspection)) fail("SOURCE_INVALID");
        const handle = newHandle();
        entries.push({ handle, item });
        derivatives.push({
          derivativeHandle: handle,
          id: item.id,
          recipeDigest: item.recipeDigest,
          sha256: item.sha256,
          byteLength: item.byteLength,
          mime: item.mime,
          width: item.width,
          height: item.height,
          alpha: item.alpha,
          verification: inspection.verification,
        });
      }

      const record = source.record;
      const snapshot = freezeSnapshot({
        schema: ILLUSTRATION_SNAPSHOT_SCHEMA,
        version: ILLUSTRATION_SERVICE_VERSION,
        illustrationHandle,
        manifestDigest: source.manifest.manifestDigest,
        recordDigest: record.digest,
        illustrationId: record.illustrationId,
        revision: record.revision,
        operation: record.operation,
        provider: record.provider,
        model: record.model,
        source: {
          sha256: record.source.sha256,
          mime: record.source.mime,
          byteLength: record.source.byteLength,
          dimensions: { ...record.source.dimensions },
          alpha: record.source.alpha,
        },
        lineage: { parentDigest: record.lineage.parentDigest },
        derivatives,
        capabilities: { snapshot: true, preview: true, authoring: false, export: false, install: false },
        state: "ready",
      });
      this.#assertOpenGeneration(generation);
      const next: CurrentCarrier = { generation, source, snapshot, derivatives: new Map(entries.map((entry) => [entry.handle, entry])) };
      const previous = this.#current;
      this.#current = next;
      if (previous !== undefined) await this.#disposeSource(previous.source);
      // After committing, a newer invalid request must not strand this live
      // carrier. Only an actual replacement, restart or close retires it.
      if (this.#closed) fail("SESSION_CLOSED");
      if (this.#current !== next) fail("SOURCE_CHANGED");
      return snapshot;
    } catch (error) {
      if (source !== undefined && source !== this.#current?.source) await this.#disposeSource(source);
      if (error instanceof IllustrationRegistryError) throw error;
      if (this.#closed) fail("SESSION_CLOSED");
      if (this.#generation !== generation) fail("SOURCE_CHANGED");
      fail("SOURCE_INVALID");
    }
  }

  async preview(derivativeHandle: string): Promise<IllustrationPreview> {
    if (this.#closed) fail("SESSION_CLOSED");
    if (typeof derivativeHandle !== "string") fail("HANDLE_INVALID");
    if (!HANDLE.test(derivativeHandle)) fail("HANDLE_INVALID");
    const current = this.#current;
    if (current === undefined) fail("HANDLE_STALE");
    const generation = current.generation;
    const entry = current.derivatives.get(derivativeHandle);
    if (entry === undefined) fail("HANDLE_STALE");
    if (!isPreviewBounded(entry.item)) fail("PREVIEW_LIMIT");

    try {
      await revalidateIllustrationSource(current.source);
      await this.#testHooks?.afterRevalidate?.();
    } catch {
      await this.#invalidateCurrent(current);
      if (this.#closed) fail("SESSION_CLOSED");
      fail("SOURCE_CHANGED");
    }
    this.#assertPreviewOwnership(current, generation);

    let bytes: Uint8Array;
    try {
      bytes = getIllustrationPayload(current.source, entry.item.id);
    } catch {
      await this.#invalidateCurrent(current);
      if (this.#closed) fail("SESSION_CLOSED");
      fail("SOURCE_CHANGED");
    }
    try {
      const inspection = inspectRasterDerivativePayload(bytes, entry.item.mime);
      if (!matchesInspection(entry.item, bytes, inspection)) fail("PREVIEW_INVALID");
      if (!isPreviewBounded(entry.item)) fail("PREVIEW_LIMIT");
      this.#assertPreviewOwnership(current, generation);
      return freezePreview({
        schema: ILLUSTRATION_PREVIEW_SCHEMA,
        version: ILLUSTRATION_SERVICE_VERSION,
        derivativeHandle,
        mime: entry.item.mime,
        bytesBase64: Buffer.from(bytes).toString("base64"),
        byteLength: bytes.byteLength,
        sha256: computeSha256(bytes),
        width: inspection.width,
        height: inspection.height,
        alpha: inspection.alpha,
        verification: inspection.verification,
      });
    } catch (error) {
      if (error instanceof IllustrationRegistryError) throw error;
      fail("PREVIEW_INVALID");
    }
  }

  async close(): Promise<void> {
    if (this.#closed) return;
    this.#closed = true;
    ++this.#generation;
    await this.#discardCurrent();
  }

  /** Invalidate the current carrier while keeping this session reusable. */
  async restart(): Promise<void> {
    if (this.#closed) return;
    ++this.#generation;
    await this.#discardCurrent();
  }

  async #discardCurrent(): Promise<void> {
    const current = this.#current;
    this.#current = undefined;
    if (current !== undefined) await this.#disposeSource(current.source);
  }

  get closed(): boolean { return this.#closed; }

  async #invalidateCurrent(current: CurrentCarrier): Promise<void> {
    if (this.#current !== current) return;
    this.#current = undefined;
    await this.#disposeSource(current.source);
  }

  #assertOpenGeneration(generation: number): void {
    if (this.#closed) fail("SESSION_CLOSED");
    if (this.#generation !== generation) fail("SOURCE_CHANGED");
  }

  #assertPreviewOwnership(current: CurrentCarrier, generation: number): void {
    if (this.#closed) fail("SESSION_CLOSED");
    if (this.#current !== current || current.generation !== generation) fail("SOURCE_CHANGED");
  }

  async #disposeSource(source: VerifiedIllustrationSource): Promise<void> {
    const existing = this.#disposals.get(source);
    if (existing !== undefined) {
      await existing;
      return;
    }
    const pending = (async () => {
      await this.#testHooks?.beforeDispose?.();
      await disposeIllustrationSource(source);
    })().catch(() => undefined);
    this.#disposals.set(source, pending);
    await pending;
  }
}

