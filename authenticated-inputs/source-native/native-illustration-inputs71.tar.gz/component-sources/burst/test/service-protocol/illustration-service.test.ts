import { PassThrough } from "node:stream";
import { describe, expect, it, vi } from "vitest";

import { computeSha256 } from "../../src/digests.js";
import { StudioServer } from "../../src/service-protocol/server.js";
import { StudioSession } from "../../src/service-protocol/session.js";
import { ValidationError, validateResult } from "../../src/service-protocol/v1-validate.js";
import { cleanup, makeCarrier, temporary } from "../illustration-fixture.js";

type IllustrationRegistryHooks = {
  readonly beforeDispose?: () => Promise<void>;
};

let registryHooks: IllustrationRegistryHooks | undefined;

vi.mock("../../src/service-protocol/illustration-registry.js", async (importOriginal) => {
  const actual = await importOriginal<typeof import("../../src/service-protocol/illustration-registry.js")>();
  class TestIllustrationRegistry extends actual.IllustrationRegistry {
    constructor() {
      super(registryHooks === undefined ? undefined : { testHooks: registryHooks });
    }
  }
  return { ...actual, IllustrationRegistry: TestIllustrationRegistry };
});

interface JsonRpcResponse { readonly id: string | number | null; readonly result?: unknown; readonly error?: { readonly data?: { readonly code?: string } } }

function response(output: PassThrough): Promise<JsonRpcResponse> {
  return new Promise((resolve) => {
    let buffer = "";
    const onData = (chunk: Buffer | string): void => {
      buffer += chunk.toString();
      const newline = buffer.indexOf("\n");
      if (newline < 0) return;
      output.off("data", onData);
      resolve(JSON.parse(buffer.slice(0, newline)) as JsonRpcResponse);
    };
    output.on("data", onData);
  });
}

function responses(output: PassThrough, count: number): Promise<readonly JsonRpcResponse[]> {
  return new Promise((resolve) => {
    let buffer = "";
    const records: JsonRpcResponse[] = [];
    const onData = (chunk: Buffer | string): void => {
      buffer += chunk.toString();
      while (true) {
        const newline = buffer.indexOf("\n");
        if (newline < 0) break;
        records.push(JSON.parse(buffer.slice(0, newline)) as JsonRpcResponse);
        buffer = buffer.slice(newline + 1);
        if (records.length === count) { output.off("data", onData); resolve(records); return; }
      }
    };
    output.on("data", onData);
  });
}

function send(input: PassThrough, output: PassThrough, message: object): Promise<JsonRpcResponse> {
  const result = response(output);
  input.write(`${JSON.stringify(message)}\n`);
  return result;
}

async function initialized(input: PassThrough, output: PassThrough, minVersion = "1.3", maxVersion = "1.3"): Promise<{ readonly nonce: string; readonly init: JsonRpcResponse }> {
  const init = await send(input, output, {
    jsonrpc: "2.0", id: "init", method: "initialize",
    params: { protocol: "tfsb.studio", minVersion, maxVersion, client: { name: "isolated-532", version: "1" }, capabilities: { progress: false, cancellation: true } },
  });
  const nonce = (init.result as { readonly sessionNonce: string }).sessionNonce;
  input.write(`${JSON.stringify({ jsonrpc: "2.0", method: "initialized", params: { sessionNonce: nonce } })}\n`);
  return { nonce, init };
}

describe("isolated 1.3 illustration service afterimage", () => {
  it("negotiates 1.3, opens a real carrier, previews by opaque handle, and disposes on shutdown", async () => {
    const owned: string[] = [];
    const root = await temporary(owned);
    const carrier = await makeCarrier(root);
    const input = new PassThrough(); const output = new PassThrough(); const error = new PassThrough();
    new StudioServer({ input, output, error }).start();
    const { nonce, init } = await initialized(input, output);
    expect(init.result).toMatchObject({ selectedVersion: "1.3", capabilities: { illustration: { methods: { open: true, previewGet: true }, limits: { maxPreviewBytes: 4_194_304, maxDimension: 1_024, maxPixels: 1_048_576, maxDerivativeHandles: 4 }, state: "read-only" } } });
    expect(Object.keys((init.result as { readonly capabilities: Record<string, unknown> }).capabilities).sort()).toEqual(["brand", "illustration", "limits", "methods"]);

    const privatePath = "/home/private-fixture/missing-carrier";
    const missing = await send(input, output, { jsonrpc: "2.0", id: "missing", method: "illustration.open", params: { sessionNonce: nonce, directory: privatePath, purpose: "illustration-carrier" } });
    expect(missing.error?.data?.code).toBe("DOMAIN_OPERATION_FAILED");
    expect(JSON.stringify(missing)).not.toContain(privatePath);
    const unknown = await send(input, output, { jsonrpc: "2.0", id: "unknown", method: "illustration.open", params: { sessionNonce: nonce, directory: carrier.carrier, purpose: "illustration-carrier", extra: true } });
    expect(unknown.error?.data?.code).toBe("INVALID_PARAMS");

    const opened = await send(input, output, { jsonrpc: "2.0", id: "open", method: "illustration.open", params: { sessionNonce: nonce, directory: carrier.carrier, purpose: "illustration-carrier" } });
    expect(opened.error).toBeUndefined();
    const snapshot = opened.result as { readonly illustrationId: string; readonly derivatives: readonly [{ readonly derivativeHandle: string; readonly id: string }]; readonly source: { readonly sha256: string }; readonly capabilities: { readonly authoring: false; readonly export: false; readonly install: false } };
    expect(snapshot.illustrationId).toBe("synthetic_hero.v1");
    expect(snapshot.derivatives.length).toBeGreaterThanOrEqual(1);
    expect(snapshot.derivatives[0].id).toBe("hero_1.preview");
    expect(snapshot.source.sha256).toMatch(/^sha256:[0-9a-f]{64}$/u);
    expect(snapshot.capabilities).toEqual({ snapshot: true, preview: true, authoring: false, export: false, install: false });

    const snapshotRecord = opened.result as Record<string, unknown>;
    const sourceRecord = snapshotRecord.source as Record<string, unknown>;
    const derivativeRecord = (snapshotRecord.derivatives as readonly Record<string, unknown>[])[0]!;
    expect(() => validateResult("illustration.open", { ...snapshotRecord, source: { ...sourceRecord, dimensions: { width: 1, height: 1, extra: true } } })).toThrow(ValidationError);
    expect(() => validateResult("illustration.open", { ...snapshotRecord, provider: "/home/private-fixture/provider" })).toThrow(ValidationError);
    expect(() => validateResult("illustration.open", { ...snapshotRecord, model: "m".repeat(129) })).toThrow(ValidationError);
    expect(() => validateResult("illustration.open", { ...snapshotRecord, illustrationId: "bad/id" })).toThrow(ValidationError);
    expect(() => validateResult("illustration.open", { ...snapshotRecord, derivatives: [{ ...derivativeRecord, id: "bad$id" }] })).toThrow(ValidationError);
    expect(() => validateResult("illustration.open", { ...snapshotRecord, provider: "sk-proj-12345678901234567890" })).toThrow(ValidationError);
    expect(() => validateResult("illustration.open", { ...snapshotRecord, revision: 0 })).toThrow(ValidationError);
    expect(() => validateResult("illustration.open", { ...snapshotRecord, source: { ...sourceRecord, byteLength: 0 } })).toThrow(ValidationError);
    expect(() => validateResult("illustration.open", { ...snapshotRecord, source: { ...sourceRecord, alpha: "has-alpha" } })).toThrow(ValidationError);
    expect(() => validateResult("illustration.open", { ...snapshotRecord, derivatives: [{ ...derivativeRecord, alpha: "straight" }] })).toThrow(ValidationError);
    expect(() => validateResult("illustration.open", { ...snapshotRecord, derivatives: [{ ...derivativeRecord, verification: "webp-header-only" }] })).toThrow(ValidationError);

    const preview = await send(input, output, { jsonrpc: "2.0", id: "preview", method: "illustration.preview.get", params: { sessionNonce: nonce, derivativeHandle: snapshot.derivatives[0].derivativeHandle } });
    expect(preview.error).toBeUndefined();
    expect(preview.result).toMatchObject({ schema: "tfsb.illustration-service-preview", version: 1, mime: "image/png", width: 1, height: 1, verification: "png-pixels-decoded" });
    expect((preview.result as { readonly bytesBase64: string }).bytesBase64).toBe(Buffer.from(carrier.payload).toString("base64"));
    expect(() => validateResult("illustration.preview.get", { ...(preview.result as Record<string, unknown>), unknown: true })).toThrow(ValidationError);

    const shutdown = await send(input, output, { jsonrpc: "2.0", id: "shutdown", method: "shutdown", params: { sessionNonce: nonce } });
    expect(shutdown.result).toBeNull();
    const afterShutdown = await send(input, output, { jsonrpc: "2.0", id: "after", method: "illustration.preview.get", params: { sessionNonce: nonce, derivativeHandle: snapshot.derivatives[0].derivativeHandle } });
    expect(afterShutdown.error?.data?.code).toBe("SESSION_NOT_INITIALIZED");
    input.end(); await cleanup(owned);
  });

  it("accepts full source dimensions while retaining a small preview", async () => {
    const owned: string[] = []; const root = await temporary(owned);
    const carrier = await makeCarrier(root, { width: 1, height: 1, sourceWidth: 1_024, sourceHeight: 1_536 });
    const input = new PassThrough(); const output = new PassThrough(); const error = new PassThrough(); new StudioServer({ input, output, error }).start();
    const { nonce } = await initialized(input, output);
    const opened = await send(input, output, { jsonrpc: "2.0", id: "large-source", method: "illustration.open", params: { sessionNonce: nonce, directory: carrier.carrier, purpose: "illustration-carrier" } });
    expect(opened.result).toMatchObject({ source: { dimensions: { width: 1_024, height: 1_536 } }, derivatives: [{ width: 1, height: 1 }] });
    const handle = ((opened.result as { readonly derivatives: readonly [{ readonly derivativeHandle: string }] }).derivatives[0]).derivativeHandle;
    const preview = await send(input, output, { jsonrpc: "2.0", id: "small-preview", method: "illustration.preview.get", params: { sessionNonce: nonce, derivativeHandle: handle } });
    expect(preview.result).toMatchObject({ width: 1, height: 1, byteLength: carrier.payload.byteLength });
    input.end(); await cleanup(owned);
  });

  it("returns a valid snapshot for a non-preview-eligible derivative and refuses only the preview", async () => {
    const owned: string[] = []; const root = await temporary(owned);
    const carrier = await makeCarrier(root, { width: 1_024, height: 1_536 });
    const input = new PassThrough(); const output = new PassThrough(); const error = new PassThrough(); new StudioServer({ input, output, error }).start();
    const { nonce } = await initialized(input, output);
    const opened = await send(input, output, { jsonrpc: "2.0", id: "large-derivative", method: "illustration.open", params: { sessionNonce: nonce, directory: carrier.carrier, purpose: "illustration-carrier" } });
    expect(opened.result).toMatchObject({ derivatives: [{ width: 1_024, height: 1_536 }] });
    const handle = ((opened.result as { readonly derivatives: readonly [{ readonly derivativeHandle: string }] }).derivatives[0]).derivativeHandle;
    const preview = await send(input, output, { jsonrpc: "2.0", id: "too-large-preview", method: "illustration.preview.get", params: { sessionNonce: nonce, derivativeHandle: handle } });
    expect(preview.error?.data?.code).toBe("DOMAIN_OPERATION_FAILED");
    input.end(); await cleanup(owned);
  });

  it("accepts the exact raw preview byte bound without invoking an image decoder", () => {
    const bytes = Buffer.alloc(4 * 1_048_576);
    const bytesBase64 = bytes.toString("base64");
    validateResult("illustration.preview.get", {
      schema: "tfsb.illustration-service-preview", version: 1,
      derivativeHandle: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", mime: "image/png",
      bytesBase64, byteLength: bytes.byteLength, sha256: computeSha256(bytes), width: 1, height: 1,
      alpha: "opaque", verification: "png-pixels-decoded",
    });
    const tooLarge = Buffer.alloc(4 * 1_048_576 + 1);
    expect(() => validateResult("illustration.preview.get", {
      schema: "tfsb.illustration-service-preview", version: 1,
      derivativeHandle: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", mime: "image/png",
      bytesBase64: tooLarge.toString("base64"), byteLength: tooLarge.byteLength, sha256: computeSha256(tooLarge), width: 1, height: 1,
      alpha: "opaque", verification: "png-pixels-decoded",
    })).toThrow(ValidationError);
  });

  it("keeps 1.2 unavailable for the new methods and rejects private-invalid inputs without echoing them", async () => {
    const input = new PassThrough(); const output = new PassThrough(); const error = new PassThrough();
    new StudioServer({ input, output, error }).start();
    const { nonce } = await initialized(input, output, "1.2", "1.2");
    const legacy = await send(input, output, { jsonrpc: "2.0", id: "new", method: "illustration.preview.get", params: { sessionNonce: nonce, derivativeHandle: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" } });
    expect(legacy.error?.data?.code).toBe("METHOD_NOT_FOUND");
    const privatePath = "/home/private-fixture/secret-carrier";
    const bad = await send(input, output, { jsonrpc: "2.0", id: "bad", method: "source.open", params: { sessionNonce: nonce, path: privatePath, purpose: "not-a-purpose" } });
    expect(bad.error?.data?.code).toBe("INVALID_PARAMS");
    expect(JSON.stringify(bad)).not.toContain(privatePath);
    input.end();
  });

  it("keeps the prior 1.0-1.2 capability shapes closed", async () => {
    for (const version of ["1.0", "1.1", "1.2"] as const) {
      const input = new PassThrough(); const output = new PassThrough(); const error = new PassThrough();
      new StudioServer({ input, output, error }).start();
      const { init } = await initialized(input, output, version, version);
      const capabilities = init.result as { readonly capabilities: Record<string, unknown> };
      expect(capabilities.capabilities).not.toHaveProperty("illustration");
      if (version === "1.0") expect(capabilities.capabilities).not.toHaveProperty("brand");
      else expect(capabilities.capabilities).toHaveProperty("brand");
      input.end();
    }
  });

  it("checks cancellation before the registry await and cancels a queued real-service request", async () => {
    const controller = new AbortController(); controller.abort();
    const session = new StudioSession();
    await expect(session.illustrationPreview("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", controller.signal)).rejects.toMatchObject({ symbolicCode: "REQUEST_CANCELLED" });
    const afterController = new AbortController();
    const afterResult = session.illustrationOpen("/home/private-fixture/not-used", afterController.signal);
    queueMicrotask(() => afterController.abort());
    await expect(afterResult).rejects.toMatchObject({ symbolicCode: "REQUEST_CANCELLED" });
    await session.shutdown();

    const owned: string[] = []; const root = await temporary(owned); const carrier = await makeCarrier(root);
    const input = new PassThrough(); const output = new PassThrough(); const error = new PassThrough(); new StudioServer({ input, output, error }).start();
    const { nonce } = await initialized(input, output);
    const both = responses(output, 2);
    input.write(`${JSON.stringify({ jsonrpc: "2.0", id: "first", method: "illustration.open", params: { sessionNonce: nonce, directory: carrier.carrier, purpose: "illustration-carrier" } })}\n`);
    input.write(`${JSON.stringify({ jsonrpc: "2.0", id: "second", method: "illustration.open", params: { sessionNonce: nonce, directory: carrier.carrier, purpose: "illustration-carrier" } })}\n`);
    input.write(`${JSON.stringify({ jsonrpc: "2.0", method: "$/cancelRequest", params: { sessionNonce: nonce, id: "second" } })}\n`);
    const records = await both;
    expect(records.find((item) => item.id === "second")?.error?.data?.code).toBe("REQUEST_CANCELLED");
    expect(records.find((item) => item.id === "first")?.result).toBeDefined();
    input.end(); await cleanup(owned);
  });

  it("returns the committed open snapshot when cancellation arrives during old-carrier disposal", async () => {
    const owned: string[] = [];
    const root = await temporary(owned);
    const firstCarrier = await makeCarrier(root, { revision: 1 });
    const secondCarrier = await makeCarrier(root, { revision: 2 });
    let disposalStarted: (() => void) | undefined;
    let releaseDisposal: (() => void) | undefined;
    const disposalReady = new Promise<void>((resolve) => { disposalStarted = resolve; });
    const disposalRelease = new Promise<void>((resolve) => { releaseDisposal = resolve; });
    let holdFirstDisposal = true;
    registryHooks = {
      beforeDispose: async () => {
        if (!holdFirstDisposal) return;
        holdFirstDisposal = false;
        disposalStarted?.();
        await disposalRelease;
      },
    };
    const session = new StudioSession();
    try {
      await session.illustrationOpen(firstCarrier.carrier, new AbortController().signal);
      const controller = new AbortController();
      const opening = session.illustrationOpen(secondCarrier.carrier, controller.signal);
      await disposalReady;
      controller.abort();
      releaseDisposal?.();
      const snapshot = await opening;
      expect(snapshot.source.sha256).toMatch(/^sha256:[0-9a-f]{64}$/u);
      await expect(session.illustrationPreview(snapshot.derivatives[0]!.derivativeHandle, new AbortController().signal)).resolves.toMatchObject({
        derivativeHandle: snapshot.derivatives[0]!.derivativeHandle,
      });
    } finally {
      releaseDisposal?.();
      await session.shutdown();
      registryHooks = undefined;
      await cleanup(owned);
    }
  });
});
